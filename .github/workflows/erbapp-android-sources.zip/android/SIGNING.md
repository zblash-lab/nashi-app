# Erbapp kalıcı kişisel imzası

## Anahtarın korunması

`ERBAPP_SIGNING` yalnızca GitHub Actions repository secret olarak saklanır.
JSON; base64 PKCS12, store_password, key_password ve alias alanlarını taşır.
Özel değerler kaynak kodda, YAML'da, raporlarda veya APK artifact'inde yoktur.
Kaynak paketindeki `signing/certificate.der` ve `certificate.sha256` herkese açık
sertifika ve kimlik özetidir; bu dosyalar APK imzalamak için kullanılamaz.

Araç her çalışmada yeni anahtar üretmez. CI secret'ı yoksa veya anahtar beklenen
sertifikayla eşleşmiyorsa işlem durur. Başka bir anahtara otomatik geçiş yapılmaz.
Özel anahtarın kaybı, mevcut kurulumlara aynı imzayla güncelleme üretememek demektir.

## Derleme akışı

Mevcut debug adlı Gradle varyantı korunur; `isDebuggable=false` ile uygulama hata
ayıklamaya kapalıdır. JUnit/lint ve runtime lisans denetimi bu varyantla çalışır.
Başarılı ara APK `apksigner sign` ile kalıcı anahtar kullanılarak `Erbapp.apk`
olarak imzalanır. Önceki geçici debug imzası final APK için kullanılmaz.

`sign_apk.py` anahtarı 0700 geçici klasörde 0600 izinli dosyaya açar; keystore ve
parolayı `keytool` ile kontrol eder. Parolalar komut metnine yazılmaz; alt sürecin
environment değerlerinden okunur. İşlem bitince geçici anahtar dosyası silinir.
`apksigner verify --verbose --print-certs` başarılı olmalı ve tek APK sertifikasının
SHA-256 özeti sabit açık sertifikayla eşleşmelidir. Ancak bundan sonra son APK ve
herkese açık imza bilgisi çıktı dizinine yazılır.

İmza secret'ını kullanan adımlar `tee` ile dosyaya alınmaz: GitHub add-mask kontrol
komutlarının ham içerikleri rapor artifact'ine kopyalanamaz. Raporlanabilir durum,
ayrı `signing-status.json` dosyasında yalnız kontrollü mesaj ve açık özetle tutulur.
APK artifact'i yalnız son APK, SHA256SUMS, signing-info ve lisans raporunu içerir.

## Güncelleme kimliği

Görünen ad: Erbapp. Paket kimliği: lab.zblash.nashi. CI versionCode=1000+GITHUB_RUN_NUMBER; yerel versionCode=10.
Sabit sertifika ve mevcut workflow dosya adı korunmalı; yeni çalıştırmalarda versionCode artar. Eski
geçici imzalı Nashi kurulumuyla ilk geçişte yeniden kurulum gerekebilir. Kalıcı
imza ilk geçişteki geçici imzayı geri getirmez.

## Doğrulama sınırı

Yerelde PKCS12 açma, gerçek RSA-3072 özel anahtarla mesaj imzalama ve açık anahtarla
doğrulama yapıldı. Otomatik testler; hatalı secret, sertifika uyuşmazlığı, çoklu
imza, doğrulama öncesi APK yayımının engellenmesi ve anahtarların kaynak paketine
sokulmasının reddini kapsar. 0.4.2 (#11) için CI APK üretimi ve apksigner doğrulaması başarılıdır. 0.5.2 için
aynı işlemler yeni CI sonucuyla doğrulanmalıdır; yerelde SDK yoktur.

Kaynaklar:
- https://developer.android.com/studio/publish/app-signing
- https://developer.android.com/tools/apksigner
- https://docs.github.com/en/actions/how-tos/write-workflows/choose-what-workflows-do/use-secrets
