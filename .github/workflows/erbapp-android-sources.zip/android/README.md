# Erbapp Android 0.6.0

Kotlin, Jetpack Compose ve Material 3 kabuğu; Android'e özel yerel dosya ekranı ve
çevrimdışı WebView işlem motorları. API 26+, compile/target 37.0/37, AGP 9.2.0,
Gradle 9.4.1, JDK 17, Kotlin/Compose 2.2.10. Hesap, reklam, abonelik ve INTERNET
veya genel depolama izni yoktur. Arayüz Türkçe ve koyu temadır.

## Web'den bağımsız Android

APK arayüzü app-ui/ içindedir. prepare_android.py yalnız android/ kaynaklarından
varlık üretir; docs/, playground.js, demo kataloğu, web sitesi ve Pages yayınına
bağımlı değildir. Önceki ortak playground adaptörleri kaynak geçmişi ve regresyon
testleri için tutulur; APK'ya paketlenmez veya Gradle tarafından çağrılmaz.

Görünen üç sekme Görseller, PDF ve EPUB'dur. Gerçek araçlar PNG/JPEG/WebP üretme,
görsellerden A4 PDF, PDF birleştirme/sayfa seçme/döndürme ve DRM'siz EPUB → PDF'dir.
Dosya yönetimi sayfa içinde açılır; örnek ve masaüstü önizleme menüleri yoktur.
Girdiler aynı erbapp-files IndexedDB şemasında korunur. Paket kimliği, yerel URL
ve imza değişmediğinden mevcut girdiler için yeni bir veri alanı oluşturulmaz.

Kaldırma yalnız uygulama içindeki kopyaya uygulanır. Kaydet, SAF ile yeni dosya
üretir; Paylaş, FileProvider kullanır. Girdiler grup geçişinde korunur. Kalıcı
kayıt mümkün değilse durum metni bunu söyler. Çıktı kitaplığı oturum içindir;
en fazla altı çıktı/96 MB tutulur. Kalıcı çıktı için Kaydet tamamlanmalıdır.

## Kaynaklar ve lisanslar

vendor/ içindeki pdf-lib 1.17.1 (MIT), pako inflate 1.0.11 (MIT ve Zlib) ve
DejaVu Sans 2.37 (Bitstream Vera ve Arev; DejaVu değişiklikleri public domain)
değiştirilmemiştir. SHA-256 ve lisans metinleri manifest ile denetlenir. Lisans
sayfası Nashi, Erbapp, font ve bağımlılık bildirimlerini taşır. Android Maven
runtime lisans denetimi ayrıca zorunludur. Playwright 1.55.0 (Apache-2.0),
pypdf 6.10.0 (BSD-3-Clause) ve Pillow 12.3.0 (MIT-CMU) yalnız test bağımlılığıdır;
APK'ya eklenmez. Pillow, PDF görsellerinin bağımsız okunması için açıkça kurulur.

## CI ve kaynak sürümünün doğrulanması

make_bootstrap.py yaklaşık 8 KB nashi-android.yml ile ayrı kaynak ZIP'i üretir.
İkisi tek commit ile .github/workflows/ klasörüne yüklenir. ZIP tümüyle SHA-256 ile
doğrulanır; yalnız android/ yolları açılır. Eski Android checkout'u, doğrulama
sonrasında temizlenir ve teslimattaki kaynaklar kullanılır. Eski kaynaklara sessiz
fallback yoktur. Workflow boyutu 500000 byte'ın altında olmalıdır. Özel anahtarlar
kaynak ZIP'ine eklenemez. Actions çalışma başlığında sürüm görünür; source-package.json
sürüm, commit, run ID, deneme ve ZIP özetini taşır. Rapor sürümle başlar.

CI yalnız APK yayınlar. browser_acceptance.py --android-only ile 10 bağımsız Chrome
senaryosu çalışır: PNG, JPEG, WebP, görsel PDF, EPUB PDF, PDF sayfa seçme, birleştirme,
döndürme, dosya yönetimi ve kitaplık. Bir hata diğerlerini durdurmaz; herhangi bir
zorunlu hata APK yayınını engeller. Başarılı dosyaların içerikleri, diğer senaryolar
başarısız olsa da bağımsız Pillow/pypdf ile incelenir ve tüm hatalar saklanır.

CSP gevşetilmez; test içinden eval reddi ölçülmez. page.wait_for_function yerine
DevTools değerlendirmesiyle süreli bekleme kullanılır. Gerçek kaydet linki ve
parçalı JS aktarımı çalışır; native yanıtlar test çiftidir. Fiziksel Android SAF,
Paylaş ve WebView kabulü bu Chrome senaryosunun kapsamı dışındadır.

## Kanıt düzeyi

Yerel Python ve Node testleri, yalnız Android kaynaklarıyla gerçek varlık paketleme,
controller → gerçek PDF motoru → kitaplık akışı, veri koruma ve iptal senaryolarını
kapsar. Yerel gerçek görsel/PDF motor çıktıları native canvas adaptörüyle üretildi
ve bağımsız okuyucularla incelendi; bu bir Chrome veya Android cihaz testi değildir.
Yeni 0.6.0 compile/lint/JUnit, Chrome ve final apksigner sonucu CI bekler. Önceki
0.5.3 raporunun başarısız kontrolü yeni sürümün çalıştırıldığına kanıt sayılmaz.

ERBAPP_SIGNING aynen korunur. applicationId=lab.zblash.nashi; CI versionCode=
1000+GITHUB_RUN_NUMBER. Mevcut uygulamanın üzerine kur; verileri temizleme. Bilgi
bölümünde 0.6.0-personal görülmelidir. Ayrıntılı işlev sınırları KAPSAM.md içindedir.
