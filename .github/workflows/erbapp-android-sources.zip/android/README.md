# Erbapp Android 0.6.1 — klasik Nashi arayüzü

0.6.0'da getirilen üç sekmeli sade ekran geri alındı. APK yeniden özgün Nashi
sekmelerini, dosya kartlarını, Dönüştür/Araçlar/İşlemler çarklarını, kitaplığı ve
araç pencerelerini kullanır. app-ui/ içindeki deneysel 0.6.0 ekranı APK'ya
paketlenmez. Eski yeteneklerin menülerini kaldırarak hata giderme yapılmaz.

## Web'den bağımsızlık

Klasik HTML, playground.js, CSS, çark geometrisi ve katalog android/classic-ui/
içinde sabitlenmiştir. prepare_android.py yalnız android/ kaynaklarını okur;
GitHub Pages'e, canlı web sitesine veya repo docs/ klasörüne bağımlı değildir.
Sabit kaynaklar SHA-256 ile kontrol edilir. Kaynağa yalnız açıkça denetlenen
başlangıç adaptörleri ve gerçek medya giriş düzeltmesi uygulanır. CSS ve çark
geometrisi byte düzeyinde özgün halleriyle paketlenir.

Kotlin/Compose/Material 3 kabuğu, Türkçe koyu tema ve API 26+ korunur. Yeni ekran
native Kotlin motorlarının tümüyle yeniden yazıldığı şeklinde sunulmaz; araçlar
çevrimdışı WebView'da çalışır. Uygulamada INTERNET/genel depolama izni, reklam,
abonelik ve hesap yoktur. compile/target 37.0/37, AGP 9.2.0, Gradle 9.4.1,
JDK 17 ve Kotlin/Compose 2.2.10 korunur.

## Korunan ve geri bağlanan işlemler

Görsel düzenleme, kırpma, sıkıştırma, işaretleme, çerçeve, kolaj, gizleme ve EXIF
sıyırma; PDF bölme/düzenleme/birleştirme için eski araç pencereleri geri bağlanır.
Metin/Markdown, CSV/TSV ve SRT/VTT dönüşümleri gerçek UTF-8 kullanıcı içeriğini
okur. Orijinal örnek metni kaynak yerine kullanılamaz. Metin HTML'ye güvenli pre
olarak yazılır; tam Markdown render motoru değildir. Office hedefleri bu sınırlı
metin motorunun gerçek dönüşümü olarak gösterilmez.

Orijinal medya penceresi örnek ses/video açıyordu. Android adaptörü gerçek kullanıcı
Blob'unu bağlar ve örneğe fallback yapmaz. Desteklenen codec'lerde ses aralığı/
kanal/gizleme WAV çıktısı ve videodan PNG kare üretme korunur. Diğer medya/Office/
arşiv/QR seçeneklerinin bazıları özgün uygulamadaki gibi önizlemedir; bunlar gerçek
çıktı ekleyemez. Tam sınırlar KAPSAM.md'dedir.

PNG/JPEG/WebP, görsellerden A4 PDF, PDF sayfa seçme/birleştirme/döndürme ve gerçek
EPUB → PDF motorları korunur. Bunlar eski dönüşüm çarkına bağlanır. Ek Dönüşüm
ayarları paneli başlangıçta kapalıdır; PDF aralıkları/toplu işlemler için açılır.

## Veri, pencereler ve kaynak güvenliği

Dosya yönetimi sayfa içinde açılır; eski blur/backdrop hatası geri getirilmez.
Araç pencereleri aynı görsel stillerle ordinary DOM overlay kullanır. Kapanış,
medya temizliği, klavye ve inert/odak durumları korunur. İlk üç kart yüzen düzende,
daha büyük gruplar erişilebilir ızgaradadır. Aynı konumda veya konumsuz kaydedilmiş
0.6.0 girdileri ayrı kart konumları alır.

Grup geçişinde dosyalar korunur; aynı erbapp-files IndexedDB şeması ve yerel origin
kullanılır. Kaldırma uygulama kopyasını siler; telefon dosyasına yazılmaz. Native
kayıt bildirimleri kapalı dönüşüm panelinde gizlenmez. Kalıcı çıktı için Kaydet
ile Android kayıt ekranı tamamlanmalıdır. Kitaplık, eski arayüzdeki gibi oturum boyunca gerçek çıktıları tutar.

## Testler ve yayın

Yeni regresyonlar, klasik CSS/çark byte eşitliğini ve eski işleme kodunun dar
adaptörler dışında korunmasını zorunlu tutar. Metin gerçek içeriği, altyazıdaki
sayısal diyalog, CSV tırnak/yeni satır, orijinal WAV PCM çıktısı, çarkların
korunması, girdi konumları, sekmelerde saklama ve gerçek çıktı yönlendirmesi
kontrol edilir. Gerçek Chrome için klasik çark/araç penceresi senaryosu eklendi;
11 bağımsız senaryonun tümü yayın kapısıdır. Bir hata diğer sonuçları gizlemez.

Yerel Node/DOM testleri gerçek fiziksel WebView/SAF kabulü olarak sunulmaz. Yeni
APK compile/lint/JUnit, Chrome ve final apksigner sonucu CI bekler. Fiziksel cihaz
kontrolü ayrıca gerekir. Test araçları Playwright/pypdf/Pillow ürün bağımlılığı
değildir. Üç gömülü runtime/font (pdf-lib MIT, pako MIT/Zlib, DejaVu Vera/Arev) ve
Maven runtime lisans kapıları korunur; Nashi MIT tam bildirimi de pakettedir.

make_bootstrap.py küçük YAML ve ayrı SHA-256 kontrollü kaynak ZIP'i üretir.
Doğrulanmış kaynaklar eski CI Android checkout'unun yerine açılır. Sürüm/commit/
ZIP özeti raporda ve sürüm Actions başlığında görünür. Pages deploy işi yoktur.
ERBAPP_SIGNING değiştirilmez; applicationId=lab.zblash.nashi, aynı sertifika,
CI versionCode=1000+GITHUB_RUN_NUMBER. Güncelleme mevcut uygulamanın üzerine
kurulur. Bilgi bölümünde 0.6.1-personal yazmalıdır.
