# Erbapp Android

Kotlin/Compose/Material 3 Android kabuğu, yerel WebViewAssetLoader ve ortak dosya
araçları. Türkçe, koyu tema, API 26+, compile/target 37.0/37. AGP 9.2.0, Gradle
9.4.1, JDK 17 ve Kotlin/Compose 2.2.10 araç zinciri korunur. Hesap, reklam,
abonelik veya Android INTERNET/genel depolama izni yoktur.

## 0.5.2

Doğrudan Dosya dönüştür paneli gerçek PNG/JPEG/WebP, görsel PDF, PDF birleştirme,
sayfa seçme/döndürme ve EPUB → PDF üretir. Özgün Nashi örnek/önizleme menüleri
çalışan masaüstü dönüştürücülerin tamamı olarak sunulmaz. Desteksiz işlemler
kitaplığa sahte dosya ekleyemez. [KAPSAM.md](KAPSAM.md) tam sınırları açıklar.

Dosyaları yönet artık sayfa içinde açılır. Her sekme kendi dosyalarını tutar;
girdiler Blob kopyası olarak IndexedDB'ye kaydedilir. Kota/kayıt hatasında kullanıcı
bilgilendirilir. Kaynak URI'lere yazılmaz, kaldırma yalnız uygulama kopyasını siler.
Uygulama/tarayıcı verisini temizlemek bu kopyaları siler. Çıktıları kalıcı tutmak
ayrıca Kaydet'i tamamlamayı gerektirir. Cihazlar arasında dosya senkronizasyonu yoktur.

## Doğrulama

64 Python ve 50 Node testi yerelde geçti. Gerçek EPUB'dan 10 sayfa aranabilir PDF,
Türkçe metin, sıra, görsel ve gömülü font bağımsız okuyucuyla doğrulandı. Gerçek
PDF birleştir/sayfa seç/döndür de kontrol edildi. Görsel canvas çıktıları, gerçek
IndexedDB ve indirme için APK HTML Chrome senaryosu eklendi; henüz çalışmadı. Android
HTML senaryosu native köprü yanıtını taklit eder, gerçek SAF testi değildir.

0.5.2 APK derlemesi ve fiziksel telefon sonucu henüz doğrulanmadı. Yeni CI sonuçları
bu sürüm için zorunludur. [ASAMA-RAPORU.md](ASAMA-RAPORU.md) kanıt sınırlarını açıklar.

## Derleme ve yayın

Mevcut deponun docs/, LICENSE ve Resources/licenses/pdf-lib.txt dosyaları gerekir.
Küçük başlangıç YAML dosyası, yanında .github/workflows/erbapp-android-sources.zip
olarak yüklenen kaynakları SHA-256 denetimiyle CI klasörüne açar; depoya otomatik commit yazmaz. Depoda android/app/build.gradle.kts
varsa versioned kaynaklar kullanılır. Normal kaynaklarla gelişim için bu android/
klasörü ve standart .github/workflows/nashi-android.yml depoya eklenebilir.

CI: Node/Python testleri, Android/Maven ve web/font lisans denetimi, Kotlin/JUnit/
lint/build, ortak kaynak hash karşılaştırması, APK arayüzü Chrome senaryosu, bağımsız
çıktı içerik doğrulaması, sabit APK imzası ve compiled manifest kontrolü.
Başarılı işten erbapp-apk; raporlar erbapp-test-raporlari artifact'inde bulunur.
Bu akış web sitesi üretmez veya Pages yayını yapmaz. Pages izni/ayarına ihtiyaç yoktur.

[ANDROID-KURULUM.md](../ANDROID-KURULUM.md) ve [SIGNING.md](SIGNING.md) kurulum/güncelleme
adımlarını açıklar. Mevcut ERBAPP_SIGNING korunur. Aynı paket ve artan CI versionCode
ile uygulamanın üzerine kurulur; workflow çalışması telefondaki APK'yı kendiliğinden
güncellemez. Bilgi bölümünde 0.5.2-personal görülmelidir.

## Kaynak düzeni

- shared-ui/: dosya alanı, gerçek converter/EPUB motoru, UI ve pencere yaşam döngüsü.
- scripts/*_hook.js: özgün playground'a dar state/UI adaptörleri; çekirdek kaynak
  dosyası üzerine yazılmaz, paketleme kopyasında uygulanır.
- vendor/: değiştirilmemiş pako inflate, DejaVu Sans ve SHA/lisans manifesti.
- app/src/main/assets/mobile/mobile.js: yalnız Android Blob/SAF köprüsü.
- scripts/prepare_web.py: internetten indirmeden web ve APK varlıklarını üretir.

Pako ZIP açma sınırları, EPUB XML/script güvenliği ve PDF Unicode adapteri testlidir.
Font adapteri yalnız bundled TrueType fontu, basit Latin/Yunanca/Kiril yerleşimi
ve pdf-lib 1.17.1 API'si içindir. Karmaşık yazı şekillendirme yapmaz. EPUB sayfa
stili yeniden kurulur; CSS tasarımı, SVG veya uzaktaki görseller kopyalanmaz.

## Android'e bağımsız yayın

0.5.2'de Pages job, web-site build ve web/APK hash eşitliği yayın koşulu kaldırıldı.
UI kabulü --android-only ile yalnız APK içine gerçekten paketlenen varlıklarda
çalışır. PNG/PDF içerik kontrolü bu senaryoyu zorunlu tutar. Dosya araçları, sabit
imza, Android/Maven ve gömülü runtime lisans kontrolleri korunur. Web hazırlama
fonksiyonu isteğe bağlı kaynak aracı olarak kalır; Android akışında çağrılmaz.

## Workflow boyutu düzeltmesi

GitHub'ın workflow dosya sınırı 500 KB'dır. Kaynaklar artık YAML içinde base64
olarak taşınmaz. make_bootstrap.py küçük nashi-android.yml ve ayrı
 erbapp-android-sources.zip üretir; ikisi birlikte .github/workflows/ klasörüne
 yüklenir. ZIP yalnız android/ kaynaklarıdır. Tam SHA-256 eşleşmeden açılmaz.
Üretici ayrıca YAML'ın 500000 byte altında olduğunu zorunlu kontrol eder.
Yeni regresyon testleri gerçek font dahil kaynakları, workflow boyutunu, eksik
ve değiştirilmiş ZIP'i ve tam kaynak açılımını kontrol eder.
