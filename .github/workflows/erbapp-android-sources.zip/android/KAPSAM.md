# Erbapp 0.5.4 kapsamı ve kanıt düzeyi

Bu sürüm, Nashi web playground'unu bütün masaüstü araçları çalışan Android uygulaması
olarak sunmaz. Dosya dönüştür paneli yalnız gerçek çıktı üreten aşağıdaki işlemleri
sunar. Önizleme sonucu kitaplığa dosya gibi eklenmez.

| İşlem | Uygulanan davranış | Bu ortamda doğrulama | Yeni CI/cihaz sonucu |
| --- | --- | --- | --- |
| PNG/JPEG/WebP üretme | Seçilen gerçek görseli canvas ile yeniden kodlar | UI yönlendirmesi ve hata akışı test edildi | #13'te PNG pikseli ve byte aktarımı geçti; JPEG sırasında test bekleme/CSP hatası; tam kabul bekliyor |
| Görsellerden PDF | Her görseli A4 sayfaya oranını koruyarak yerleştirir | Kaynak/sözdizimi kontrolü | Gerçek PDF/görsel içeriği Chrome+pypdf testi bekliyor |
| PDF birleştirme | Seçilen PDF'lerin tüm sayfalarını sırayla kopyalar | Gerçek PDF'lerle sayfa sayısı/sırası doğrulandı | Android HTML ve SAF bekliyor |
| PDF sayfa seçme/bölme | Örn. 1-3,5 aralığını tek yeni PDF'ye çıkarır | Gerçek PDF'de seçilen sayfalar doğrulandı | Android HTML ve SAF bekliyor |
| PDF döndürme | Seçilen PDF'nin tüm sayfalarını 90/180/270 döndürür | Gerçek çıktının rotation değerleri ve özgün dosya kontrol edildi | Android HTML ve SAF bekliyor |
| EPUB → PDF | OPF spine sırası, Türkçe/Latin metin, başlıklar, PNG/JPEG ve kapak; aranabilir PDF | Gerçek EPUB'dan 10 sayfa PDF, Türkçe metin, sıra, görsel, gömülü font doğrulandı | Browser DOMParser/indirme ve fiziksel Android bekliyor |
| Dosyaları yönet | Sayfa içi liste, tek kopyayı kaldırma, onaylı temizleme | Gerçek controller/state olayları ve kalıcı silme işareti test edildi | Gerçek IndexedDB/UI Chrome testi bekliyor |
| Sekmeler ve yeniden açılış | Her grubun dosyalarını korur, sahip olunan Blob kopyasını IndexedDB'ye yazar | Sekme/yeniden yükleme modeli, kayıt hatası/race ve silme işareti test edildi | Gerçek IndexedDB/Android kabulü bekliyor |
| Android kaydet/paylaş | Mevcut parçalı köprü + ACTION_CREATE_DOCUMENT/FileProvider | Byte eşitliği, sıra, hata ve kaydet sonucu mesajları test edildi | Gerçek Android SAF ve fiziksel cihaz sonucu bekliyor |
| Video, ses, arşiv, Office, QR ve diğer masaüstü araçları | Yeni dönüştür panelinde gerçek destek verilmez; özgün örnek/önizleme menüleri tamamlanmış sayılmaz | Desteksiz işlem gerçek dosya/kitaplık sonucu üretemez | Geliştirilmesi gerekiyor |

EPUB desteği DRM'siz, yeniden akışlı kitaplar içindir. CSS/sayfa tasarımı, bağlantılar,
özel fontlar ve karmaşık tablolar birebir korunmaz. SVG/uzak görseller alınmaz ve
raporlanır. Sağdan sola/karmaşık yazı şekillendirme, fontta bulunmayan karakterler,
şifreli veya fontu gizlenmiş EPUB ve sabit mizanpaj açık hata verir. Tek EPUB 25 MB;
açılmış ZIP toplamı 64 MB, tek girdi 12 MB, 3000 girdi, metin 2 milyon karakter,
PDF 800 sayfa/64 MB ile sınırlıdır. PNG iç görseli en fazla 12 megapikseldir.

Görsel girdileri PNG/JPEG/WebP/GIF/BMP'dir; GIF yeniden kodlaması tek kare içindir.
HEIC/TIFF/AVIF gibi örnek menülerde görünen başka biçimler bu panelin gerçek girdi
listesinde değildir. Yeni dosyalar kaynak dosyaların üzerine yazılmaz.

Kayıtlı girdiler uygulama/tarayıcı verisi silinirse kaybolur. IndexedDB veya kota
hatasında oturum içi koruma sürer ve kullanıcı bilgilendirilir. Çıktı kitaplığı
bu oturuma aittir; kalıcı çıktı için Kaydet tamamlanmalıdır. APK kendi yerel arayüzünü içinde taşır; web yayınıyla eşzamanlı olmak zorunda değildir; cihazlar arasında dosya senkronizasyonu yoktur.
