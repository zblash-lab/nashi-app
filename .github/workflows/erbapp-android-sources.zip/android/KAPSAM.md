# Erbapp 0.6.0 Android kapsamı

APK, Android'e özel yerel bir ekran kullanır. Web sitesiyle senkronizasyon ve
orijinal playground'un örnek/önizleme menüleri yoktur. Kotlin/Compose kabuğu ve
çevrimdışı WebView işlem motoru kullanılır; tümü native Kotlin motoruna çevrilmiş
bir uygulama olduğu iddia edilmez.

| İşlem | Davranış | Yerel kanıt | Bekleyen |
| --- | --- | --- | --- |
| PNG/JPEG/WebP | Gerçek görseli yeniden kodlar; JPEG beyaz arka plan kullanır | Gerçek motor native canvas adaptörüyle çıktı üretti; Pillow piksel/biçim/boyut okudu | Chrome ve telefon |
| Görsel → PDF | A4 sayfaya oranını koruyarak yerleştirir | Gerçek motor çıktısında pypdf bir sayfa ve gömülü görsel doğruladı | Chrome ve telefon |
| PDF sayfa seçme | 1-3,5 gibi aralığı tek yeni PDF'ye çıkarır | Gerçek çıktıda sayfa ölçüsü, metni ve sırası doğrulandı | Chrome ve telefon |
| PDF birleştirme | Seçili PDF'lerin sayfalarını sırasıyla ekler | Gerçek çıktıda A'nın üç, B'nin iki sayfası doğru sırada okundu | Chrome ve telefon |
| PDF döndürme | Tüm sayfalara 90/180/270 derece ekler | Gerçek çıktıda üç sayfa, metin ve 90 derece doğrulandı | Chrome ve telefon |
| EPUB → PDF | OPF spine, Türkçe/Latin metin, başlıklar, PNG/JPEG ve kapak; aranabilir metin | Gerçek EPUB'dan 10 sayfa PDF; pypdf ile Türkçe, sıra, görsel, özgün tam font doğrulandı | Chrome DOMParser ve telefon |
| Dosya yönetimi | Tek kopyayı kaldırma ve onaylı liste temizleme; bulanık modal yok | Gerçek controller olayları ve sahip olunan URL'nin bırakılması test edildi | Gerçek IDB/telefon |
| Sekmeler ve kayıt | Grup bazlı dosyalar ve IndexedDB'de Blob kopyaları | Controller/çalışma alanı testleri; kayıt hatası, silme işareti, sekme geçişi | Gerçek IDB/telefon |
| Kaydet/paylaş | ACTION_CREATE_DOCUMENT ve FileProvider; kaynak URI'lere yazılmaz | Parçalı JS aktarımında byte/sıra/hata testleri; eski CI'da Kotlin derlemesi | Yeni APK imzası ve fiziksel SAF/paylaş |
| Video, ses, arşiv, Office, QR ve gelişmiş metadata | Bu sürümde sunulmaz | Örnek/önizleme menüleri APK'da bulunmaz | Ayrı geliştirme gerekiyor |

Görsel girdileri PNG/JPEG/WebP/GIF/BMP'dir. GIF tek kare olarak yeniden kodlanır.
HEIC/TIFF/AVIF desteği yoktur. Tek girdi 25 MB; toplam girdi alanı 75 MB ve grup
başına 12 dosya. Görsel işlem limiti 24 megapiksel; tek çıktı en fazla 64 MB.

EPUB desteği DRM'siz, yeniden akışlı metin kitapları içindir. CSS tasarımı, bağlantılar,
özel fontlar ve karmaşık tablolar birebir korunmaz. SVG/uzak görseller alınmaz ve
raporlanır. Sağdan sola/karmaşık yazı şekillendirme, fontta olmayan karakterler,
şifreli/obfuscated fontlu EPUB ve sabit mizanpaj açık hata verir. EPUB ZIP açılımı
toplam 64 MB, tek girdi 12 MB, 3000 arşiv girdisi, 2 milyon karakter ve 800 PDF
sayfasıyla sınırlıdır. EPUB içindeki PNG görsel en fazla 12 megapikseldir.

Kaldırma yalnız uygulama kopyasını siler; orijinal telefon dosyası korunur. Uygulama
verilerini temizlemek girdileri kaldırır. Kota/IndexedDB hatasında oturum içi koruma
sürer ve durum metni gösterilir. Çıktılar kitaplıkta oturum boyunca, en fazla altı
adet/96 MB tutulur; kalıcılık için Kaydet tamamlanmalıdır. Cihazlar arası eşitleme yoktur.

Bu doküman yeni APK'nın CI ve fiziksel cihaz kabulünün tamamlandığı anlamına gelmez.
