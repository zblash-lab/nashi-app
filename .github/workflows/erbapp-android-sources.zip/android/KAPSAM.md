# Erbapp 0.6.1 — klasik arayüz ve gerçek işlev kapsamı

Klasik Nashi görünümü geri getirildi. Görseller, Video, Ses, PDF, Belgeler,
Tablolar, Sunumlar, EPUB, Altyazı ve Arşivler sekmeleri; yüzen kartlar, çarklar,
kitaplık ve eski araç pencereleri korunur. Arayüzün dosyaları APK içindedir,
web sitesiyle eşitleme gerekmez. Bir menünün görünmesi, masaüstündeki bütün
motorların Android'e taşındığı anlamına gelmez.

| Araç | Davranış / sınır | Kanıt düzeyi |
| --- | --- | --- |
| Görsel dönüştürme | Gerçek PNG/JPEG/WebP ve görselden A4 PDF | Gerçek motor çıktıları bağımsız okuyucuyla kontrol edildi; yeni Chrome/telefon bekliyor |
| Eski görsel araçları | Düzenleme, kırpma, sıkıştırma, çerçeve, işaretleme, kolaj, gizleme, PNG'ye yeniden kodlayarak EXIF sıyırma | Eski motor kodu korunur; yeni Chrome çark/editor senaryosu eklendi; her aracın fiziksel kabulü bekliyor |
| PDF | Eski bölme/düzenleme/birleştirme pencereleri; ek panelde sayfa seçme/birleştirme/döndürme | Yeni motor PDF'leri metin/sıra/ölçü/açıyla doğrulandı; eski editor kaynakları korundu; telefon bekliyor |
| EPUB → PDF | OPF spine, Türkçe/Latin metin, PNG/JPEG, aranabilir metin ve tam font gömme | Yerelde gerçek EPUB'dan 10 sayfa PDF bağımsız pypdf ile doğrulandı; Chrome/telefon bekliyor |
| TXT/Markdown | Gerçek UTF-8 içeriği TXT/MD/HTML'ye yazar; HTML güvenli pre metnidir | Gerçek kullanıcı metni, UTF-8 hatası ve kaynak değişmezliği test edildi; tam Markdown render motoru yok |
| CSV/TSV | Tırnak, kaçış, ayraç ve gömülü yeni satırları işler | Gerçek veri round-trip testi; Office tablolarına dönüştürmez |
| SRT/VTT | Gerçek cue ve zamanları dönüştürür; TXT'ye diyalog çıkarır | Türkçe ve sayısal diyalog korunumu test edildi |
| Ses | Desteklenen codec'lerde aralık kesme, kanal ayarı ve gizleme WAV üretir | Orijinal WAV PCM motorunun örnek/süre/kanal/gain çıktısı test edildi; gerçek WebView decode/telefon bekliyor |
| Video | Desteklenen codec'te gerçek dosya önizlemesi ve PNG kare çıkarma kodu korunur | Örnek video yerine kullanıcı Blob'u bağlandı; gerçek codec/kare yakalama CI/telefon kabulü henüz yok |
| Diğer medya/Office/arşiv/QR | Eski menü ve pencereler geri getirildi; birçok seçenek önizleme olarak kalır | Null/örnek sonuç gerçek dosya olarak kitaplığa eklenemez; bütün masaüstü motorları tamamlanmış sayılmaz |
| Dosya yönetimi | Sayfa içinde kaldırma/onaylı temizleme, grup bazlı koruma ve IndexedDB kopyaları | Controller/kayıt/sekme/silme işareti testleri; gerçek IDB/telefon kabulü bekliyor |
| Native Kaydet/Paylaş | Yeni kopya SAF ile kaydedilir, FileProvider ile paylaşılır | JS byte/sıra/hata/bildirim testleri; fiziksel SAF ve Paylaş bekliyor |

Görsel girdileri PNG/JPEG/WebP/GIF/BMP; GIF tek karedir. HEIC/TIFF gibi biçimlerin
menüde görünmesi Android decoder desteği anlamına gelmez. Ses/video desteği
cihazın WebView codec'lerine bağlıdır. Metin motoru UTF-8 ve 5 MB ile sınırlıdır.

Girdi başına 25 MB, toplam 75 MB, kategori başına 12 dosya; görsel 24 megapiksel,
çıktı başına 64 MB. Kitaplık eski arayüzdeki gibi oturum içindir. Kalıcı
çıktı için Kaydet gerekir. Kaynak telefon dosyaları değiştirilmez. Uygulama
verilerini temizlemek girdi kopyalarını siler. Cihazlar arası senkronizasyon yoktur.

EPUB DRM'siz ve yeniden akışlı metin kitapları içindir. Özel CSS/tasarım, SVG,
uzak kaynak, karmaşık tablolar, RTL/karmaşık şekillendirme ve şifreleme tam
karşılanmaz. Sınırlar: ZIP açılımı toplam 64 MB, tek girdi 12 MB, 3000 arşiv girdisi,
2 milyon karakter, 800 PDF sayfası; iç PNG görsel 12 megapiksel.

Bu doküman yeni APK'nın tam CI ve fiziksel cihaz kabulünün tamamlandığı anlamına
gelmez. Klasik görünüme dönüş, desteklenmeyen bir motoru tamamlanmış yapmaz.
