import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import org.gradle.api.file.DirectoryProperty
import org.gradle.api.tasks.OutputDirectory
import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.plugin.compose")
}
val erbappVersion = Properties().apply {
    rootProject.file("version.properties").inputStream().use { load(it) }
}
val erbappCiRun = providers.environmentVariable("GITHUB_RUN_NUMBER").orNull?.toIntOrNull()
android {
    namespace = "lab.zblash.nashi"
    compileSdk {
        version = release(37) { minorApiLevel = 0 }
    }
    defaultConfig {
        applicationId = "lab.zblash.nashi"
        minSdk = 26
        targetSdk = 37
        versionCode = erbappCiRun?.let { erbappVersion.getProperty("ciVersionCodeBase").toInt() + it }
            ?: erbappVersion.getProperty("localVersionCode").toInt()
        versionName = erbappVersion.getProperty("versionName")
    }
    buildFeatures { compose = true; buildConfig = true }
    // Keep the tested variant; the final APK is re-signed with the persistent key.
    buildTypes { getByName("debug") { isDebuggable = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
kotlin { compilerOptions { jvmTarget.set(JvmTarget.JVM_17) } }

abstract class PrepareAndroidAssets : Exec() {
    @get:OutputDirectory
    abstract val outputDirectory: DirectoryProperty
}

val prepareAndroid by tasks.registering(PrepareAndroidAssets::class) {
    inputs.dir(rootProject.layout.projectDirectory.dir("app-ui"))
    inputs.dir(rootProject.layout.projectDirectory.dir("scripts"))
    inputs.dir(rootProject.layout.projectDirectory.dir("shared-ui"))
    inputs.dir(rootProject.layout.projectDirectory.dir("vendor"))
    inputs.file(rootProject.layout.projectDirectory.file("version.properties"))
    inputs.file(layout.projectDirectory.file("src/main/res/drawable-nodpi/erbapp_logo.jpg"))
    inputs.property("erbappCiRun", providers.environmentVariable("GITHUB_RUN_NUMBER").orElse("local"))
    inputs.property("erbappCommit", providers.environmentVariable("GITHUB_SHA").orElse("local"))
    inputs.file(rootProject.layout.buildDirectory.file("reports/license-audit.json"))
    inputs.file(rootProject.layout.projectDirectory.file("LICENSE"))
    inputs.dir(rootProject.layout.projectDirectory.dir("licenses"))
    outputDirectory.set(layout.buildDirectory.dir("generated/nashiAssets"))
    commandLine("python3", rootProject.file("scripts/prepare_android.py").absolutePath,
        "--android-root", rootProject.file(".").absolutePath,
        "--output", outputDirectory.get().asFile.absolutePath)
}
androidComponents {
    onVariants(selector().all()) { variant ->
        variant.sources.assets?.addGeneratedSourceDirectory(
            prepareAndroid, PrepareAndroidAssets::outputDirectory
        )
    }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2025.10.00"))
    implementation("androidx.activity:activity-compose:1.11.0")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.webkit:webkit:1.14.0")
    testImplementation("junit:junit:4.13.2")
}

// Export exactly the resolved runtime set; the CI audit fails on unknown licenses.
tasks.register("exportRuntimeComponents") {
    doLast {
        val components = configurations.getByName("debugRuntimeClasspath")
            .resolvedConfiguration.resolvedArtifacts.map { artifact ->
                val id = artifact.moduleVersion.id
                mapOf("group" to id.group, "name" to id.name, "version" to id.version,
                    "file" to artifact.file.absolutePath)
            }.distinctBy { it["group"] + ":" + it["name"] + ":" + it["version"] }
        val report = layout.buildDirectory.file("reports/runtime-components.json").get().asFile
        report.parentFile.mkdirs()
        report.writeText(groovy.json.JsonOutput.prettyPrint(groovy.json.JsonOutput.toJson(components)))
    }
}
