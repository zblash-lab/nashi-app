package lab.zblash.nashi

import org.junit.Assert.*
import org.junit.Test

class ExportPolicyTest {
    @Test fun bounds() {
        assertTrue(ExportPolicy.validSize(0))
        assertTrue(ExportPolicy.validSize(ExportPolicy.MAX_BYTES))
        assertFalse(ExportPolicy.validSize(-1))
        assertFalse(ExportPolicy.validSize(ExportPolicy.MAX_BYTES + 1))
    }
    @Test fun fileNamesCannotEscapeTheExportDirectory() {
        assertFalse(ExportPolicy.name("../../a/b\\c.pdf").contains('/'))
        assertFalse(ExportPolicy.name("../../a/b\\c.pdf").contains('\\'))
        assertEquals("nashi-cikti", ExportPolicy.name("..."))
        assertEquals("a_b.txt", ExportPolicy.name("a\u0000b.txt"))
    }
    @Test fun invalidMimeFallsBackToBinary() {
        assertEquals("application/pdf", ExportPolicy.mime("application/pdf"))
        assertEquals("application/octet-stream", ExportPolicy.mime("text/html\r\nX-Evil: 1"))
    }
}
