package lab.zblash.nashi

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContract
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

private const val ORIGIN = "https://appassets.androidplatform.net"
private const val HOME = "$ORIGIN/assets/web/tr/index.html#playground"
private const val NOTICES = "$ORIGIN/assets/mobile/licenses.html"

private class CreateOutput : ActivityResultContract<LocalExport, Uri?>() {
    override fun createIntent(context: Context, input: LocalExport) = Intent(Intent.ACTION_CREATE_DOCUMENT)
        .addCategory(Intent.CATEGORY_OPENABLE).setType(input.mime)
        .putExtra(Intent.EXTRA_TITLE, input.name)
    override fun parseResult(resultCode: Int, intent: Intent?): Uri? =
        if (resultCode == Activity.RESULT_OK) intent?.data else null
}

@OptIn(ExperimentalMaterial3Api::class)
class MainActivity : ComponentActivity() {
    private val io = Executors.newSingleThreadExecutor()
    private val savePending = AtomicBoolean(false)
    private lateinit var exports: ExportStore
    private lateinit var incoming: IncomingStore
    private var web: WebView? = null
    private var loaded = false
    private var pendingImports: String? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var multipleFiles = false
    private var pendingExport: LocalExport? = null
    private var latest by mutableStateOf<LocalExport?>(null)
    private var about by mutableStateOf(false)
    private var supported by mutableStateOf(true)

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val result = if (multipleFiles) uris.take(20) else uris.take(1)
        fileCallback?.onReceiveValue(result.takeIf { it.isNotEmpty() }?.toTypedArray())
        fileCallback = null
    }
    private val writer = registerForActivityResult(CreateOutput()) { uri ->
        val output = pendingExport
        pendingExport = null
        if (uri == null || output == null) {
            savePending.set(false)
            message(if (uri == null) R.string.save_cancelled else R.string.save_failed)
            saveStatus(if (uri == null) "cancelled" else "failed")
        } else io.execute {
            val success = runCatching {
                check(output.file.isFile)
                checkNotNull(contentResolver.openOutputStream(uri, "wt")).use { destination ->
                    output.file.inputStream().use { source -> source.copyTo(destination) }
                }
            }.isSuccess
            savePending.set(false)
            runOnUiThread {
                if (!isDestroyed) {
                    message(if (success) R.string.saved else R.string.save_failed)
                    saveStatus(if (success) "saved" else "failed")
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        exports = ExportStore(this) { savePending.get() }
        incoming = IncomingStore(this)
        io.execute { exports.cleanup() }
        savedInstanceState?.let { state ->
            latest = restoreExport(state, "last")
            pendingExport = restoreExport(state, "pending")
            savePending.set(pendingExport != null)
        }
        supported = WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Color(0xffe7c46d), background = Color(0xff101e17), surface = Color(0xff101e17))) {
                Scaffold(topBar = {
                    TopAppBar(title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Image(painterResource(R.drawable.erbapp_logo), contentDescription = null,
                                modifier = Modifier.size(28.dp).clip(RoundedCornerShape(7.dp)))
                            Spacer(Modifier.width(10.dp))
                            Text(stringResource(R.string.app_name))
                        }
                    }, actions = {
                        TextButton(onClick = { latest?.let(::share) }, enabled = latest != null) { Text(stringResource(R.string.share)) }
                        TextButton(onClick = { about = true }) { Text(stringResource(R.string.about)) }
                    })
                }) { padding ->
                    if (supported) AndroidView(
                        modifier = Modifier.fillMaxSize().padding(padding),
                        factory = { createWebView() }
                    ) else Text(stringResource(R.string.webview_old), Modifier.padding(padding))
                }
                if (about) AlertDialog(onDismissRequest = { about = false },
                    title = { Text(stringResource(R.string.app_name)) },
                    text = { Text("Sürüm ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})\n\n" + stringResource(R.string.about_text)) },
                    confirmButton = { TextButton(onClick = { about = false; web?.loadUrl(NOTICES) }) { Text(stringResource(R.string.licenses)) } },
                    dismissButton = { TextButton(onClick = { about = false }) { Text(stringResource(R.string.close)) } })
                BackHandler {
                    web?.evaluateJavascript("window.NashiMobile?.back?.() === true") { consumed ->
                        if (consumed != "true") {
                            if (web?.canGoBack() == true) web?.goBack() else finish()
                        }
                    } ?: finish()
                }
            }
        }
        acceptSharedIntent(intent)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(): WebView {
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/incoming/") { token -> runCatching { incoming.response(token) }.getOrNull() }
            .build()
        return WebView(this).apply {
            web = this
            setBackgroundColor(android.graphics.Color.rgb(16, 30, 23))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            // Required to read user-selected SAF content URIs; no file:// access.
            settings.allowContentAccess = true
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.mediaPlaybackRequiresUserGesture = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.safeBrowsingEnabled = true
            CookieManager.getInstance().setAcceptCookie(false)
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, false)
            WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)
            if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
                WebViewCompat.addWebMessageListener(this, "NashiNative", setOf(ORIGIN)) { view, payload, source, mainFrame, reply ->
                    if (!mainFrame || (source.scheme != "https" || source.host != "appassets.androidplatform.net" || source.port !in setOf(-1, 443)) || payload.data == null) return@addWebMessageListener
                    val raw = payload.data!!
                    io.execute {
                        val parsed = runCatching { JSONObject(raw) }.getOrNull()
                        if (parsed?.optString("type") == "importComplete") {
                            parsed.optJSONArray("tokens")?.let(incoming::remove)
                            val response = JSONObject().put("token", parsed.optString("token")).put("ok", true).toString()
                            view.post { if (!isDestroyed) reply.postMessage(response) }
                        } else {
                            val result = exports.receive(raw)
                            if (result.completed != null) savePending.set(true)
                            view.post {
                                if (!isDestroyed) {
                                    reply.postMessage(result.json)
                                    result.completed?.let { output ->
                                        latest = output; pendingExport = output
                                        try { writer.launch(output) } catch (_: ActivityNotFoundException) {
                                            savePending.set(false); pendingExport = null; message(R.string.save_failed)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse {
                    val uri = request.url
                    if (uri.scheme == "https" && uri.host == "appassets.androidplatform.net") {
                        val response = loader.shouldInterceptRequest(uri)
                        if (response != null) {
                            if (uri.path?.endsWith(".mjs") == true || uri.path?.endsWith(".js") == true) response.mimeType = "text/javascript"
                            return response
                        }
                    }
                    return WebResourceResponse("text/plain", "UTF-8", 403, "Blocked", emptyMap(), ByteArrayInputStream(ByteArray(0)))
                }
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val uri = request.url
                    if (uri.scheme == "https" && uri.host == "appassets.androidplatform.net" &&
                        uri.path?.startsWith("/assets/") == true) return false
                    if (request.isForMainFrame && request.hasGesture() && uri.scheme == "https") {
                        runCatching { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
                    }
                    return true
                }
                override fun onPageFinished(view: WebView, url: String) {
                    loaded = url.startsWith("$ORIGIN/assets/web/tr/index.html")
                    deliverImports()
                }
                override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                    if (request.isForMainFrame) message(R.string.web_error)
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(view: WebView, callback: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                    fileCallback?.onReceiveValue(null); fileCallback = callback
                    multipleFiles = params.mode == FileChooserParams.MODE_OPEN_MULTIPLE
                    // Some EPUB providers report application/octet-stream; the UI validates input format.
                    try { picker.launch(arrayOf("*/*")) }
                    catch (_: ActivityNotFoundException) { callback.onReceiveValue(null); fileCallback = null; message(R.string.file_picker_failed) }
                    return true
                }
            }
            setDownloadListener { _, _, _, _, _ -> message(R.string.save_failed) }
            loadUrl(HOME)
        }
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); acceptSharedIntent(intent) }
    @Suppress("DEPRECATION")
    private fun acceptSharedIntent(intent: Intent?) {
        if (intent?.action !in setOf(Intent.ACTION_SEND, Intent.ACTION_SEND_MULTIPLE)) return
        val uris: List<Uri> = if (intent?.action == Intent.ACTION_SEND_MULTIPLE)
            intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM).orEmpty()
        else listOfNotNull(intent?.getParcelableExtra<Uri>(Intent.EXTRA_STREAM))
        io.execute {
            val data = runCatching { incoming.copy(uris) }.getOrNull()
            runOnUiThread {
                if (!isDestroyed) {
                    if (data == null) message(R.string.shared_import_failed)
                    else { pendingImports = data; if (!loaded) web?.loadUrl(HOME); deliverImports() }
                }
            }
        }
    }
    private fun deliverImports() {
        val data = pendingImports ?: return
        if (!loaded) return
        pendingImports = null
        web?.evaluateJavascript("window.NashiMobile?.importFiles($data)", null)
    }
    private fun share(output: LocalExport) {
        runCatching {
            val uri = FileProvider.getUriForFile(this, "$packageName.files", output.file, output.name)
            val request = Intent(Intent.ACTION_SEND).setType(output.mime)
                .putExtra(Intent.EXTRA_STREAM, uri).putExtra(Intent.EXTRA_TITLE, output.name)
                .apply { clipData = ClipData.newUri(contentResolver, output.name, uri) }
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(request, getString(R.string.share_title)))
        }.onFailure { message(R.string.share_failed) }
    }
    private fun message(resource: Int) { Toast.makeText(this, resource, Toast.LENGTH_LONG).show() }
    private fun saveStatus(status: String) {
        web?.evaluateJavascript("window.NashiMobile?.saveResult?.(${JSONObject.quote(status)})", null)
    }
    override fun onSaveInstanceState(outState: Bundle) {
        fun put(prefix: String, output: LocalExport?) { output ?: return
            outState.putString("$prefix.file", output.file.name)
            outState.putString("$prefix.name", output.name)
            outState.putString("$prefix.mime", output.mime)
        }
        put("last", latest); put("pending", pendingExport)
        super.onSaveInstanceState(outState)
    }
    private fun restoreExport(state: Bundle, prefix: String): LocalExport? {
        val name = state.getString("$prefix.file") ?: return null
        if (!Regex("[a-f0-9-]{36}\\.[A-Za-z0-9]{1,10}").matches(name)) return null
        val file = File(cacheDir, "exports/$name").takeIf { it.isFile } ?: return null
        return LocalExport(file, ExportPolicy.name(state.getString("$prefix.name").orEmpty()),
            ExportPolicy.mime(state.getString("$prefix.mime").orEmpty()))
    }
    override fun onPause() { web?.onPause(); super.onPause() }
    override fun onResume() { super.onResume(); web?.onResume() }
    override fun onDestroy() {
        fileCallback?.onReceiveValue(null); fileCallback = null
        web?.stopLoading(); web?.destroy(); web = null
        io.execute { exports.abort(); incoming.clear() }; io.shutdown()
        super.onDestroy()
    }
}
