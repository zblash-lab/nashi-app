package lab.zblash.nashi

object ExportPolicy {
    const val MAX_BYTES = 64L * 1024 * 1024
    const val MAX_CHUNK = 48 * 1024
    fun validSize(size: Long): Boolean = size in 0..MAX_BYTES
    fun name(raw: String): String = raw
        .replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_")
        .trim().trimStart('.').take(160).ifBlank { "nashi-cikti" }
    fun mime(raw: String): String = raw.substringBefore(';').trim().takeIf {
        it.length <= 100 && Regex("[A-Za-z0-9!#$&^_.+-]+/[A-Za-z0-9!#$&^_.+-]+").matches(it)
    } ?: "application/octet-stream"
}
