package lab.zblash.nashi

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.WebResourceResponse
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class IncomingStore(private val context: Context) {
    private data class Item(val file: File, val name: String, val mime: String)
    private val items = ConcurrentHashMap<String, Item>()
    private val directory = File(context.cacheDir, "incoming").apply { mkdirs() }
    private val accepted = setOf("image/png", "image/jpeg", "image/webp", "image/gif", "image/bmp", "application/pdf", "application/epub+zip")
    init { directory.listFiles()?.forEach { it.delete() } }

    fun copy(uris: List<Uri>): String {
        require(uris.size in 1..5) { "Bir defada en fazla 5 dosya paylaşabilirsin." }
        var total = 0L
        val result = JSONArray()
        val created = mutableListOf<String>()
        try {
            for (uri in uris) {
                require(uri.scheme == "content") { "Yalnızca Android dosya sağlayıcıları desteklenir." }
                val mime = context.contentResolver.getType(uri).orEmpty()
                require(mime in accepted) { "Desteklenen görsel, PDF veya EPUB seç." }
                var name = "paylasilan-dosya"
                context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) name = cursor.getString(0) ?: name
                }
                val token = UUID.randomUUID().toString()
                val destination = File(directory, token)
                created += token
                val input = checkNotNull(context.contentResolver.openInputStream(uri))
                input.use { source -> destination.outputStream().use { output ->
                    val buffer = ByteArray(64 * 1024)
                    var size = 0L
                    while (true) {
                        val count = source.read(buffer)
                        if (count < 0) break
                        size += count; total += count
                        require(size <= 20 * 1024 * 1024 && total <= 50 * 1024 * 1024) { "Paylaşım boyutu sınırı aşıldı." }
                        output.write(buffer, 0, count)
                    }
                } }
                items[token] = Item(destination, ExportPolicy.name(name), mime)
                result.put(JSONObject().put("token", token).put("name", ExportPolicy.name(name)).put("mime", mime))
            }
            return result.toString()
        } catch (error: Exception) {
            created.forEach { token -> items.remove(token); File(directory, token).delete() }
            throw error
        }
    }
    fun response(token: String): WebResourceResponse? {
        val item = items[token] ?: return null
        return WebResourceResponse(item.mime, null, item.file.inputStream())
    }
    fun remove(tokens: JSONArray) {
        for (index in 0 until minOf(tokens.length(), 5)) items.remove(tokens.optString(index))?.file?.delete()
    }
    fun clear() { items.values.forEach { it.file.delete() }; items.clear() }
}
