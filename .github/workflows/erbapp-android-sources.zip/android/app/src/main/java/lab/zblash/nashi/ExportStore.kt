package lab.zblash.nashi

import android.content.Context
import android.util.Base64
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

data class LocalExport(val file: File, val name: String, val mime: String)
data class ExportReply(val json: String, val completed: LocalExport? = null)

/** Called only on the Activity's single IO executor. Never writes to source URIs. */
class ExportStore(context: Context, private val savePending: () -> Boolean) {
    private val directory = File(context.cacheDir, "exports").apply { mkdirs() }
    private var stream: FileOutputStream? = null
    private var active: LocalExport? = null
    private var expected = 0L
    private var written = 0L
    private var nextSequence = 0

    fun receive(raw: String): ExportReply {
        var token = ""
        return try {
            require(raw.length <= 70_000) { "Aktarım iletisi çok büyük." }
            val message = JSONObject(raw)
            token = message.getString("token").take(80)
            require(token.isNotBlank()) { "Geçersiz aktarım." }
            var completed: LocalExport? = null
            when (message.getString("type")) {
                "begin" -> {
                    check(stream == null && !savePending()) { "Önce açık kayıt işlemini tamamla." }
                    val size = message.getLong("size")
                    require(ExportPolicy.validSize(size)) { "Tek çıktı en fazla 64 MB olabilir." }
                    val name = ExportPolicy.name(message.getString("name"))
                    val extension = name.substringAfterLast('.', "bin").takeIf { Regex("[A-Za-z0-9]{1,10}").matches(it) } ?: "bin"
                    cleanup()
                    val output = LocalExport(File(directory, "${UUID.randomUUID()}.$extension"),
                        name, ExportPolicy.mime(message.optString("mime")))
                    active = output
                    stream = FileOutputStream(output.file)
                    expected = size; written = 0; nextSequence = 0
                }
                "chunk" -> {
                    val output = checkNotNull(stream) { "Aktarım başlatılmadı." }
                    require(message.getInt("sequence") == nextSequence) { "Aktarım sırası uyuşmuyor." }
                    val encoded = message.getString("data")
                    require(encoded.length <= 65_536 && encoded.isNotEmpty() &&
                        Regex("[A-Za-z0-9+/]*={0,2}").matches(encoded)) { "Geçersiz dosya parçası." }
                    val bytes = Base64.decode(encoded, Base64.NO_WRAP)
                    require(bytes.size <= ExportPolicy.MAX_CHUNK && written + bytes.size <= expected) {
                        "Dosya boyutu sınırı aşıldı."
                    }
                    output.write(bytes)
                    written += bytes.size; nextSequence++
                }
                "finish" -> {
                    checkNotNull(stream) { "Aktarım başlatılmadı." }
                    require(written == expected) { "Çıktı tamamlanamadı; yeniden dene." }
                    stream?.close(); stream = null
                    completed = checkNotNull(active); active = null
                }
                "abort" -> abort()
                else -> error("Bilinmeyen aktarım işlemi.")
            }
            ExportReply(JSONObject().put("token", token).put("ok", true).toString(), completed)
        } catch (error: Exception) {
            abort()
            ExportReply(JSONObject().put("token", token).put("ok", false)
                .put("error", error.message ?: "Dosya aktarılamadı.").toString())
        }
    }
    fun abort() {
        runCatching { stream?.close() }; stream = null
        active?.file?.delete(); active = null
    }
    fun cleanup() {
        val completed = directory.listFiles()?.filter { it != active?.file }?.sortedByDescending { it.lastModified() }.orEmpty()
        completed.forEachIndexed { index, file ->
            if (index >= 2 || System.currentTimeMillis() - file.lastModified() > 24 * 60 * 60 * 1000L) file.delete()
        }
    }
}
