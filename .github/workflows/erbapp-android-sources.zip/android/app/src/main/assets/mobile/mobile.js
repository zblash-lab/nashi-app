/* Native integration for the unmodified Nashi playground. No network service. */
(() => {
  'use strict';
  const MAX = 64 * 1024 * 1024, CHUNK = 48 * 1024;
  const pending = new Map();
  let sequence = 0, exporting = false, saveFeedback = 0;
  function status(text) {
    let box = document.getElementById('nashi-native-status');
    if (!box) {
      box = document.createElement('div'); box.id = 'nashi-native-status';
      box.setAttribute('role', 'status');
      (document.querySelector?.('.erbapp-real-tools') || document.body).append(box);
      box.scrollIntoView?.({block:'nearest'});
    }
    box.textContent = text;
  }
  function send(message) {
    return new Promise((resolve, reject) => {
      const token = 'nashi-' + (++sequence);
      const timer = setTimeout(() => {
        pending.delete(token); reject(new Error('Dosya aktarımı yanıt vermedi. Yeniden dene.'));
      }, 20000);
      pending.set(token, {resolve, reject, timer});
      try { window.NashiNative.postMessage(JSON.stringify({...message, token})); }
      catch (error) { clearTimeout(timer); pending.delete(token); reject(error); }
    });
  }
  if (!window.NashiNative) { status('Android System WebView’i güncelle.'); return; }
  window.NashiNative.onmessage = event => {
    let reply; try { reply = JSON.parse(event.data); } catch { return; }
    const handler = pending.get(reply.token); if (!handler) return;
    pending.delete(reply.token); clearTimeout(handler.timer);
    if (reply.ok) handler.resolve(); else handler.reject(new Error(reply.error || 'Dosya aktarılamadı.'));
  };
  async function exportBlob(url, name) {
    if (exporting) { status('Önce devam eden aktarımın bitmesini bekle.'); return; }
    exporting = true;
    const feedbackAtStart = saveFeedback;
    try {
      const blob = await (await fetch(url)).blob();
      if (blob.size > MAX) throw new Error('Tek çıktı en fazla 64 MB olabilir.');
      await send({type:'begin', name: name || 'nashi-cikti', mime: blob.type || 'application/octet-stream', size:blob.size});
      for (let offset=0, part=0; offset<blob.size; offset+=CHUNK, part++) {
        const bytes = new Uint8Array(await blob.slice(offset, offset+CHUNK).arrayBuffer());
        let text=''; for(let p=0;p<bytes.length;p+=8192) text+=String.fromCharCode(...bytes.subarray(p,p+8192));
        await send({type:'chunk',sequence:part,data:btoa(text)});
        status('Yeni kopya hazırlanıyor · %'+Math.round(Math.min(blob.size,offset+CHUNK)/Math.max(1,blob.size)*100));
      }
      await send({type:'finish'});
      if(saveFeedback===feedbackAtStart)status('Yeni kopyan hazır. Android kayıt penceresinden hedef seç.');
    } catch (error) {
      try { await send({type:'abort'}); } catch {}
      status(error.message || 'Dosya kaydedilemedi.');
    } finally { exporting=false; }
  }
  document.addEventListener('click', event => {
    const link = event.target.closest?.('a[download]');
    if (!link || !link.href.startsWith('blob:'+location.origin+'/')) return;
    event.preventDefault(); event.stopImmediatePropagation();
    exportBlob(link.href,link.download);
  }, true);
  window.NashiMobile = {
    saveResult(result) {
      saveFeedback++;
      status(result==='saved'?'Yeni kopya kaydedildi. Kaynak dosyan değişmedi.':result==='cancelled'?'Kaydetme iptal edildi. Çıktıyı Kaydet bağlantısından yeniden deneyebilirsin.':'Kayıt başarısız. Başka bir klasör seçerek yeniden dene veya üstteki Paylaş düğmesini kullan.');
    },
    async importFiles(files) {
      try {
        let input;
        for(let attempt=0;attempt<150;attempt++) {
          input=document.querySelector('#playground input[type=file]');
          if(input)break; await new Promise(resolve=>setTimeout(resolve,100));
        }
        if(!input)throw new Error('Dosya seçici hazırlanamadı. Uygulamadan yeniden seç.');
        const transfer=new DataTransfer();
        for(const file of files) {
          if(!/^[a-f0-9-]{36}$/.test(file.token))throw new Error('Geçersiz paylaşım.');
          const response=await fetch('/incoming/'+file.token);
          if(!response.ok)throw new Error('Paylaşılan dosya okunamadı.');
          transfer.items.add(new File([await response.blob()],file.name,{type:file.mime}));
        }
        input.files=transfer.files; input.dispatchEvent(new Event('change',{bubbles:true}));
        status('Paylaşılan dosyalar seçildi. Bir işlem seçebilirsin.');
        await send({type:'importComplete',tokens:files.map(file=>file.token)});
      } catch(error) { status(error.message || 'Paylaşılan dosya alınamadı.'); }
    },
    back() {
      if(window.ErbappOverlay?.close())return true;
      if(window.ErbappFileManager?.close())return true;
      const dialog=document.querySelector('dialog[open]');
      if(dialog){const close=dialog.querySelector('.close-editor');if(close){close.click();return true;}}
      if(document.querySelector('.demo-wheel')){document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true}));return true;}
      return false;
    }
  };
})();
