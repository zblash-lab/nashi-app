# Erbapp 0.5.2 doğrulama raporu

## Kullanıcı sorunları ve değişiklik

1. EPUB → PDF'nin yalnız önizleme olması: gerçek EPUB okuma/PDF üretme eklendi.
   ZIP bütünlük ve açılmış boyut kontrolü, container/OPF/spine, XHTML metni,
   PNG/JPEG/kapak ve Unicode font gömme uygulanır. Kaynak HTML/CSS/script çalıştırılmaz;
   dış kaynağa istek yapılmaz. PDF aranabilir metin taşır.
2. Dosyaları yönet düğmesi: modal kaldırıldı; sayfa içinde açılan liste kullanılır.
   Kaldır sonrası sayaç ve açık durum metni güncellenir. Kaynak dosya silinmez.
3. Sekme değişiminde dosya kaybı: özgün setGroup() her seferinde örnek listesi
   oluşturuyordu. Yerine grup bazlı çalışma alanı ve IndexedDB kayıtları eklendi.
   Girdi byte'ları uygulamanın Blob kopyasına alınır. Kaldırılan kayıtların geçici
   IndexedDB hatasında geri gelmesini önleyen yerel silme işaretleri vardır.
4. Dönüştürücülerin kullanılamaması: gerçek dosya/işlem/çıktı bağlantısı olan doğrudan
   Dosya dönüştür paneli eklendi. Gerçek araçlar PNG/JPEG/WebP, görsellerden PDF,
   PDF birleştir/sayfa seç/döndür ve EPUB → PDF'dir. Örnekler varsayılan yüklenmez.
   Önizleme çıktıları kitaplığa sahte dosya olarak eklenemez. Kartlar erişilebilir
   ızgarada gösterilir, birden fazla girdi üst üste binmez.

Genel araç/kitaplık pencereleri ortak DOM katmanını kullanır; kapanış medya/cleanup,
klavye, odak, scroll ve inert durumunu yönetir. Kitaplığın adı artık Kitaplık'tır.
Native Android seçici EPUB dahil dosya seçebilir; gelen paylaşım MIME listesine
EPUB eklendi. Bilgi bölümünde gerçek build sürümü görünür. Native kaydetmenin
başarı/iptal/hatası arayüzde kalıcı durum metnine iletilir. Sabit imza/paket korunur.

## Yerelde gerçekten doğrulanan

- 64 Python ve 50 JavaScript testi geçti.
- Üretilen gerçek EPUB PDF'si 10 sayfa. Bağımsız pypdf ile Türkçe ÇĞİÖŞÜ çğıöşü,
  bölüm sırası, son bölüm içeriği, gömülü görsel ve özgün gömülü font byte'ları
  doğrulandı. Fontun telif/lisans name tablosu PDF'ye değişmeden gömülür.
- Gerçek PDF birleştirme, sayfa seçimi ve döndürme; sayfa sayısı/ölçü/sıra/rotation
  ve kaynak byte değişmezliğiyle kontrol edildi.
- ZIP CRC hasarı, şifreli EPUB, merkezi/açılmış boyut uyuşmazlığı, dış/üst dizin
  yolları, iptal ve desteklenmeyen yazı düzeni test edildi. Sahte çıktı üretilmez.
- Dosya controller'ı, grup geçişi, kayıt hatası, devam eden kayıt sırasında sekme
  değişimi, yeniden açılış modeli ve başarısız silmede geri gelmeme test edildi.
  Bu Node testlerinde IndexedDB yerine kayıt adaptörü kullanılır; gerçek IDB sonucu
  olarak sunulmaz. UI yönlendirme testlerinde DOM/servis test çiftleri kullanılır.
- Android JavaScript köprüsünün gerçek chunk byte'ları, sıra, hata, boyut ve kaydet
  sonucu mesajları kontrol edildi. Kotlin/Android SAF çalıştırıldığı iddia edilmez.

## Yeni zorunlu CI kontrolleri — henüz çalıştırılmadı

Android-only Chrome senaryosu APK'ya gömülü HTML ve gerçek işleme kaynaklarını
kullanır. Web site build/deploy veya web/Android hash eşitliği yayın koşulu değildir.
Gerçek PNG pikseli, JPEG, görsel PDF, EPUB PDF, PDF sayfa seç/birleştir/döndür,
sekme geçişi, gerçek IndexedDB yeniden açılışı ve tamamlanmış silme kontrol edilir.
Gerçek kaydet linki ve parçalı JS köprüsü çalışır; native yanıtlar taklit edilir,
SAF ekranı taklit edilmez. Üretilen dosyalar bağımsız pypdf/PNG kontrolünden geçmeden
APK yayınlanmaz. Android-only kontrol boş/başarısız veya yalnız web sonucunu kabul
edemez; yeni üç Python regresyon testi bu kapsam seçimini kontrol eder.

Yerel ortamda Chrome soket/sandbox kısıtı ve SDK/Gradle eksikliği vardır.
0.5.2 Android compile/lint/JUnit, gerçek Chrome ve apksigner doğrulaması henüz
çalışmadı. Önceki #11 (0.4.2) başarısı yeni sürüm için kanıt değildir. Fiziksel
telefonda dosya seç/kaydet/paylaş ve uçak modu kabul testi ayrıca gereklidir.

## Lisans denetimi ve sınırlar

Android Maven runtime lisans denetimi korunur. Yeni web runtime pako inflate 1.0.11
(MIT ve Zlib) ve DejaVu Sans 2.37 (Bitstream Vera/Arev, DejaVu değişiklikleri public
domain) kaynakları mevcut yerel kurulumdan değiştirilmeden alındı. Tam bildirimler,
SHA-256 manifesti ve çevrimdışı audit eklendi. Her paketlemede hash ve lisans
bildirimleri doğrulanır; uygulama lisans sayfasına da kopyalanır. pypdf 6.10.0
(BSD-3-Clause) yalnız CI doğrulama aracıdır, ürüne eklenmez. Yeni Android Maven
runtime bağımlılığı yoktur. Kapsam/gerçek sınırlar KAPSAM.md içindedir.

versionName=0.5.2-personal, yerel versionCode=10;
CI versionCode=1000+GITHUB_RUN_NUMBER; package lab.zblash.nashi.
ERBAPP_SIGNING ve açık sertifika değişmedi. Logo byte raporu yayını engellemez.

## 0.5.2 yayın ayrımı

Kullanıcı web senkronizasyonunun gerekli olmadığını belirtti. Android workflow'u
tek apk job'a indirildi; Pages build/upload/deploy ve pages/id-token izinleri
kaldırıldı. Web sitesine doğrudan işlem yapılmadı. EPUB → PDF, dosya kaldırma,
kalıcı dosya çalışma alanı ve gerçek dönüştürücü düzeltmeleri korunur.
APK zaten yerel varlıklarla çevrimdışı çalışacak şekilde tasarlanmıştı; bu değişiklik
yayın sürecini ayırır. Dönüştürme hatalarının yalnız yayın ayrımıyla çözüldüğü
iddia edilmez. Yeni APK/Chrome/fiziksel cihaz doğrulaması bekliyor.

## 0.5.2 — GitHub 500 KB workflow sınırı

Kullanıcının #12 ekran görüntüsünde GitHub workflow'u boyut nedeniyle reddetti;
job/derleme başlamadı. Önceki generator 1 MB altında olmayı yeterli görmüştü;
gerçek sınır 500 KB olduğundan bu kontrol yanlıştı. Yeni generator kaynakları
YAML'a gömmez. Yaklaşık 7 KB YAML ve yaklaşık 550 KB kaynak ZIP'i ayrı üretilir.
İki dosya aynı .github/workflows klasörüne tek commit ile yüklenir. ZIP dosyası
workflow değildir; GitHub'ın YAML boyut sınırına dahil edilmez.

Kaynak ZIP'inin SHA-256 özeti YAML'a yazılır. Eksik veya değiştirilmiş ZIP kaynaklar
açılmadan reddedilir. Mutlak/üst dizin yolları ve symlink girdileri kabul edilmez.
Özel anahtar dosyası koruması sürer. Dört yeni paketleme testi geçti. Bu, APK'nın
derlendiği veya fiziksel telefonda çalıştığı anlamına gelmez; yeni CI bekliyor.
EPUB, dosya koruma ve gerçek converter kodu bu düzeltmede değiştirilmedi.
