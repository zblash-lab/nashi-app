/* Offline EPUB -> searchable PDF. No user HTML/CSS/scripts are executed. */
(() => {
 'use strict';
 const LIMIT={input:25*1024*1024,entry:12*1024*1024,total:64*1024*1024,files:3000,pages:800,characters:2000000};
 const pause=()=>new Promise(resolve=>setTimeout(resolve,0));
 function cancelled(signal){if(signal?.aborted)throw Error('İşlem iptal edildi.');}
 function pathOf(ref,from=''){
  if(typeof ref!=='string'||/^[a-z][a-z0-9+.-]*:/i.test(ref)||ref.startsWith('/')||ref.includes('\\'))throw Error('EPUB içindeki dış veya geçersiz dosya yolu kullanılamaz.');
  let value;try{value=decodeURIComponent(ref.split(/[?#]/)[0]);}catch{throw Error('EPUB dosya yolu okunamadı.');}
  const parts=from?from.split('/').slice(0,-1):[];
  for(const part of value.split('/')){if(!part||part==='.')continue;if(part==='..'){if(!parts.length)throw Error('EPUB dosya yolu arşiv dışına çıkıyor.');parts.pop();}else{if(part.includes('\0')||part.includes('\\'))throw Error('Geçersiz EPUB yolu.');parts.push(part);}}
  return parts.join('/');
 }
 function decode(bytes){
  const encoding=bytes[0]===255&&bytes[1]===254?'utf-16le':bytes[0]===254&&bytes[1]===255?'utf-16be':'utf-8';
  try{return new TextDecoder(encoding,{fatal:true}).decode(bytes);}catch{throw Error('EPUB metin kodlaması okunamadı. UTF-8 veya UTF-16 gerekir.');}
 }
 function crc32(bytes){let crc=0xffffffff;for(const value of bytes){crc^=value;for(let bit=0;bit<8;bit++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}return (crc^0xffffffff)>>>0;}
 function zip(input){
  const bytes=input instanceof Uint8Array?input:new Uint8Array(input);
  if(bytes.length<22||bytes.length>LIMIT.input)throw Error('EPUB en fazla 25 MB olmalı ve geçerli ZIP içermeli.');
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),u16=o=>view.getUint16(o,true),u32=o=>view.getUint32(o,true);
  let end=-1;for(let i=bytes.length-22;i>=Math.max(0,bytes.length-65557);i--)if(u32(i)===0x06054b50&&i+22+u16(i+20)===bytes.length){end=i;break;}
  if(end<0||u16(end+4)||u16(end+6)||u16(end+8)!==u16(end+10))throw Error('EPUB ZIP dizini geçersiz veya çok parçalı.');
  const count=u16(end+10),size=u32(end+12),start=u32(end+16),entries=new Map(),cache=new Map();
  if(count>LIMIT.files||start+size!==end||start+size>bytes.length)throw Error('EPUB ZIP64 veya boyut sınırını aşan arşiv içeriyor.');
  let cursor=start,total=0;
  for(let i=0;i<count;i++){
   if(cursor+46>end||u32(cursor)!==0x02014b50)throw Error('EPUB ZIP girdisi bozuk.');
   const flags=u16(cursor+8),method=u16(cursor+10),compressed=u32(cursor+20),uncompressed=u32(cursor+24),length=u16(cursor+28),extra=u16(cursor+30),comment=u16(cursor+32),offset=u32(cursor+42);
   if(cursor+46+length+extra+comment>end||flags&1||![0,8].includes(method)||u16(cursor+34))throw Error('Şifreli veya desteklenmeyen EPUB ZIP girdisi.');
   const name=decode(bytes.subarray(cursor+46,cursor+46+length));
   if(name.startsWith('/')||name.includes('\\')||name.split('/').some(part=>part==='..'||part==='.')||name.includes('\0'))throw Error('EPUB ZIP yolu güvenli değil.');
   if(uncompressed>LIMIT.entry||(total+=uncompressed)>LIMIT.total||uncompressed>Math.max(compressed,1)*1500)throw Error('EPUB açılmış boyutu sınırı aşıyor.');
   if(!name.endsWith('/')){
    if(entries.has(name))throw Error('EPUB aynı dosyayı birden fazla kez içeriyor.');
    entries.set(name,{name,method,compressed,uncompressed,offset,crc:u32(cursor+16)});
   }
   cursor+=46+length+extra+comment;
  }
  if(cursor!==end)throw Error('EPUB ZIP dizini tutarsız.');
  function read(name){
   if(cache.has(name))return cache.get(name);
   const entry=entries.get(name);if(!entry)throw Error('EPUB içinde dosya bulunamadı: '+name);
   const o=entry.offset;if(o+30>start||u32(o)!==0x04034b50)throw Error('EPUB yerel ZIP başlığı bozuk.');
   const length=u16(o+26),extra=u16(o+28),data=o+30+length+extra;
   if(data+entry.compressed>start||decode(bytes.subarray(o+30,o+30+length))!==name||u16(o+8)!==entry.method)throw Error('EPUB ZIP veri aralığı geçersiz.');
   const compressed=bytes.subarray(data,data+entry.compressed);let result;
   if(entry.method===0)result=compressed.slice();
   else{
    const chunks=[];let size=0;const inflate=new pako.Inflate({raw:true,chunkSize:65536});
    inflate.onData=chunk=>{size+=chunk.length;if(size>entry.uncompressed||size>LIMIT.entry)throw Error('EPUB açılmış veri sınırını aşıyor.');chunks.push(chunk);};
    inflate.push(compressed,true);if(inflate.err)throw Error('EPUB sıkıştırılmış verisi açılamadı.');
    result=new Uint8Array(size);let offset=0;for(const chunk of chunks){result.set(chunk,offset);offset+=chunk.length;}
   }
   if(result.length!==entry.uncompressed||crc32(result)!==entry.crc)throw Error('EPUB dosyasının bütünlük kontrolü başarısız.');
   cache.set(name,result);return result;
  }
  return {entries,read};
 }
 const all=(node,name)=>[...node.getElementsByTagName('*')].filter(element=>element.localName?.toLowerCase()===name);
 const plain=text=>text.normalize('NFC').replace(/[\u00ad\u200b\ufeff]/g,'').replace(/\s+/gu,' ').trim();
 function xml(bytes,parse){
  let text=decode(bytes);if(/<!ENTITY|<!DOCTYPE[^>]*\[/i.test(text))throw Error('EPUB XML varlık bildirimi desteklenmiyor.');
  text=text.replace(/<!DOCTYPE[^>]*>/gi,'');
  const doc=parse?parse(text):new DOMParser().parseFromString(text,'application/xml');
  if(!doc||all(doc,'parsererror').length)throw Error('EPUB XML veya XHTML dosyası bozuk.');return doc;
 }
 async function open(input,{parseXml,signal,onProgress=()=>{}}={}){
  cancelled(signal);const archive=zip(input),warnings=[];
  if(decode(archive.read('mimetype')).trim()!=='application/epub+zip')throw Error('Bu dosya bir EPUB değil.');
  if(archive.entries.has('META-INF/encryption.xml'))throw Error('Şifreli/DRM korumalı veya gizlenmiş font içeren EPUB bu sürümde desteklenmiyor.');
  const container=xml(archive.read('META-INF/container.xml'),parseXml),root=all(container,'rootfile')[0];
  if(!root)throw Error('EPUB paket belgesi bulunamadı.');
  const opfPath=pathOf(root.getAttribute('full-path')),opf=xml(archive.read(opfPath),parseXml);
  if(all(opf,'meta').some(node=>node.getAttribute('property')==='rendition:layout'&&plain(node.textContent)==='pre-paginated'))throw Error('Sabit sayfa düzenli EPUB bu sürümde desteklenmiyor.');
  const items=new Map(all(opf,'item').map(node=>[node.getAttribute('id'),{path:pathOf(node.getAttribute('href'),opfPath),mime:node.getAttribute('media-type'),properties:node.getAttribute('properties')||''}]));
  const spine=all(opf,'itemref').map(node=>items.get(node.getAttribute('idref')));
  if(!spine.length||spine.some(item=>!item||!['application/xhtml+xml','text/html'].includes(item.mime)))throw Error('EPUB okuma sırası veya bölüm türü desteklenmiyor.');
  const book={title:plain(all(opf,'title')[0]?.textContent||'Kitap'),author:all(opf,'creator').map(node=>plain(node.textContent)).join(', '),language:plain(all(opf,'language')[0]?.textContent||'tr'),chapters:[],warnings};
  let characters=0;
  for(let index=0;index<spine.length;index++){
   cancelled(signal);const item=spine[index],doc=xml(archive.read(item.path),parseXml),body=all(doc,'body')[0];if(!body)throw Error('EPUB bölümü body içermiyor.');
   const blocks=[];let text='',size=12;
   function flush(){const value=plain(text);text='';if(value){characters+=value.length;if(characters>LIMIT.characters)throw Error('Kitap metni boyut sınırını aşıyor.');blocks.push({type:'text',text:value,size});}}
   function walk(node,depth=0){
    if(depth>80)throw Error('EPUB bölüm yapısı çok derin.');
    if(node.nodeType===3||node.nodeType===4){text+=node.textContent;return;}
    if(node.nodeType!==1)return;
    const tag=node.localName.toLowerCase();if(['script','style','iframe','object','audio','video','form'].includes(tag))return;
    if(tag==='img'||tag==='image'){
     flush();let path;try{path=pathOf(node.getAttribute('src')||node.getAttribute('href')||node.getAttribute('xlink:href'),item.path);}catch{warnings.push('Dış veya geçersiz görsel bağlantısı alınmadı.');return;}
     if(!archive.entries.has(path)){warnings.push('Eksik görsel: '+path);return;}
     const bytes=archive.read(path);const png=bytes[0]===137&&bytes[1]===80,jpg=bytes[0]===255&&bytes[1]===216;
     if(!png&&!jpg){warnings.push('PNG/JPEG dışındaki görsel alınmadı: '+path);return;}
     blocks.push({type:'image',bytes,path,mime:png?'image/png':'image/jpeg'});return;
    }
    const block=/^(p|div|section|article|body|li|blockquote|figcaption|h[1-6]|pre|table|tr)$/.test(tag),prior=size;
    if(block||tag==='br')flush();if(/^h[1-6]$/.test(tag))size=tag==='h1'?20:tag==='h2'?17:14;
    if(tag==='li')text+='• ';if(tag==='td'||tag==='th')text+=' ';
    for(const child of node.childNodes)walk(child,depth+1);
    if(block||tag==='br')flush();size=prior;
   }
   walk(body);flush();book.chapters.push({path:item.path,blocks});onProgress({phase:'read',current:index+1,total:spine.length});await pause();
  }
  const coverId=all(opf,'meta').find(node=>node.getAttribute('name')==='cover')?.getAttribute('content');
  const cover=items.get(coverId)||[...items.values()].find(item=>item.properties.split(/\s+/).includes('cover-image'));
  if(cover&&archive.entries.has(cover.path)&&!book.chapters.some(chapter=>chapter.blocks.some(block=>block.type==='image'&&block.path===cover.path))){
   const bytes=archive.read(cover.path),png=bytes[0]===137&&bytes[1]===80,jpg=bytes[0]===255&&bytes[1]===216;
   if(png||jpg)book.cover={type:'image',bytes,path:cover.path,mime:png?'image/png':'image/jpeg'};
   else warnings.push('PNG/JPEG dışındaki kapak alınmadı.');
  }
  if(!book.chapters.some(chapter=>chapter.blocks.length))throw Error('EPUB içinde dönüştürülebilir metin veya görsel bulunamadı.');
  return book;
 }
 function wrap(text,font,size,width){
  const lines=[];let line='';
  for(const word of plain(text).split(' ')){
   if(font.widthOfTextAtSize(word,size)>width){
    if(line){lines.push(line);line='';}
    for(const char of word){if(line&&font.widthOfTextAtSize(line+char,size)>width){lines.push(line);line='';}line+=char;}
   }else if(!line)line=word;
   else if(font.widthOfTextAtSize(line+' '+word,size)<=width)line+=' '+word;
   else{lines.push(line);line=word;}
  }
  if(line)lines.push(line);return lines;
 }
 async function pdf(book,fontBytes,{signal,onProgress=()=>{}}={}){
  cancelled(signal);const doc=await PDFLib.PDFDocument.create();doc.registerFontkit(ErbappTrueType);
  const font=await doc.embedFont(fontBytes,{subset:false});doc.setTitle(book.title);doc.setAuthor(book.author);doc.setLanguage(book.language);doc.setProducer('Erbapp');
  const width=595.28,height=841.89,margin=44,usable=width-2*margin;let page,y,lines=0;const images=new Map();
  function next(){if(doc.getPageCount()>=LIMIT.pages)throw Error('Kitap 800 sayfa sınırını aşıyor.');page=doc.addPage([width,height]);y=height-margin;}
  async function paragraph(text,size=12){for(const line of wrap(text,font,size,usable)){cancelled(signal);if(y-size*1.5<margin)next();page.drawText(line,{font,size,x:margin,y:y-size});y-=size*1.5;if(++lines%40===0)await pause();}y-=8;}
  async function drawImage(block){
   let image=images.get(block.path);
   if(!image){
    if(block.mime==='image/png'){const v=new DataView(block.bytes.buffer,block.bytes.byteOffset,block.bytes.byteLength);if(v.getUint32(16)*v.getUint32(20)>12000000)throw Error('EPUB görseli 12 megapiksel sınırını aşıyor.');image=await doc.embedPng(block.bytes);}else image=await doc.embedJpg(block.bytes);
    images.set(block.path,image);
   }
   const scale=Math.min(usable/image.width,(height-2*margin-24)/image.height),w=image.width*scale,h=image.height*scale;
   if(y-h<margin)next();page.drawImage(image,{x:margin+(usable-w)/2,y:y-h,width:w,height:h});y-=h+12;
  }
  next();if(book.cover){await drawImage(book.cover);next();}await paragraph(book.title,22);if(book.author)await paragraph(book.author,11);
  for(let index=0;index<book.chapters.length;index++){
   cancelled(signal);if(index)next();
   for(const block of book.chapters[index].blocks){
    cancelled(signal);if(block.type==='text')await paragraph(block.text,block.size);
    else await drawImage(block);
   }
   onProgress({phase:'pdf',current:index+1,total:book.chapters.length,pages:doc.getPageCount()});await pause();
  }
  for(const [index,sheet]of doc.getPages().entries()){const text=String(index+1);sheet.drawText(text,{font,size:9,x:(width-font.widthOfTextAtSize(text,9))/2,y:22});}
  cancelled(signal);const bytes=await doc.save();if(bytes.length>64*1024*1024)throw Error('PDF 64 MB çıktı sınırını aşıyor.');cancelled(signal);return bytes;
 }
 window.ErbappEpub={open,pdf,pathOf,zip,wrap,LIMIT};
})();
