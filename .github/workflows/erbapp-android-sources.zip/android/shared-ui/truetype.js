/* Fixed bundled TrueType adapter for pdf-lib 1.17.1. Latin/Greek/Cyrillic,
   no user fonts, complex-script shaping or font subsetting. */
(() => {
 'use strict';
 function create(bytes){
  bytes=bytes instanceof Uint8Array?bytes:new Uint8Array(bytes);
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),u16=o=>view.getUint16(o),i16=o=>view.getInt16(o),u32=o=>view.getUint32(o),tables={};
  if(u32(0)!==0x00010000)throw Error('Desteklenmeyen yazı tipi.');
  for(let i=0;i<u16(4);i++){const o=12+i*16;const tag=String.fromCharCode(...bytes.subarray(o,o+4));tables[tag]=u32(o+8);}
  for(const tag of ['head','hhea','maxp','hmtx','cmap','post'])if(tables[tag]===undefined)throw Error('Yazı tipi eksik: '+tag);
  const head=tables.head,hhea=tables.hhea,cmap=tables.cmap,post=tables.post,metrics=u16(hhea+34),glyphCount=u16(tables.maxp+4),mapping=new Map();
  let selected=null;
  for(let i=0;i<u16(cmap+2);i++){const offset=cmap+u32(cmap+4+i*8+4),format=u16(offset);if(format===12){selected={offset,format};break;}if(format===4)selected={offset,format};}
  if(!selected)throw Error('Yazı tipi Unicode haritası bulunamadı.');
  const o=selected.offset;
  if(selected.format===12){
   for(let i=0;i<u32(o+12);i++){const p=o+16+i*12,start=u32(p),end=u32(p+4),first=u32(p+8);if(end-start>200000)throw Error('Yazı tipi aralığı geçersiz.');for(let cp=start;cp<=end;cp++){const id=first+cp-start;if(id&&id<glyphCount)mapping.set(cp,id);}}
  }else{
   const count=u16(o+6)/2,end=o+14,start=end+count*2+2,delta=start+count*2,range=delta+count*2;
   for(let i=0;i<count;i++)for(let cp=u16(start+i*2);cp<=u16(end+i*2)&&cp<65535;cp++){
    const relative=u16(range+i*2);let id=relative?u16(range+i*2+relative+2*(cp-u16(start+i*2))):cp;
    if(!relative||id)id=(id+i16(delta+i*2))&65535;if(id&&id<glyphCount)mapping.set(cp,id);
   }
  }
  const used=new Set([32]),unitsPerEm=u16(head+18);
  function glyphForCodePoint(cp){const id=mapping.get(cp);if(!id)throw Error('Bu kitapta desteklenmeyen karakter var: U+'+cp.toString(16).toUpperCase());used.add(cp);return {id,codePoints:[cp],advanceWidth:u16(tables.hmtx+4*Math.min(id,metrics-1))};}
  return {postscriptName:'DejaVuSans',unitsPerEm,ascent:i16(hhea+4),descent:i16(hhea+6),capHeight:i16(hhea+4),xHeight:0,italicAngle:view.getInt32(post+4)/65536,
   bbox:{minX:i16(head+36),minY:i16(head+38),maxX:i16(head+40),maxY:i16(head+42)},post:{isFixedPitch:Boolean(u32(post+12))},head:{macStyle:{italic:Boolean(u16(head+44)&2)}},
   get characterSet(){return [...used];},glyphForCodePoint,
   layout(text){if(/[\u0590-\u08ff\ufb1d-\ufdff\ufe70-\ufeff]/u.test(text))throw Error('Sağdan sola yazı düzeni bu sürümde desteklenmiyor.');return {glyphs:[...text].map(char=>glyphForCodePoint(char.codePointAt(0)))};}
  };
 }
 window.ErbappTrueType={create};
})();
