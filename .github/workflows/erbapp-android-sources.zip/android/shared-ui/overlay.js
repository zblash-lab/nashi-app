/* Shared, ordinary DOM overlay: avoids WebView dialog/backdrop compositing. */
(() => {
  'use strict';
  let active = null;
  function close(restoreFocus = true) {
    if (!active) return false;
    const current = active; active = null;
    current.overlay.remove();
    current.root.inert = current.inert;
    document.body.style.overflow = current.overflow;
    current.onClose?.();
    if (restoreFocus && current.focus?.isConnected) current.focus.focus({preventScroll:true});
    return true;
  }
  function open(title, subtitle, options = {}) {
    const focus = active?.focus || document.activeElement;
    close(false);
    const root = document.getElementById('playground');
    const overlay = document.createElement('div');overlay.className='erbapp-modal-overlay';
    const panel = document.createElement('section');panel.className='erbapp-modal-panel';
    panel.setAttribute('role','dialog');panel.setAttribute('aria-modal','true');panel.setAttribute('aria-labelledby','erbapp-modal-title');
    const header=document.createElement('div');header.className='erbapp-modal-header';
    const heading=document.createElement('div');
    const name=document.createElement('h2');name.id='erbapp-modal-title';name.textContent=title;
    const note=document.createElement('p');note.textContent=subtitle;heading.append(name,note);
    const dismiss=document.createElement('button');dismiss.type='button';dismiss.className='erbapp-modal-close';
    dismiss.textContent='×';dismiss.setAttribute('aria-label','Kapat');dismiss.onclick=()=>close();
    header.append(heading,dismiss);panel.append(header);overlay.append(panel);
    overlay.addEventListener('click',event=>{if(event.target===overlay)close();});
    overlay.addEventListener('keydown',event=>{
      event.stopPropagation();
      if(event.key==='Escape'){event.preventDefault();close();return;}
      options.onKeyDown?.(event);
      if(event.defaultPrevented)return;
      if(event.key!=='Tab')return;
      const buttons=[...panel.querySelectorAll('button:not([disabled]),a[href],input:not([disabled]),[tabindex="0"]')];
      const first=buttons[0],last=buttons.at(-1);
      if(!first){event.preventDefault();dismiss.focus();return;}
      if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}
      else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}
    });
    active={overlay,root,inert:root.inert,overflow:document.body.style.overflow,focus,onClose:options.onClose};
    root.inert=true;document.body.style.overflow='hidden';document.body.append(overlay);
    dismiss.focus({preventScroll:true});
    return panel;
  }
  window.ErbappOverlay={open,close};
})();
