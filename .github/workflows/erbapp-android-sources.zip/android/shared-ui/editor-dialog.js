/* Shared tool windows: ordinary DOM panels with the upstream editor lifecycle. */
(() => {
  'use strict';
  function install(port) {
    function close() {
      const editor=port.getEditor();
      if(!editor)return false;
      // Clear first: closing the overlay invokes this function again.
      port.setEditor(null);
      for(const media of editor.dialog.querySelectorAll('video,audio')) {
        try {media.pause();} catch {}
      }
      for(const cleanup of editor.cleanup) {
        try {cleanup();} catch(error) {console.warn('Araç kaynağı kapatılamadı.',error);}
      }
      window.ErbappOverlay.close();
      editor.dialog.remove();
      return true;
    }
    function open(title,subtitle,ic='file') {
      port.closeWheel();close();
      if(title==='Demo kitaplığın'){title='Kitaplık';subtitle='Bu oturumda üretilen gerçek dosyalar. Kalıcı kayıt için dosyayı kaydet.';}
      const panel=window.ErbappOverlay.open(title,subtitle,{
        onClose:close,
        onKeyDown:event=>port.key(event)
      });
      panel.classList.add('demo-dialog','erbapp-editor-panel');
      panel.setAttribute('open','');
      const header=panel.querySelector('.erbapp-modal-header');
      header.classList.add('editor-header');
      panel.querySelector('.erbapp-modal-close').classList.add('close-editor');
      const badge=document.createElement('div');badge.className='editor-icon';badge.append(port.icon(ic));
      header.prepend(badge);
      port.setEditor({dialog:panel,cleanup:[]});
      return panel;
    }
    function unavailable(files,ext) {
      const panel=open('EPUB → '+ext.toUpperCase(),'Bu sürümde desteklenmiyor.');
      const body=document.createElement('div');body.className='nashi-file-manager-body';
      const note=document.createElement('p');note.className='editor-note';
      note.textContent='EPUB dönüşümü henüz eklenmedi. Dosyan değiştirilmedi; yeni dosya oluşturulmadı.';
      const names=document.createElement('p');names.className='editor-note';
      names.textContent=files.map(file=>file.name).join(', ');
      const dismiss=document.createElement('button');dismiss.type='button';dismiss.className='utility-button';
      dismiss.textContent='Anladım';dismiss.onclick=close;
      body.append(note,names,dismiss);panel.append(body);
      return panel;
    }
    return {open,close,unavailable};
  }
  window.ErbappEditorDialogs={install};
})();
