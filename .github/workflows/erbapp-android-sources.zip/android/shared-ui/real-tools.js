/* Direct operation controls: input -> real Blob -> explicit save link. */
(() => {
 'use strict';
 function install(port){
  const make=(tag,text='')=>{const node=document.createElement(tag);node.textContent=text;return node;};
  const panel=make('section');panel.className='erbapp-real-tools';panel.setAttribute('aria-label','Dosya dönüştür');panel.hidden=!!port.compact;
  const title=make('h2','Dosya dönüştür'),selected=make('p');selected.className='erbapp-tool-selection';
  const label=make('label','İşlem '),format=make('select');format.id='erbapp-output-format';label.append(format);
  const rangeLabel=make('label','Sayfalar (örn. 1-3, 5) '),range=make('input');range.id='erbapp-page-range';range.placeholder='Boş: tüm sayfalar';rangeLabel.append(range);
  const rotateLabel=make('label','Döndürme '),rotation=make('select');for(const value of [90,180,270]){const option=make('option',value+'°');option.value=String(value);rotation.append(option);}rotateLabel.append(rotation);
  const run=make('button','Dönüştür'),status=make('p'),outputs=make('div');run.id='erbapp-run';run.type='button';status.id='erbapp-conversion-status';status.setAttribute('role','status');outputs.className='erbapp-real-results';
  const cancel=make('button','İptal');cancel.type='button';cancel.hidden=true;cancel.onclick=()=>abort?.abort();
  const controls=make('div');controls.className='erbapp-tool-controls';controls.append(label,rangeLabel,rotateLabel,run,cancel);
  const selectAll=make('button','Yüklediklerimin tümünü seç');selectAll.className='erbapp-select-all';selectAll.type='button';selectAll.onclick=()=>port.selectAll();
  const pick=make('button','Dosya ekle');pick.id='erbapp-pick';pick.type='button';pick.className='erbapp-select-all';pick.onclick=()=>port.pick();
  const dismiss=make('button','Kapat');dismiss.type='button';dismiss.className='erbapp-select-all';dismiss.onclick=()=>{abort?.abort();panel.hidden=true;};
  panel.append(title,pick,selected,selectAll,controls,status,outputs);if(port.compact)panel.append(dismiss);port.stage.before(panel);
  let group=null,busy=false,abort=null,supported=false;
  function fields(){rangeLabel.hidden=format.value!=='pdf:extract';rotateLabel.hidden=format.value!=='pdf:rotate';}
  function render(){
   const current=port.group(),files=port.selection();
   if(current!==group){group=current;format.replaceChildren();const options={image:[['image:png','PNG'],['image:jpg','JPEG'],['image:webp','WebP'],['image:pdf','PDF']],pdf:[['pdf:extract','Sayfa seç / PDF böl'],['pdf:merge','PDF birleştir'],['pdf:rotate','PDF döndür']],epub:[['epub:pdf','PDF']]}[group]||[];
    for(const [value,title]of options){const option=make('option',title);option.value=value;format.append(option);}supported=options.length>0;fields();
   }
   selected.textContent=files.length?files.map(file=>file.name+(file.user?'':' (örnek)')).join(', '):'Dosya ekle ve listeden seç.';
   format.disabled=busy||!supported;pick.disabled=busy;selectAll.disabled=busy;range.disabled=busy;rotation.disabled=busy;
   run.disabled=busy||!supported||!files.length||files.some(file=>!file.blob);
   if(!supported)status.textContent='Bu kategori geliştirme aşamasında. Buradaki menüler gerçek dönüştürme desteği anlamına gelmez.';
  }
  format.onchange=fields;
  run.onclick=async()=>{
   if(busy)return;busy=true;cancel.hidden=false;outputs.replaceChildren();abort=new AbortController();status.textContent='Dosya işleniyor…';render();
   try{
    const results=await ErbappConverters.run([...port.selection()],format.value,{range:range.value,rotation:Number(rotation.value),signal:abort.signal,progress:text=>{status.textContent=text;}});
    for(const result of results){const saved=port.result(result.name,result.blob);const link=make('a',result.name+' · Kaydet ↓');link.href=saved.url;link.download=saved.name;link.className='erbapp-output-link';outputs.append(link);for(const warning of result.warnings||[])outputs.append(make('p',warning));}
    status.textContent=results.length+' çıktı hazır. Kalıcı kayıt için Kaydet bağlantısını kullan.';
   }catch(error){status.textContent='Dönüştürme yapılamadı: '+error.message;}finally{busy=false;cancel.hidden=true;render();}
  };
  const show=()=>{panel.hidden=false;panel.scrollIntoView({block:'nearest'});};
  render();return {render,show,cancel:()=>abort?.abort(),get busy(){return busy;},
   execute(operation){show();if(busy)return;render();format.value=operation;fields();return run.onclick();}};
 }
 window.ErbappRealTools={install};
})();
