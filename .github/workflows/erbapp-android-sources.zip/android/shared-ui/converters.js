/* Real converters only. Every successful operation returns actual output bytes. */
(() => {
 'use strict';
 const stem=name=>name.replace(/\.[^.]+$/,'');
 async function bytes(file){if(!file.blob)throw Error('Örnek yerine kendi dosyanı ekle.');return new Uint8Array(await file.blob.arrayBuffer());}
 async function image(file){
  if(!file.blob)throw Error('Örnek yerine kendi görselini ekle.');const url=URL.createObjectURL(file.blob);
  try{return await new Promise((resolve,reject)=>{const img=new Image(),timer=setTimeout(()=>{img.src='';reject(Error('Görsel okunamadı.'));},15000);img.onload=()=>{clearTimeout(timer);if(img.width*img.height>24000000)reject(Error('Görsel en fazla 24 megapiksel olabilir.'));else resolve(img);};img.onerror=()=>{clearTimeout(timer);reject(Error('Görsel dosyası okunamadı.'));};img.src=url;});}finally{URL.revokeObjectURL(url);}
 }
 function canvas(img,white=false){const node=document.createElement('canvas');node.width=img.width;node.height=img.height;const context=node.getContext('2d');if(!context)throw Error('Görsel motoru açılamadı.');if(white){context.fillStyle='#ffffff';context.fillRect(0,0,node.width,node.height);}context.drawImage(img,0,0);return node;}
 function encode(canvas,mime,quality=.9){return new Promise((resolve,reject)=>canvas.toBlob(blob=>blob&&blob.type===mime?resolve(blob):reject(Error('Bu cihaz istenen görsel çıktısını desteklemiyor.')),mime,quality));}
 async function loadPdf(file){try{return await PDFLib.PDFDocument.load(await bytes(file));}catch(error){if(!file.blob)throw error;throw Error('PDF açılamadı. Şifreli veya bozuk PDF bu işlemde desteklenmiyor.');}}
 function pages(value,count){if(!value.trim())return Array.from({length:count},(_,index)=>index);const result=[];for(const token of value.split(',')){const match=token.trim().match(/^(\d+)(?:\s*-\s*(\d+))?$/);if(!match)throw Error('Sayfa aralığını 1-3, 5 şeklinde gir.');const first=Number(match[1]),last=Number(match[2]||match[1]);if(first<1||last<first||last>count)throw Error('Sayfa aralığı PDF dışında.');for(let i=first;i<=last;i++)if(!result.includes(i-1))result.push(i-1);}return result;}
 async function run(files,operation,{range='',rotation=90,progress=()=>{},signal}={}){
  if(signal?.aborted)throw Error('İşlem iptal edildi.');
  if(!files.length)throw Error('Önce bir dosya ekle ve seç.');if(files.some(file=>!file.blob))throw Error('Örnek dosyalar yerine kendi dosyanı ekle ve seç.');
  const outputs=[];
  if(operation.startsWith('image:')){
   if(files.some(file=>file.kind!=='image'))throw Error('Bu işlem için yalnız görsel seç.');const format=operation.split(':')[1];
   if(format==='pdf'){
    const doc=await PDFLib.PDFDocument.create();
    for(const [index,file]of files.entries()){progress('Görsel PDF’ye ekleniyor: '+(index+1)+' / '+files.length);const img=await image(file),png=await encode(canvas(img),'image/png'),embedded=await doc.embedPng(await png.arrayBuffer()),page=doc.addPage([595.28,841.89]);const scale=Math.min(507.28/img.width,753.89/img.height);page.drawImage(embedded,{x:(595.28-img.width*scale)/2,y:(841.89-img.height*scale)/2,width:img.width*scale,height:img.height*scale});}
    outputs.push({name:files.length===1?stem(files[0].name)+'.pdf':'gorseller.pdf',blob:new Blob([await doc.save()],{type:'application/pdf'})});
   }else{
    const mime={png:'image/png',jpg:'image/jpeg',webp:'image/webp'}[format];if(!mime)throw Error('Görsel çıktı türü desteklenmiyor.');
    for(const [index,file]of files.entries()){progress('Görsel dönüştürülüyor: '+(index+1)+' / '+files.length);outputs.push({name:stem(file.name)+'.'+format,blob:await encode(canvas(await image(file),format==='jpg'),mime)});}
   }
  }else if(operation.startsWith('pdf:')){
   if(files.some(file=>file.ext!=='pdf'))throw Error('Bu işlem için yalnız PDF seç.');const action=operation.split(':')[1],doc=await PDFLib.PDFDocument.create();
   if(action==='merge'){
    if(files.length<2)throw Error('Birleştirmek için en az iki PDF ekle ve seç.');
    for(const [index,file]of files.entries()){progress('PDF birleştiriliyor: '+(index+1)+' / '+files.length);const source=await loadPdf(file);for(const page of await doc.copyPages(source,source.getPageIndices()))doc.addPage(page);}
   }else{
    if(files.length!==1)throw Error('Bu işlem için tek PDF seç.');const source=await loadPdf(files[0]);
    const indices=action==='extract'?pages(range,source.getPageCount()):source.getPageIndices();
    if(!['extract','rotate'].includes(action))throw Error('PDF işlemi desteklenmiyor.');
    if(action==='rotate'&&![90,180,270].includes(Number(rotation)))throw Error('Döndürme açısı 90, 180 veya 270 olmalı.');
    for(const page of await doc.copyPages(source,indices)){if(action==='rotate')page.setRotation(PDFLib.degrees((page.getRotation().angle+Number(rotation))%360));doc.addPage(page);}
   }
   outputs.push({name:action==='merge'?'birlestirilmis.pdf':stem(files[0].name)+'-'+(action==='rotate'?'dondurulmus':'sayfalar')+'.pdf',blob:new Blob([await doc.save()],{type:'application/pdf'})});
  }else if(operation==='epub:pdf'){
   if(files.length!==1||files[0].ext!=='epub')throw Error('Tek EPUB seç.');
   const onProgress=e=>progress((e.phase==='read'?'Kitap okunuyor':'PDF hazırlanıyor')+': bölüm '+e.current+' / '+e.total);
   const book=await ErbappEpub.open(await bytes(files[0]),{signal,onProgress});
   const response=await fetch(new URL('../erbapp/vendor/fonts/DejaVuSans.ttf',document.baseURI));if(!response.ok)throw Error('Yerel yazı tipi bulunamadı.');
   outputs.push({name:stem(files[0].name)+'.pdf',blob:new Blob([await ErbappEpub.pdf(book,new Uint8Array(await response.arrayBuffer()),{signal,onProgress})],{type:'application/pdf'}),warnings:book.warnings});
  }else throw Error('Bu araç henüz gerçek dosya üretmiyor. Desteklenen görsel, PDF veya EPUB işlemlerini seç.');
  if(signal?.aborted)throw Error('İşlem iptal edildi.');
  if(outputs.some(output=>!output.blob.size||output.blob.size>64*1024*1024))throw Error('Çıktı boş veya 64 MB sınırını aşıyor.');return outputs;
 }
 window.ErbappConverters={run,pages};
})();
