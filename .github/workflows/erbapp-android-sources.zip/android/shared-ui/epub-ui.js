/* Real EPUB conversion UI, using the same PDF Blob save/share bridge as images. */
(() => {
 'use strict';let fontPromise;
 function install(port){
  const make=(tag,text='')=>{const node=document.createElement(tag);node.textContent=text;return node;};
  async function convert(files,ext){
   if(ext!=='pdf')return port.unavailable(files,ext);
   const panel=port.dialog('EPUB → PDF','Dosyan cihazında işlenir. Orijinal dosya değiştirilmez.'),editor=port.editor();
   const body=make('div');body.className='nashi-file-manager-body';panel.append(body);
   const status=make('p');status.setAttribute('role','status');status.className='editor-note';
   const note=make('p','Türkçe metin, bölüm sırası ve PNG/JPEG görselleri korunur. PDF sayfa düzeni yeniden oluşturulur; kitap tasarımı birebir kopyalanmaz.');note.className='editor-note';body.append(note,status);
   if(files.length!==1||!files[0].blob){
    status.textContent=files.length!==1?'Bir defada tek EPUB seç.':'Bu bir örnek dosya. PDF oluşturmak için kendi EPUB dosyanı ekle.';
    const pick=make('button','EPUB dosyası seç');pick.className='utility-button';pick.onclick=()=>{port.close();port.pick();};body.append(pick);return;
   }
   const file=files[0],abort=new AbortController();editor.cleanup.push(()=>abort.abort());
   const button=make('button','PDF oluştur');button.className='utility-button';button.disabled=true;body.append(button);
   const active=()=>port.editor()===editor&&!abort.signal.aborted;
   let book,pages=0;
   const progress=event=>{if(!active())return;pages=event.pages||pages;status.textContent=(event.phase==='read'?'Kitap okunuyor':'PDF hazırlanıyor')+': bölüm '+event.current+' / '+event.total+(event.pages?' · '+event.pages+' sayfa':'');};
   try{
    status.textContent='EPUB okunuyor…';
    book=await ErbappEpub.open(await file.blob.arrayBuffer(),{signal:abort.signal,onProgress:progress});if(!active())return;
    const title=make('p',book.title+(book.author?' · '+book.author:''));title.className='editor-note';body.prepend(title);
    for(const warning of book.warnings){const text=make('p',warning);text.className='editor-note';body.append(text);}
    status.textContent=book.chapters.length+' bölüm hazır. PDF oluşturabilirsin.';button.disabled=false;
   }catch(error){if(active())status.textContent=error.message;return;}
   button.onclick=async()=>{
    button.disabled=true;
    try{
     if(!fontPromise)fontPromise=fetch(new URL('../erbapp/vendor/fonts/DejaVuSans.ttf',document.baseURI)).then(response=>{if(!response.ok)throw Error('Yerel yazı tipi okunamadı.');return response.arrayBuffer();}).catch(error=>{fontPromise=null;throw error;});
     const bytes=await ErbappEpub.pdf(book,new Uint8Array(await fontPromise),{signal:abort.signal,onProgress:progress});if(!active())return;
     const output=port.result(file.name.replace(/\.epub$/i,'')+'.pdf',new Blob([bytes],{type:'application/pdf'}));
     const link=make('a',"PDF’yi kaydet ↓");link.href=output.url;link.download=output.name;link.className='utility-button erbapp-epub-save';body.append(link);
     status.textContent='PDF hazır · '+pages+' sayfa. Kalıcı kayıt için PDF’yi kaydet düğmesini kullan.';button.textContent='PDF oluşturuldu';
    }catch(error){if(active()){status.textContent=error.message;button.disabled=false;}}
   };
  }
  return {convert};
 }
 window.ErbappEpubUI={install};
})();
