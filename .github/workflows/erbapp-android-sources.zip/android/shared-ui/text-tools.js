/* Convert actual UTF-8 user bytes; never substitute demo text. */
(() => {
 'use strict';
 function supports(files,target){return files.length>0&&files.every(file=>
  ['txt','md'].includes(file.ext)&&['txt','md','html'].includes(target)||
  ['csv','tsv'].includes(file.ext)&&['csv','tsv'].includes(target)||
  ['srt','vtt'].includes(file.ext)&&['srt','vtt','txt'].includes(target));}
 function table(text,delimiter){
  const rows=[];let row=[],field='',quoted=false,closed=false;
  for(let i=0;i<text.length;i++){
   const c=text[i];
   if(quoted){if(c==='"'){if(text[i+1]==='"'){field+='"';i++;}else{quoted=false;closed=true;}}else field+=c;continue;}
   if(c==='"'&&!field&&!closed){quoted=true;continue;}
   if(c===delimiter){row.push(field);field='';closed=false;continue;}
   if(c==='\r'||c==='\n'){if(c==='\r'&&text[i+1]==='\n')i++;row.push(field);rows.push(row);row=[];field='';closed=false;continue;}
   if(closed)throw Error('Tabloda kapanış tırnağından sonra geçersiz karakter var.');
   field+=c;
  }
  if(quoted)throw Error('Tabloda kapanmamış tırnak var.');
  if(field||row.length||closed)rows.push([...row,field]);
  return rows;
 }
 function subtitles(text){
  const cues=[];
  for(const block of text.replace(/^\uFEFF/,'').replace(/^WEBVTT[^\n]*\n/,'').trim().split(/\n\s*\n/)){
   const lines=block.split('\n');if(/^(NOTE|STYLE|REGION)(?:\s|$)/.test(lines[0]))continue;
   const index=lines.findIndex(line=>line.includes('-->'));if(index<0)continue;
   const match=lines[index].match(/^((?:\d{2,}:)?\d{2}:\d{2}[.,]\d{3})\s+-->\s+((?:\d{2,}:)?\d{2}:\d{2}[.,]\d{3})(?:\s+.*)?$/);
   if(!match)throw Error('Altyazı zaman aralığı okunamadı.');
   const timestamp=value=>{value=value.replace(',','.');return value.split(':').length===2?'00:'+value:value;};
   cues.push({start:timestamp(match[1]),end:timestamp(match[2]),text:lines.slice(index+1).join('\n')});
  }
  if(!cues.length)throw Error('Dosyada geçerli altyazı bulunamadı.');
  return cues;
 }
 async function run(files,target){
  if(!supports(files,target)||files.some(file=>!file.user||!file.blob))throw Error('Bu dönüşüm için kendi desteklenen metin dosyanı seç.');
  const outputs=[];
  for(const file of files){
   if(file.blob.size>5*1024*1024)throw Error('Metin dönüştürme sınırı 5 MB.');
   let text;try{text=new TextDecoder('utf-8',{fatal:true}).decode(await file.blob.arrayBuffer()).replace(/^\uFEFF/,'');}catch{throw Error('Metin UTF-8 olarak okunamadı.');}
   text=text.replace(/\r\n?/g,'\n');let result=text,mime='text/plain;charset=utf-8';
   if(['csv','tsv'].includes(file.ext)){
    const delimiter=target==='csv'?',':'\t';
    result=table(text,file.ext==='csv'?',':'\t').map(row=>row.map(field=>/["\r\n]/.test(field)||field.includes(delimiter)?'"'+field.replace(/"/g,'""')+'"':field).join(delimiter)).join('\r\n');
    mime=target==='csv'?'text/csv;charset=utf-8':'text/tab-separated-values;charset=utf-8';
   }else if(['srt','vtt'].includes(file.ext)){
    const cues=subtitles(text);
    result=target==='txt'?cues.map(cue=>cue.text).join('\n\n'):(target==='vtt'?'WEBVTT\n\n':'')+cues.map((cue,index)=>(target==='srt'?(index+1)+'\n':'')+(target==='srt'?cue.start.replace('.',','):cue.start)+' --> '+(target==='srt'?cue.end.replace('.',','):cue.end)+'\n'+cue.text).join('\n\n')+'\n';
    mime=target==='vtt'?'text/vtt;charset=utf-8':'text/plain;charset=utf-8';
   }else if(target==='html'){
    result='<!doctype html><html lang="tr"><meta charset="utf-8"><title>'+file.name.replace(/[&<>"']/g,'')+'</title><body><pre>'+text.replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]))+'</pre></body></html>';mime='text/html;charset=utf-8';
   }
   outputs.push({name:file.name.replace(/\.[^.]+$/,'')+'.'+target,blob:new Blob([result],{type:mime})});
  }
  return outputs;
 }
 window.ErbappTextConverters={supports,run};
})();
