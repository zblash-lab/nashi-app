/* Local file workspace: tab changes never discard imported files. */
(() => {
 'use strict';
 const MAX_FILE=25*1024*1024,MAX_TOTAL=75*1024*1024;
 const GROUPS=['image','video','audio','pdf','document','sheet','slides','epub','subtitle','archive'];
 function database(){
  let connection;
  async function open(){
   if(connection)return connection;
   if(!window.indexedDB)return null;
   connection=await new Promise((resolve,reject)=>{
    const request=indexedDB.open('erbapp-files',1);
    request.onupgradeneeded=()=>request.result.createObjectStore('files',{keyPath:'id'});
    request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);
   });return connection;
  }
  async function run(mode,action){
   const db=await open();if(!db)return null;
   return new Promise((resolve,reject)=>{
    const transaction=db.transaction('files',mode);const request=action(transaction.objectStore('files'));
    let result;request.onsuccess=()=>{result=request.result;};
    transaction.oncomplete=()=>resolve(result);transaction.onerror=()=>reject(transaction.error);transaction.onabort=()=>reject(transaction.error);
   });
  }
  return {list:()=>run('readonly',store=>store.getAll()),put:file=>run('readwrite',store=>store.put(file)),remove:id=>run('readwrite',store=>store.delete(id))};
 }
 function install(port,store=database()){
  const bins=new Map(),records=new Map();let started=false,persistent=true;
  const deleted=new Set();
  try{for(const id of JSON.parse(window.localStorage?.getItem('erbapp.deletedFiles.v1')||'[]'))if(typeof id==='string')deleted.add(id);}catch{}
  const rememberDeleted=()=>{try{window.localStorage?.setItem('erbapp.deletedFiles.v1',JSON.stringify([...deleted]));}catch{}};
  const ensure=group=>{if(!bins.has(group))bins.set(group,{files:port.samples(group),selected:[]});return bins.get(group);};
  function remember(){if(started){const state=port.state();bins.set(state.group,{files:[...state.files],selected:[...state.selected]});}}
  function display(group){const bucket=ensure(group);const ids=new Set(bucket.files.map(file=>file.id));
   bucket.selected=bucket.selected.filter(id=>ids.has(id));
   if(!bucket.selected.length&&bucket.files.length)bucket.selected=[bucket.files[0].id];
   port.display(group,bucket.files,bucket.selected);started=true;port.render();
  }
  function switchGroup(group){remember();display(group);}
  async function save(action){try{const result=await action();if(result===null){persistent=false;port.notice('Bu cihazda kalıcı dosya kaydı kullanılamıyor. Dosyalar bu oturumda korunacak.');}}catch{persistent=false;port.notice('Dosyalar bu oturumda korunuyor; kalıcı kayıt için cihazda yer açıp tekrar ekle.');}}
  const ready=(async()=>{
   try{
    const saved=await store.list();if(saved===null){persistent=false;return;}
    remember();
    for(const record of saved||[]){
     if(deleted.has(record.id)||!record.blob||typeof record.blob.arrayBuffer!=='function'||record.blob.size>MAX_FILE||!GROUPS.includes(record.group))continue;
     records.set(record.id,record);const bucket=ensure(record.group);
     if(!bucket.files.some(file=>file.id===record.id))bucket.files.push({...record,url:port.url(record.blob),sample:false,user:true});
    }
    for(const bucket of bins.values()){const users=bucket.files.filter(file=>file.user);bucket.files=[...users,...bucket.files.filter(file=>!file.user).slice(0,Math.max(0,12-users.length))];}
    if(started)display(port.state().group);
   }catch{persistent=false;port.notice('Kayıtlı dosyalar açılamadı. Bu oturumda yeni dosya ekleyebilirsin.');}
  })();
  function kind(file){
   const ext=file.name.split('.').pop().toLowerCase();
   if(file.type==='application/epub+zip'||ext==='epub')return {group:'epub',kind:'file',ext:'epub'};
   if(file.type==='application/pdf'||ext==='pdf')return {group:'pdf',kind:'file',ext:'pdf'};
   const mimes={png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',webp:'image/webp',gif:'image/gif',bmp:'image/bmp'};
   if(Object.values(mimes).includes(file.type)||mimes[ext])return {group:'image',kind:'image',ext:({'image/png':'png','image/jpeg':'jpg','image/webp':'webp','image/gif':'gif','image/bmp':'bmp'}[file.type]||(ext==='jpeg'?'jpg':ext))};
   const families={video:['mp4','mov','mkv','webm','avi','wmv'],audio:['mp3','m4a','wav','flac','ogg','opus','aiff','wma'],document:['docx','pages','md','rtf','rtfd','textclipping','txt','html'],sheet:['xlsx','xls','ods','csv','tsv'],slides:['ppt','pptx'],subtitle:['srt','vtt'],archive:['zip','tar','gz','rar']};
   for(const [group,extensions]of Object.entries(families))if(extensions.includes(ext))return {group,kind:['video','audio','archive'].includes(group)?group:'file',ext};
   return null;
  }
  async function importFiles(files){
   await ready;remember();
   const accepted=files.map(file=>({file,type:kind(file)}));
   if(!accepted.length)return;
   if(accepted.some(item=>!item.type)){port.notice('Bu dosya biçimi tanınmıyor. Desteklenen görsel, medya, belge veya arşiv dosyası seç.');return;}
   if(accepted.some(item=>item.file.size>MAX_FILE)){port.notice('Tek dosya en fazla 25 MB olabilir.');return;}
   const total=[...records.values()].reduce((sum,record)=>sum+record.blob.size,0)+files.reduce((sum,file)=>sum+file.size,0);
   if(total>MAX_TOTAL){port.notice('Dosya alanı en fazla 75 MB olabilir. Önce kullanmadığın dosyaları listeden kaldır.');return;}
   const counts=new Map();for(const item of accepted)counts.set(item.type.group,(counts.get(item.type.group)||0)+1);
   for(const [group,count]of counts)if(ensure(group).files.length+count>12){port.notice('Bir sekmede en fazla 12 dosya tutulabilir. Örnekleri veya kullanmadığın dosyaları kaldır.');return;}
   const prepared=[];
   for(const {file,type}of accepted){const owned=new Blob([await file.arrayBuffer()],{type:file.type||({epub:'application/epub+zip',pdf:'application/pdf'}[type.group]||'application/octet-stream')});prepared.push({file,type,owned});}
   remember();
   const added=[];
   const pending=[];
   for(const {file,type,owned}of prepared){
    const record={...port.model(file.name,type.kind),id:'user-'+port.uuid(),name:file.name,ext:type.ext,kind:type.kind,group:type.group,blob:owned,user:true,sample:false,created:Date.now()};
    delete record.url;
    records.set(record.id,record);const model={...record,url:port.url(owned)};ensure(type.group).files.push(model);added.push(model);
    pending.push(record);
   }
   const group=added[0].group;ensure(group).selected=added.filter(file=>file.group===group).map(file=>file.id);display(group);
   for(const record of pending)if(records.has(record.id))await save(()=>store.put(record));
   port.notice(persistent?'Dosyalar eklendi. Sekme değiştirince ve yeniden açınca korunacak.':'Dosyalar eklendi; bu oturum boyunca korunacak.');
  }
  function remove(id){
   deleted.add(id);rememberDeleted();records.delete(id);
   for(const bucket of bins.values()){bucket.files=bucket.files.filter(file=>file.id!==id);bucket.selected=bucket.selected.filter(value=>value!==id);}
   void save(async()=>{const result=await store.remove(id);if(result!==null){deleted.delete(id);rememberDeleted();}return result;});
  }
  let queue=Promise.resolve();
  const importQueued=files=>{queue=queue.then(()=>importFiles([...files])).catch(error=>port.notice('Dosya yüklenemedi: '+error.message));return queue;};
  return {ready,remember,switchGroup,importFiles:importQueued,remove};
 }
 window.ErbappWorkspace={install};
})();
