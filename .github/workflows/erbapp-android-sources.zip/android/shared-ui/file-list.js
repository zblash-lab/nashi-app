/* Android file-list controls. Removal affects this session, never source files. */
(() => {
  'use strict';
  const STORAGE_KEY = 'nashi.hiddenSamples.v1';
  const stem = file => file.name.replace(/\.[^.]+$/, '');
  function createController(port, storage) {
    let hidden;
    try {
      const saved = JSON.parse(storage?.getItem(STORAGE_KEY) || '[]');
      hidden = new Set(Array.isArray(saved) ? saved.filter(value => typeof value === 'string') : []);
    } catch { hidden = new Set(); }
    const key = file => port.group() + ':' + stem(file);
    const sample = file => file.sample === true && !file.user;
    const persist = () => { try { storage?.setItem(STORAGE_KEY, JSON.stringify([...hidden])); } catch {} };
    return {
      filter() {
        const files = port.files();
        const kept = files.filter(file => !sample(file) || !hidden.has(key(file)));
        if (kept.length !== files.length) port.replace(kept);
      },
      remove(ids) {
        const selected = new Set(ids), before = port.files();
        const removed = before.filter(file => selected.has(file.id));
        for (const file of removed) if (sample(file)) hidden.add(key(file));
        port.replace(before.filter(file => !selected.has(file.id)));
        for (const file of removed) if (file.user) port.release(file);
        persist();
        port.refresh();
        return removed.length;
      },
      clear() { return this.remove(port.files().map(file => file.id)); },
      restore() {
        const prefix = port.group() + ':';
        for (const entry of hidden) if (entry.startsWith(prefix)) hidden.delete(entry);
        const files = port.files(), existing = new Set(files.filter(sample).map(key));
        const added = port.samples().filter(file => !existing.has(key(file))).slice(0, Math.max(0, 12-files.length));
        port.replace([...files, ...added]);
        persist();
        port.refresh();
        return added.length;
      }
    };
  }

  function install(port) {
    const watermark = port.stage.querySelector('.stage-watermark');
    if (watermark) watermark.textContent = 'erbapp.';
    let storage;
    try { storage = window.localStorage; } catch {}
    const controller = createController(port, storage);
    const make = (tag, className, text) => {
      const node = document.createElement(tag);
      if (className) node.className = className;
      if (text) node.textContent = text;
      return node;
    };
    const button = (text, action) => {
      const node = make('button', 'utility-button', text);
      node.type = 'button'; node.onclick = action;
      return node;
    };
    let drawer=null, list=null, status=null, clear=null, confirmation=null, shownGroup=null;
    const manage = button('Dosyaları yönet', () => drawer ? closeManager() : openManager());
    manage.id = 'nashi-manage-files'; manage.setAttribute('aria-expanded','false');
    port.root.querySelector('.desktop-toolbar').append(manage);
    function closeManager(){
      if(!drawer)return false;
      drawer.remove();drawer=null;confirmation=null;manage.setAttribute('aria-expanded','false');manage.focus?.();return true;
    }
    function renderRows(){
      if(!drawer)return;
      if(shownGroup!==port.group()){confirmation?.remove();confirmation=null;shownGroup=port.group();status.textContent='';}
      list.replaceChildren();const files=port.files();clear.disabled=!files.length;
      if(!files.length)list.append(make('p','nashi-file-manager-note','Bu sekmede dosya yok.'));
      for(const file of files){
        const row=make('div','nashi-file-manager-row'),label=make('div','nashi-file-manager-name');
        label.append(make('strong','',file.name),make('small','',file.user?'Senin eklediğin dosya'+(file.blob?' · '+Math.ceil(file.blob.size/1024)+' KB':''):'Örnek dosya'));
        const remove=button('Kaldır',()=>{
          const removed=controller.remove([file.id]);
          status.textContent=removed ? file.name+' listeden kaldırıldı. '+port.files().length+' dosya kaldı.' : 'Dosya zaten listede değil.';
        });
        remove.setAttribute('aria-label',file.name+' dosyasını listeden kaldır');row.append(label,remove);list.append(row);
      }
    }
    function confirmClear(){
      confirmation?.remove();const group=port.group();
      confirmation=make('div','erbapp-file-confirm');confirmation.setAttribute('role','group');confirmation.setAttribute('aria-label','Liste temizlensin mi?');
      confirmation.append(make('p','',port.files().length+' dosya listeden kaldırılacak. Telefonundaki asıl dosyalar korunur.'));
      confirmation.append(button('Vazgeç',()=>{confirmation?.remove();confirmation=null;}),button('Listeden kaldır',()=>{
        if(port.group()!==group)return;
        confirmation.remove();confirmation=null;const count=controller.clear();status.textContent=count+' dosya listeden kaldırıldı.';
      }));
      drawer.append(confirmation);confirmation.scrollIntoView?.({block:'nearest'});
    }
    function openManager(){
      if(drawer){renderRows();return;}
      drawer=make('section','erbapp-file-drawer');drawer.setAttribute('role','region');drawer.setAttribute('aria-label','Dosyaları yönet');
      const header=make('div','erbapp-file-drawer-header');header.append(make('h2','','Dosyaları yönet'),button('Kapat',closeManager));
      drawer.append(header,make('p','nashi-file-manager-note','Kaldırma işlemi uygulamadaki kopyayı kaldırır. Telefonundaki asıl dosyayı silmez.'));
      list=make('div','nashi-file-manager-list');status=make('p','nashi-file-manager-note');status.setAttribute('role','status');
      clear=button('Bu listeyi temizle',confirmClear);
      const actions=make('div','nashi-file-manager-actions');actions.append(clear);
      if(port.allowSamples!==false)actions.append(button('Örnekleri geri getir',()=>{controller.restore();status.textContent='Bu sekmenin örnekleri geri getirildi.';}));
      drawer.append(list,actions,status);port.stage.before(drawer);shownGroup=port.group();manage.setAttribute('aria-expanded','true');renderRows();
      drawer.scrollIntoView?.({block:'nearest'});
    }
    window.ErbappFileManager={close:closeManager};
    let empty;
    return {
      filter: () => controller.filter(),
      render() {
        const files = port.files();
        renderRows();
        manage.setAttribute('aria-label', 'Dosyaları yönet, ' + files.length + ' dosya');
        port.stage.classList.toggle('nashi-stage-empty', files.length === 0);
        const format = port.root.querySelector('.sample-format-row');
        if (format) format.hidden = !files.some(file => file.sample && !file.user);
        if (!files.length && !empty) {
          empty = make('div', 'nashi-empty-state');
          empty.append(make('strong', '', 'Dosyaların için hazır'),
            make('p', '', 'Telefonundan bir görsel, PDF veya EPUB seçerek başla.'),
            button('Dosya ekle', port.pick));
          if(port.allowSamples!==false)empty.append(button('Örnekleri geri getir', () => controller.restore()));
          port.stage.append(empty);
        } else if (files.length && empty) { empty.remove(); empty = null; }
        const tip = port.stage.querySelector('.stage-tip');
        if (tip) tip.textContent = 'Dosyaya dokun, ardından aşağıdan bir işlem seç.';
      }
    };
  }
  window.NashiFileList = {createController, install};
})();
