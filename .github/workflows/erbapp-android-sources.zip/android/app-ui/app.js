/* Dedicated offline Android workspace. No desktop preview or remote site code. */
(() => {
 'use strict';
 const root=document.getElementById('playground'),stage=document.getElementById('demo-stage');
 const input=root.querySelector('input[type=file]'),notice=document.getElementById('workspace-status');
 const tabs=[...root.querySelectorAll('[role=tab]')];
 const state={group:'image',files:[],selected:[],library:[]};
 let workspace,manager,tools;
 const urls=new Set();
 const url=blob=>{const value=URL.createObjectURL(blob);urls.add(value);return value;};
 const release=value=>{if(value&&urls.delete(value))URL.revokeObjectURL(value);};
 const make=(tag,text='')=>{const node=document.createElement(tag);node.textContent=text;return node;};
 const selection=()=>state.files.filter(file=>state.selected.includes(file.id));
 const uuid=()=>crypto.randomUUID?.()||'10000000-1000-4000-8000-100000000000'.replace(/[018]/g,value=>(Number(value)^crypto.getRandomValues(new Uint8Array(1))[0]&(15>>Number(value)/4)).toString(16));
 function render(){
  for(const card of stage.querySelectorAll('.demo-file'))card.remove();
  for(const file of state.files){
   const card=make('button');card.type='button';card.className='demo-file';card.dataset.fileId=file.id;
   card.setAttribute('aria-label',file.name);card.setAttribute('aria-pressed',String(state.selected.includes(file.id)));
   const preview=make('span');preview.className='file-preview';
   if(file.kind==='image'){const image=make('img');image.src=file.url;image.alt='';preview.append(image);}
   else preview.textContent=file.ext.toUpperCase();
   const name=make('span',file.name);name.className='filename';card.append(preview,name);
   card.onclick=event=>{
    state.selected=event.shiftKey?(state.selected.includes(file.id)?state.selected.filter(id=>id!==file.id):[...state.selected,file.id]):[file.id];
    render();
   };
   stage.append(card);
  }
  for(const tab of tabs)tab.setAttribute('aria-selected',String(tab.dataset.group===state.group));
  workspace?.remember();manager?.render();tools?.render();
 }
 function removeResult(id){
  const result=state.library.find(file=>file.id===id);if(result)release(result.url);
  state.library=state.library.filter(file=>file.id!==id);document.getElementById('library-count').textContent=String(state.library.length);
 }
 function addResult(name,blob){
  if(!(blob instanceof Blob)||!blob.size)throw Error('Boş çıktı kaydedilemez.');
  const result={id:uuid(),name,blob,url:url(blob)};state.library.unshift(result);
  let total=state.library.reduce((sum,file)=>sum+file.blob.size,0);
  while(state.library.length>6||total>96*1024*1024){const oldest=state.library.at(-1);total-=oldest.blob.size;removeResult(oldest.id);}
  document.getElementById('library-count').textContent=String(state.library.length);return result;
 }
 workspace=ErbappWorkspace.install({state:()=>state,samples:()=>[],model:(name,kind)=>({name,kind}),
  uuid,url,notice:text=>{notice.textContent=text;},
  display:(group,files,selected)=>Object.assign(state,{group,files,selected}),render});
 manager=NashiFileList.install({root,stage,allowSamples:false,group:()=>state.group,files:()=>state.files,
  replace:files=>{state.files=files;const kept=new Set(files.map(file=>file.id));state.selected=state.selected.filter(id=>kept.has(id));},
  release:file=>{workspace.remove(file.id);release(file.url);},refresh:render,samples:()=>[],pick:()=>input.click()});
 tools=ErbappRealTools.install({stage,pick:()=>input.click(),group:()=>state.group,selection,
  selectAll:()=>{state.selected=state.files.map(file=>file.id);render();},result:addResult});
 for(const tab of tabs)tab.onclick=()=>workspace.switchGroup(tab.dataset.group);
 input.onchange=()=>{const files=[...input.files];input.value='';void workspace.importFiles(files);};
 document.getElementById('demo-library').onclick=()=>{
  const panel=ErbappOverlay.open('Kitaplık','Çıktıları Kaydet ile telefona kaydet. Buradan kaldırmak kaydedilmiş dosyayı silmez.');
  const body=make('div');body.className='nashi-file-manager-body';panel.append(body);
  function rows(){
   body.replaceChildren();if(!state.library.length)body.append(make('p','Henüz çıktı yok.'));
   for(const result of state.library){
    const row=make('div');row.className='library-entry';const link=make('a',result.name+' · Kaydet ↓');link.href=result.url;link.download=result.name;link.className='erbapp-output-link';
    const remove=make('button','Kitaplıktan kaldır');remove.type='button';remove.setAttribute('aria-label',result.name+' çıktısını kitaplıktan kaldır');remove.onclick=()=>{removeResult(result.id);rows();};
    row.append(make('p',result.name),link,remove);body.append(row);
   }
  }
  rows();
 };
 workspace.switchGroup('image');
 window.ErbappAndroid={ready:workspace.ready};
})();
