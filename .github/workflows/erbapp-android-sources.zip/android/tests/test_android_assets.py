"""The APK must build using only its Android sources, pinned engines and notices."""
import hashlib
import importlib.util
import json
import pathlib
import shutil
import tempfile
import unittest
from html.parser import HTMLParser

ROOT = pathlib.Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('standalone_android_assets', ROOT / 'scripts/prepare_android.py')
pack = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pack)


class Page(HTMLParser):
    def __init__(self):
        super().__init__()
        self.scripts, self.tabs = [], []

    def handle_starttag(self, tag, attributes):
        attrs = dict(attributes)
        if tag == 'script':
            self.scripts.append(attrs['src'])
        if attrs.get('role') == 'tab':
            self.tabs.append(attrs['data-group'])


class AndroidAssets(unittest.TestCase):
    def test_full_app_packages_without_repository_docs_or_root_license(self):
        with tempfile.TemporaryDirectory() as folder:
            path = pathlib.Path(folder)
            android = path / 'only-android'
            shutil.copytree(ROOT, android, ignore=shutil.ignore_patterns('build', '__pycache__', '.gradle'))
            target = path / 'assets'
            info = pack.prepare(android, target, False)
            self.assertEqual(info['runtime'], 'android-only')
            page = (target / 'web/tr/index.html').read_text()
            parsed = Page()
            parsed.feed(page)
            self.assertEqual(parsed.tabs, ['image', 'pdf', 'epub'])
            self.assertTrue(all(not value.startswith(('https:', 'http:')) for value in parsed.scripts))
            self.assertIn('../erbapp/app.js', ''.join(parsed.scripts))
            self.assertNotIn('assets/playground.js', page)
            self.assertLess(page.index('Content-Security-Policy'), page.index('<script'))
            manifest = json.loads((target / 'web/erbapp/asset-manifest.json').read_text())
            for name, digest in manifest.items():
                self.assertEqual(hashlib.sha256((target / name).read_bytes()).hexdigest(), digest)
            for name in ['Nashi-MIT.txt', 'pdf-lib-MIT.txt', 'DejaVu-Embedded-License.txt', 'Android-MIT.txt']:
                self.assertTrue((target / 'web/notices' / name).exists())

    def test_missing_runtime_audit_blocks_assets_before_writing(self):
        with tempfile.TemporaryDirectory() as folder:
            android = pathlib.Path(folder) / 'android'
            shutil.copytree(ROOT, android, ignore=shutil.ignore_patterns('build', '__pycache__', '.gradle'))
            with self.assertRaises(RuntimeError):
                pack.prepare(android, pathlib.Path(folder) / 'assets')
            self.assertFalse((pathlib.Path(folder) / 'assets').exists())


if __name__ == '__main__':
    unittest.main()
