"""The APK must build using only its Android sources, pinned engines and notices."""
import hashlib
import importlib.util
import json
import pathlib
import shutil
import subprocess
import tempfile
import unittest
from html.parser import HTMLParser

ROOT = pathlib.Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('standalone_android_assets', ROOT / 'scripts/prepare_android.py')
pack = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pack)


class Page(HTMLParser):
    def __init__(self):
        super().__init__()
        self.scripts, self.tabs = [], []

    def handle_starttag(self, tag, attributes):
        attrs = dict(attributes)
        if tag == 'script':
            self.scripts.append(attrs['src'])
        if attrs.get('role') == 'tab':
            self.tabs.append(attrs['data-group'])


class AndroidAssets(unittest.TestCase):
    def test_full_app_packages_without_repository_docs_or_root_license(self):
        with tempfile.TemporaryDirectory() as folder:
            path = pathlib.Path(folder)
            android = path / 'only-android'
            shutil.copytree(ROOT, android, ignore=shutil.ignore_patterns('build', '__pycache__', '.gradle'))
            target = path / 'assets'
            info = pack.prepare(android, target, False)
            self.assertEqual(info['runtime'], 'android-only')
            page = (target / 'web/tr/index.html').read_text()
            parsed = Page()
            parsed.feed(page)
            self.assertEqual(info['interface'], 'classic-nashi')
            self.assertTrue(all(not value.startswith(('https:', 'http:')) for value in parsed.scripts))
            self.assertIn('../assets/playground.js', ''.join(parsed.scripts))
            self.assertNotIn('../erbapp/app.js', ''.join(parsed.scripts))
            raw=(android/'classic-ui/assets/playground.js').read_text()
            adapted=(target/'web/assets/playground.js').read_text()
            hooks=''.join((android/'scripts'/name).read_text() for name in ['workspace_hook.js','editor_dialog_hook.js','file_list_hook.js','classic_hook.js'])
            restored=adapted.replace(hooks,'',1).replace(pack.MEDIA_NEW,pack.MEDIA_OLD,1).replace('Seçilen videodan gerçek PNG oluşturur.','Örnek videodan gerçek PNG oluşturur.')
            self.assertEqual(restored,raw)
            self.assertIn(pack.MEDIA_NEW,adapted)
            for name in ['site.css','playground.css','wheel-geometry.mjs']:
                self.assertEqual((target/'web/assets'/name).read_bytes(),(android/'classic-ui/assets'/name).read_bytes())
            self.assertLess(page.index('Content-Security-Policy'), page.index('<script'))
            manifest = json.loads((target / 'web/erbapp/asset-manifest.json').read_text())
            for name, digest in manifest.items():
                self.assertEqual(hashlib.sha256((target / name).read_bytes()).hexdigest(), digest)
            for name in ['Nashi-MIT.txt', 'pdf-lib-MIT.txt', 'DejaVu-Embedded-License.txt', 'Android-MIT.txt']:
                self.assertTrue((target / 'web/notices' / name).exists())

    def test_missing_runtime_audit_blocks_assets_before_writing(self):
        with tempfile.TemporaryDirectory() as folder:
            android = pathlib.Path(folder) / 'android'
            shutil.copytree(ROOT, android, ignore=shutil.ignore_patterns('build', '__pycache__', '.gradle'))
            with self.assertRaises(RuntimeError):
                pack.prepare(android, pathlib.Path(folder) / 'assets')
            self.assertFalse((pathlib.Path(folder) / 'assets').exists())

    def test_changed_classic_source_cannot_silently_replace_the_original_design(self):
        with tempfile.TemporaryDirectory() as folder:
            android=pathlib.Path(folder)/'android'
            shutil.copytree(ROOT,android,ignore=shutil.ignore_patterns('build','__pycache__','.gradle'))
            (android/'classic-ui/assets/playground.css').write_text('simplified replacement')
            with self.assertRaisesRegex(RuntimeError,'Klasik arayüz'):
                pack.prepare(android,pathlib.Path(folder)/'assets',False)

    def test_native_media_connection_uses_actual_blob_and_has_no_sample_fallback(self):
        code="const files=[{blob:new Blob(['my own media'])}];"+pack.MEDIA_NEW+"mediaBlob.text().then(value=>process.stdout.write(value));"
        result=subprocess.run(['node','-e',code],capture_output=True,text=True,check=True)
        self.assertEqual(result.stdout,'my own media')
        missing=subprocess.run(['node','-e',"const files=[{}];"+pack.MEDIA_NEW],capture_output=True,text=True)
        self.assertNotEqual(missing.returncode,0)
        self.assertIn('Kendi video veya ses dosyanı',missing.stderr)


if __name__ == '__main__':
    unittest.main()
