import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {webcrypto} from 'node:crypto';
import {PDFLib} from './runtime-libs.mjs';

class Element {
 constructor(tag='div') {this.tag=tag;this.children=[];this.attributes={};this.dataset={};this.style={};this.value='';this._text='';this.inert=false;this.classList={toggle:(name,on)=>{const set=new Set((this.className||'').split(' ').filter(Boolean));on?set.add(name):set.delete(name);this.className=[...set].join(' ');}};}
 set textContent(value){this._text=String(value);this.children=[];}
 get textContent(){return this._text+this.children.map(node=>node.textContent).join('');}
 append(...nodes){for(const node of nodes){node.parent=this;this.children.push(node);}if(this.tag==='select'&&!this.value&&nodes[0])this.value=nodes[0].value;}
 replaceChildren(...nodes){this.children=[];this._text='';this.value='';this.append(...nodes);}
 remove(){if(this.parent)this.parent.children=this.parent.children.filter(node=>node!==this);}
 before(node){const index=this.parent.children.indexOf(this);node.parent=this.parent;this.parent.children.splice(index,0,node);}
 setAttribute(name,value){this.attributes[name]=String(value);}
 querySelectorAll(selector){return this.children.flatMap(node=>[...(matches(node,selector)?[node]:[]),...node.querySelectorAll(selector)]);}
 querySelector(selector){return this.querySelectorAll(selector)[0]||null;}
 scrollIntoView(){}
 focus(){}
}
const matches=(node,selector)=>selector.startsWith('.')?(node.className||'').split(' ').includes(selector.slice(1)):
 selector==='[role=tab]'?node.attributes.role==='tab':selector==='input[type=file]'?node.tag==='input'&&node.type==='file':false;
const all=node=>[node,...node.children.flatMap(all)];
const button=(node,name)=>{const found=all(node).find(item=>item.tag==='button'&&(item.attributes['aria-label']||item.textContent)===name);assert.ok(found,'Missing button '+name);return found;};
const file=async(name,type)=>Object.assign(new Blob([await fs.readFile(new URL('fixtures/epub/'+name,import.meta.url))],{type}),{name});

async function setup(crypto=webcrypto){
 const body=new Element('body'),root=new Element('main'),toolbar=new Element(),tabs=new Element(),stage=new Element(),input=new Element('input'),notice=new Element('p'),library=new Element('button'),count=new Element('span');
 root.id='playground';toolbar.className='desktop-toolbar';stage.id='demo-stage';stage.className='demo-stage';input.type='file';notice.id='workspace-status';library.id='demo-library';count.id='library-count';count.textContent='0';library.append(count);toolbar.append(library);
 for(const [group,name]of [['image','Görseller'],['pdf','PDF'],['epub','EPUB']]){const tab=new Element('button');tab.setAttribute('role','tab');tab.dataset.group=group;tab.textContent=name;tabs.append(tab);}
 body.append(root);root.append(toolbar,tabs,notice,stage,input);
 const document={body,documentElement:{dataset:{erbappRuntime:'android'}},createElement:tag=>new Element(tag),getElementById:id=>all(body).find(node=>node.id===id)||null};
 let counter=0;const blobs=new Map(),revoked=[];const blobURL={createObjectURL:blob=>{const value='blob:owned-'+(++counter);blobs.set(value,blob);return value;},revokeObjectURL:value=>{revoked.push(value);blobs.delete(value);}};
 const storage=new Map();const window={localStorage:{getItem:key=>storage.get(key)||null,setItem:(key,value)=>storage.set(key,value)}};
 for(const name of ['workspace','file-list'])new Function('window','document',await fs.readFile(new URL('../shared-ui/'+name+'.js',import.meta.url),'utf8'))(window,document);
 const converters=new Function('PDFLib','const window={};'+await fs.readFile(new URL('../shared-ui/converters.js',import.meta.url),'utf8')+';return window.ErbappConverters;')(PDFLib);
 new Function('window','document','ErbappConverters',await fs.readFile(new URL('../shared-ui/real-tools.js',import.meta.url),'utf8'))(window,document,converters);
 let panel;const overlay={open:()=>{panel=new Element('section');body.append(panel);root.inert=true;return panel;},close:()=>{panel?.remove();root.inert=false;return true;}};
 const source=await fs.readFile(new URL('../app-ui/app.js',import.meta.url),'utf8');
 new Function('window','document','URL','Blob','crypto','ErbappWorkspace','NashiFileList','ErbappRealTools','ErbappOverlay',source)(window,document,blobURL,Blob,crypto,window.ErbappWorkspace,window.NashiFileList,window.ErbappRealTools,overlay);
 await window.ErbappAndroid.ready;
 const upload=async files=>{input.files=files;input.onchange();await new Promise(resolve=>setImmediate(resolve));};
 return {window,body,root,tabs,stage,notice,count,blobs,revoked,upload,document,get panel(){return panel;}};
}

test('Android controller retains imported files across tabs and manager removes only the owned copy',async()=>{
 const e=await setup(),source=await file('image.png','image/png'),before=await source.arrayBuffer();await e.upload([source]);
 assert.equal(e.stage.querySelectorAll('.demo-file').length,1);const owned=e.stage.querySelectorAll('.demo-file')[0];
 button(e.tabs,'PDF').onclick();assert.equal(e.stage.querySelectorAll('.demo-file').length,0);
 button(e.tabs,'Görseller').onclick();assert.equal(e.stage.querySelectorAll('.demo-file')[0].attributes['aria-label'],owned.attributes['aria-label']);
 e.document.getElementById('nashi-manage-files').onclick();button(e.body,'image.png dosyasını listeden kaldır').onclick();
 assert.equal(e.stage.querySelectorAll('.demo-file').length,0);assert.equal(e.revoked.length,1);assert.deepEqual(await source.arrayBuffer(),before);
 assert.ok(!all(e.body).some(node=>node.textContent==='Örnekleri geri getir'));
});

test('Android controller connects a real PDF input through converter, result link and removable library copy',async()=>{
 const e=await setup(),source=await file('source-a.pdf','application/pdf'),before=await source.arrayBuffer();await e.upload([source]);
 assert.equal(e.document.getElementById('erbapp-output-format').value,'pdf:extract');
 await e.document.getElementById('erbapp-run').onclick();assert.equal(e.count.textContent,'1');
 const link=all(e.body).find(node=>node.tag==='a'&&node.download);assert.ok(link);const output=e.blobs.get(link.href);
 const pdf=await PDFLib.PDFDocument.load(await output.arrayBuffer());assert.equal(pdf.getPageCount(),3);
 e.document.getElementById('demo-library').onclick();assert.equal(e.root.inert,true);
 button(e.panel,'source-a-sayfalar.pdf çıktısını kitaplıktan kaldır').onclick();assert.equal(e.count.textContent,'0');
 assert.equal(e.blobs.has(link.href),false);assert.equal(e.stage.querySelectorAll('.demo-file').length,1);assert.deepEqual(await source.arrayBuffer(),before);
});

test('Android workspace UUID fallback imports files without requiring randomUUID support',async()=>{
 const e=await setup({getRandomValues:bytes=>webcrypto.getRandomValues(bytes)});await e.upload([await file('source-a.pdf','application/pdf')]);
 const id=e.stage.querySelectorAll('.demo-file')[0].dataset.fileId;
 assert.match(id,/^user-[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/);
});

test('Session library evicts its oldest Blob after six real PDF results',async()=>{
 const e=await setup();await e.upload([await file('source-a.pdf','application/pdf')]);
 for(let i=0;i<7;i++)await e.document.getElementById('erbapp-run').onclick();
 assert.equal(e.count.textContent,'6');assert.equal(e.revoked.length,1);
 assert.equal(e.blobs.size,7); // One input and six output Blobs.
});
