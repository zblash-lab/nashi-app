import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
const source=await fs.readFile(new URL('../classic-ui/assets/playground.js',import.meta.url),'utf8');
const line=source.split('\n').find(line=>line.startsWith('function audioWav(e)'));
const encode=new Function(line+';return audioWav;')();
const samples=new Float32Array([0,.25,.5,.75,1,0,-.5,-1]);
const buffer={sampleRate:4,length:samples.length,numberOfChannels:1,getChannelData:()=>samples};
test('Original audio tool emits actual selected PCM samples in a new WAV',async()=>{
 const wav=await encode({id:'trimAudio',audioBuffer:buffer,values:{start:.5,end:1.5}}).arrayBuffer(),data=new DataView(wav);
 assert.equal(new TextDecoder().decode(wav.slice(0,4)),'RIFF');assert.equal(data.getUint32(24,true),4);assert.equal(data.getUint32(40,true),16);
 assert.equal(data.getInt16(44,true),Math.trunc(.5*32767));assert.equal(data.getInt16(56,true),0);assert.deepEqual([...samples],[0,.25,.5,.75,1,0,-.5,-1]);
});
test('Original audio channel control produces mono samples with requested gain',async()=>{
 const wav=await encode({id:'audioChannels',audioBuffer:buffer,values:{channels:'mono',left:50,right:100}}).arrayBuffer(),data=new DataView(wav);
 assert.equal(data.getUint16(22,true),1);assert.equal(data.getInt16(48,true),Math.trunc(.5*.5*32767));
});
