"""Bounded, event-pumping polling under the strict-CSP acceptance harness."""
import importlib.util
import pathlib
import unittest
from unittest.mock import patch

ROOT = pathlib.Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('browser_wait', ROOT / 'android/scripts/browser_wait.py')
wait = importlib.util.module_from_spec(spec)
spec.loader.exec_module(wait)


class Page:
    def __init__(self, values):
        self.values = iter(values)
        self.elapsed = 0
        self.expressions = []

    def evaluate(self, expression):
        self.expressions.append(expression)
        value = next(self.values)
        if isinstance(value, Exception):
            raise value
        return value

    def wait_for_timeout(self, milliseconds):
        self.elapsed += milliseconds / 1000


class BrowserWait(unittest.TestCase):
    def test_delayed_native_bytes_are_returned_after_pumping_events(self):
        transfer = {'size': 3, 'chunks': ['YWJj']}
        page = Page([None, None, transfer])
        with patch.object(wait.time, 'monotonic', side_effect=lambda: page.elapsed):
            actual = wait.wait_for_page_value(page, 'window.__nativeExport')
        self.assertIs(actual, transfer)
        self.assertEqual(page.elapsed, 0.1)
        self.assertEqual(page.expressions, ['window.__nativeExport'] * 3)

    def test_indexeddb_false_is_polled_until_committed_deletion(self):
        page = Page([False, True])
        self.assertTrue(wait.wait_for_page_value(page, '() => readDeletion()'))
        self.assertGreater(page.elapsed, 0)

    def test_timeout_is_bounded_and_identifies_the_missing_result(self):
        page = Page([None] * 10)
        with patch.object(wait.time, 'monotonic', side_effect=lambda: page.elapsed):
            with self.assertRaisesRegex(TimeoutError, '100 ms.*native byte transfer'):
                wait.wait_for_page_value(page, 'window.__nativeExport', timeout=100,
                                         description='native byte transfer')
        self.assertLessEqual(page.elapsed, 0.1)

    def test_page_errors_are_not_retried_or_hidden(self):
        page = Page([RuntimeError('database unavailable')])
        with self.assertRaisesRegex(RuntimeError, 'database unavailable'):
            wait.wait_for_page_value(page, '() => readDeletion()')
        self.assertEqual(page.elapsed, 0)


if __name__ == '__main__':
    unittest.main()
