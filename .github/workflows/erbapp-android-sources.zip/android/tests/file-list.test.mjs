import {test} from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import fs from 'node:fs/promises';
const source = await fs.readFile(new URL('../shared-ui/file-list.js',import.meta.url),'utf8');
const hook = await fs.readFile(new URL('../scripts/file_list_hook.js',import.meta.url),'utf8');

// Exercise real event handlers and the real state adapter without a browser server.
class Element {
  constructor(tag='div') { this.tag=tag;this.children=[];this.attributes={};this.textContent='';this.removed=false;
    this.classList={toggle:(name,on)=>{this.attributes[name]=on;}}; }
  append(...nodes) { for(const node of nodes){node.parent=this;this.children.push(node);} }
  replaceChildren(...nodes) { this.children=[];this.append(...nodes); }
  setAttribute(key,value){this.attributes[key]=String(value);}
  remove(){this.removed=true;if(this.parent)this.parent.children=this.parent.children.filter(node=>node!==this);}
}
function descendants(node){return [node,...node.children.flatMap(descendants)];}
function button(node,text){const found=descendants(node).find(n=>n.tag==='button'&&!n.removed&&n.textContent===text);assert.ok(found,'Missing button: '+text);return found;}
function setup({saved=new Map(),blockedStorage=false}={}) {
  const toolbar=new Element(),stage=new Element(),tip=new Element(),format=new Element();
  const root={querySelector:s=>s==='.desktop-toolbar'?toolbar:s==='.sample-format-row'?format:null};
  stage.querySelector=s=>s==='.stage-tip'?tip:null;
  stage.before=drawer=>{dialogs.push(drawer);};
  let seq=20,picks=0,rendered=0;const dialogs=[],revoked=[];
  const sample=(name,id)=>({id,name,sample:true,kind:'image',ext:'jpg',url:'https://appassets.androidplatform.net/demo.jpg'});
  const user={id:'user',name:'kendi-fotografim.png',sample:false,user:true,url:'blob:user'};
  const state={group:'image',files:[sample('orchard.jpg','sample'),user],selected:['sample','user'],
    shelf:[{...user},{id:'other-group'}],float:{selected:['user','other-group']},library:[{id:'output',url:'blob:result'}],
    urls:new Set(['blob:user','blob:result']),drag:null,wheel:{}};
  const context={root,stage,state,Set,JSON,document:{createElement:tag=>new Element(tag)},
    URL:{revokeObjectURL:url=>revoked.push(url)},erbappWorkspace:{remove(){}},
    specs:{image:[['orchard.jpg','image'],['weekend.png','image']],video:[['orchard.jpg','video']]},
    fileModel:(name,kind)=>({...sample(name,'new-'+(++seq)),kind}),
    closeWheel(){state.wheel=null;},
    showDialog(title,subtitle){const dialog=new Element('dialog');dialog.title=title;dialog.subtitle=subtitle;dialogs.push(dialog);return dialog;},
    closeEditor(){if(dialogs.length)dialogs.at(-1).closed=true;},input:{click(){picks++;}},
    renderFiles(){rendered++;}
  };
  context.window=context;
  context.ErbappOverlay={open:context.showDialog,close:context.closeEditor};
  context.localStorage={getItem:key=>{if(blockedStorage)throw Error('storage disabled');return saved.get(key)??null;},
    setItem:(key,value)=>{if(blockedStorage)throw Error('storage disabled');saved.set(key,value);}};
  vm.createContext(context);vm.runInContext(source,context);vm.runInContext(hook,context);
  const render=()=>context.renderFiles();render();
  return {state,saved,toolbar,stage,format,tip,dialogs,revoked,sample,user,render,
    open(){if(!dialogs.length||dialogs.at(-1).removed)button(toolbar,'Dosyaları yönet').onclick();return dialogs.at(-1);},
    get picks(){return picks;},get rendered(){return rendered;}};
}

test('Manager removes the chosen sample from actual state and remembers it after restart',()=>{
  const e=setup(),dialog=e.open();
  button(dialog,'Kaldır').onclick();
  assert.deepEqual(e.state.files.map(f=>f.id),['user']);
  assert.deepEqual(e.state.selected,['user']);
  const next=setup({saved:e.saved});
  assert.deepEqual(next.state.files.map(f=>f.id),['user']);
  next.state.files.push(next.sample('orchard.webp','changed-format'));next.render();
  assert.ok(!next.state.files.some(f=>f.id==='changed-format'));
});

test('Removing an imported file clears its selection and pinned copy, preserving other pins and outputs',()=>{
  const e=setup();e.state.files=[e.user];e.state.selected=['user'];e.render();
  button(e.open(),'Kaldır').onclick();
  assert.equal(e.state.files.length,0);assert.equal(e.state.selected.length,0);
  assert.deepEqual(e.state.shelf.map(f=>f.id),['other-group']);
  assert.deepEqual(e.state.float.selected,['other-group']);
  assert.deepEqual(e.state.library,[{id:'output',url:'blob:result'}]);
  assert.deepEqual(e.revoked,['blob:user']);assert.ok(e.state.urls.has('blob:result'));
});

test('Clear requires confirmation and cancelling leaves files intact',()=>{
  const e=setup();button(e.open(),'Bu listeyi temizle').onclick();
  const confirm=descendants(e.dialogs.at(-1)).find(node=>node.className==='erbapp-file-confirm');assert.equal(confirm.attributes['aria-label'],'Liste temizlensin mi?');
  assert.equal(e.state.files.length,2);button(confirm,'Vazgeç').onclick();
  assert.equal(e.state.files.length,2);
});

test('Confirmed clear shows empty state and the system file picker entry still works',()=>{
  const e=setup();button(e.open(),'Bu listeyi temizle').onclick();
  button(e.dialogs.at(-1),'Listeden kaldır').onclick();
  assert.equal(e.state.files.length,0);
  assert.equal(e.format.hidden,true);assert.equal(e.stage.attributes['nashi-stage-empty'],true);
  button(e.stage,'Dosya ekle').onclick();assert.equal(e.picks,1);
  button(e.stage,'Örnekleri geri getir').onclick();
  assert.equal(e.state.files.length,2);assert.ok(e.state.files.every(f=>f.sample));
  assert.equal(e.stage.attributes['nashi-stage-empty'],false);
});

test('Restoring samples preserves imported files and never duplicates visible samples',()=>{
  const e=setup();const dialog=e.open();button(dialog,'Örnekleri geri getir').onclick();
  assert.equal(e.state.files.length,3);assert.ok(e.state.files.includes(e.user));
  button(dialog,'Örnekleri geri getir').onclick();assert.equal(e.state.files.length,3);
});

test('Hidden sample preferences apply only to their category',()=>{
  const e=setup();button(e.open(),'Kaldır').onclick();
  e.state.group='video';e.state.files=[e.sample('orchard.jpg','other-category')];e.render();
  assert.equal(e.state.files.length,1);
});

test('Unavailable localStorage still allows session removal',()=>{
  const e=setup({blockedStorage:true});button(e.open(),'Kaldır').onclick();
  assert.deepEqual(e.state.files.map(f=>f.id),['user']);
});

test('A Blob referenced by a saved library result is not revoked on stage removal',()=>{
  const e=setup();e.state.files=[e.user];e.state.library=[{url:'blob:user'}];e.render();
  button(e.open(),'Kaldır').onclick();assert.equal(e.revoked.length,0);
  assert.deepEqual(e.state.library,[{url:'blob:user'}]);
});

test('Restoring samples respects the twelve-file stage limit',()=>{
  const e=setup();e.state.files=Array.from({length:12},(_,i)=>({...e.user,id:'user-'+i}));e.render();
  button(e.open(),'Örnekleri geri getir').onclick();assert.equal(e.state.files.length,12);
});
