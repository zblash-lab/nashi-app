import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
const hook=await fs.readFile(new URL('../scripts/classic_hook.js',import.meta.url),'utf8');
const textSource=await fs.readFile(new URL('../shared-ui/text-tools.js',import.meta.url),'utf8');
const textApi=new Function('const window={};'+textSource+';return window.ErbappTextConverters;')();
function setup(files){
 const state={group:files[0]?.ext==='epub'?'epub':'image',files,selected:files.map(file=>file.id),library:[],urls:new Set()};
 const operations=[],previews=[],actions=[],toasts=[];let renderCount=0,many=false,opened=false;
 const wheel=function(...args){return args;};
 const tool={render(){},show(){opened=true;},execute:async op=>{operations.push(op);},busy:false};
 const toolbar={append(){}},count={textContent:0};
 const result=(name,blob)=>{const value={name,blob,url:'blob:output'};state.library.unshift(value);return value;};
 const returned=new Function('window','stage','input','root','state','selection','addResult','renderFiles','selectFile','toast','convert','openWheel','fileAction','openActionPreview','openConversionPreview','closeWheel','el','$','URL',hook+'\nreturn {openWheel,convert,addResult,renderFiles,fileAction};')(
  {ErbappRealTools:{install:()=>tool},ErbappTextConverters:textApi},{classList:{toggle:(key,on)=>{many=on;}}},{},{},state,()=>files,result,()=>{renderCount++;},()=>{},(...args)=>toasts.push(args),()=>{throw Error('Original sample converter must not run');},wheel,id=>actions.push(id),(...args)=>previews.push(args),ext=>previews.push(ext),()=>{},()=>({}),selector=>selector==='#library-count'?count:toolbar,{revokeObjectURL(){}});
 return {state,operations,previews,actions,toasts,wheel,...returned,get many(){return many;},get renderCount(){return renderCount;}};
}
const file=(ext,text='user')=>({id:'input',ext,name:'benim.'+ext,kind:ext==='png'?'image':'file',user:true,blob:new Blob([text])});
test('Classic convert, tools and actions wheels remain the original implementation',()=>{
 const e=setup([file('png')]);assert.equal(e.openWheel,e.wheel);
 for(const mode of ['convert','tools','actions'])assert.deepEqual(e.openWheel(mode,20,30),[mode,20,30]);
});
test('Image and EPUB wheel choices dispatch to real engines',async()=>{
 const image=setup([file('png')]);await image.convert('jpg');assert.deepEqual(image.operations,['image:jpg']);
 const book=setup([file('epub')]);await book.convert('pdf');assert.deepEqual(book.operations,['epub:pdf']);
});
test('A document wheel choice converts the actual file, never sample text',async()=>{
 const e=setup([file('txt','Kendi Türkçe notum')]);await e.convert('md');assert.equal(await e.state.library[0].blob.text(),'Kendi Türkçe notum');
});
test('Unsupported wheel targets and null preview results cannot add fake files',async()=>{
 const e=setup([file('png')]);await e.convert('docx');assert.deepEqual(e.previews,['docx']);e.addResult('sahte.docx',null);assert.equal(e.state.library.length,0);
});
test('Floating cards are preserved for small groups and larger groups remain reachable',()=>{
 const e=setup([file('png')]);e.renderFiles();assert.equal(e.many,false);e.state.files=Array.from({length:4},()=>file('png'));e.renderFiles();assert.equal(e.many,true);assert.equal(e.renderCount,2);
});
test('Imports from the simplified release receive distinct classic card positions',()=>{
 const e=setup([file('png'),{...file('png'),id:'second'},{...file('png'),id:'third'}]);e.renderFiles();
 assert.equal(new Set(e.state.files.map(file=>file.x+':'+file.y)).size,3);assert.equal(e.many,false);
 const before=e.state.files.map(file=>[file.x,file.y]);e.renderFiles();assert.deepEqual(e.state.files.map(file=>[file.x,file.y]),before);
});
test('Copy path does not put a fabricated desktop path on the Android clipboard',()=>{
 const e=setup([file('png')]);e.fileAction('copyPath');assert.equal(e.actions.length,0);assert.match(e.previews[0][1],/Android/);e.fileAction('float');assert.deepEqual(e.actions,['float']);
});
test('A twelve-file export keeps every result available in the classic session library',()=>{
 const e=setup([file('png')]);for(let i=0;i<12;i++)e.addResult('cikti-'+i+'.png',new Blob(['actual output']));
 assert.equal(e.state.library.length,12);assert.ok(e.state.library.every(item=>item.blob.size>0));
});
