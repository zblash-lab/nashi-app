import {test} from 'node:test';import assert from 'node:assert/strict';import vm from 'node:vm';import fs from 'node:fs/promises';
const source=await fs.readFile(new URL('../shared-ui/workspace.js',import.meta.url),'utf8');
const deletionStorage=new WeakMap();
function setup(saved=new Map(),override={}){
 const state={group:'image',files:[],selected:[]},notices=[];let seq=0,workspace;
 if(!deletionStorage.has(saved))deletionStorage.set(saved,new Map());const local=deletionStorage.get(saved);
 const context={console,Map,Set,Date,Blob,localStorage:{getItem:key=>local.get(key)||null,setItem:(key,value)=>local.set(key,value)}};context.window=context;vm.createContext(context);vm.runInContext(source,context);
 const store={list:async()=>[...saved.values()],put:async record=>{saved.set(record.id,record);return record;},remove:async id=>{saved.delete(id);return true;},...override};
 workspace=context.ErbappWorkspace.install({state:()=>state,samples:group=>[{id:'sample-'+group,name:'ornek.'+(group==='image'?'jpg':group),sample:true}],
  model:(name,kind)=>({name,kind,x:.2,y:.3}),uuid:()=>String(++seq),url:blob=>'blob:'+blob.size+'-'+(++seq),notice:text=>notices.push(text),
  display:(group,files,selected)=>Object.assign(state,{group,files,selected}),render:()=>workspace?.remember()},store);
 workspace.switchGroup('image');return {workspace,state,saved,notices};
}
const file=(name,type='image/png',size=10)=>Object.assign(new Blob([new Uint8Array(size)],{type}),{name});
test('Imported file and selection survive multiple tab changes',async()=>{
 const e=setup();await e.workspace.importFiles([file('benim.png')]);const first=e.state.files.find(f=>f.user),selection=[...e.state.selected];
 e.workspace.switchGroup('pdf');e.workspace.switchGroup('epub');e.workspace.switchGroup('image');
 assert.ok(e.state.files.includes(first));assert.deepEqual([...e.state.selected],selection);assert.equal(e.saved.size,1);
});
test('Removed user never reappears on tab change or restart',async()=>{
 const e=setup();await e.workspace.importFiles([file('silinecek.png')]);const id=e.state.files.find(f=>f.user).id;
 e.state.files=e.state.files.filter(f=>f.id!==id);e.workspace.remove(id);e.workspace.remember();
 e.workspace.switchGroup('pdf');e.workspace.switchGroup('image');assert.ok(!e.state.files.some(f=>f.id===id));
 const next=setup(e.saved);await next.workspace.ready;assert.ok(!next.state.files.some(f=>f.id===id));
});
test('Stored blobs restore on a fresh workspace without relying on old blob URLs',async()=>{
 const e=setup();await e.workspace.importFiles([file('kalici.png')]);const next=setup(e.saved);await next.workspace.ready;
 assert.ok(next.state.files.some(f=>f.name==='kalici.png'&&f.blob.size===10&&f.url.startsWith('blob:')));
});
test('Mixed EPUB/PDF/image uploads go into their own preserved tabs',async()=>{
 const e=setup();await e.workspace.importFiles([file('kitap.epub','application/epub+zip'),file('belge.pdf','application/pdf'),file('foto.png')]);
 assert.equal(e.state.group,'epub');assert.ok(e.state.files.some(f=>f.name==='kitap.epub'));
 e.workspace.switchGroup('pdf');assert.ok(e.state.files.some(f=>f.name==='belge.pdf'));
 e.workspace.switchGroup('image');assert.ok(e.state.files.some(f=>f.name==='foto.png'));
});
test('Storage quota failure preserves the current session and explains the limit',async()=>{
 const e=setup(new Map(),{put:async()=>{throw Error('quota');}});await e.workspace.importFiles([file('yerel.png')]);
 e.workspace.switchGroup('pdf');e.workspace.switchGroup('image');assert.ok(e.state.files.some(f=>f.name==='yerel.png'));assert.ok(e.notices.some(t=>t.includes('bu oturum')));
});
test('A tab change during an unfinished save does not discard the upload',async()=>{
 let finish,started;const saving=new Promise(resolve=>{started=resolve;});
 const e=setup(new Map(),{put:()=>{started();return new Promise(resolve=>{finish=resolve;});}});
 const pending=e.workspace.importFiles([file('bekleyen.png')]);await saving;e.workspace.switchGroup('pdf');finish(true);await pending;
 assert.equal(e.state.group,'pdf');e.workspace.switchGroup('image');assert.ok(e.state.files.some(f=>f.name==='bekleyen.png'));
});
test('Unknown file types are rejected before changing workspace or stored files',async()=>{
 const e=setup();await e.workspace.importFiles([file('uygulama.exe','application/octet-stream')]);assert.equal(e.saved.size,0);assert.equal(e.state.files.length,1);
});

test('A failed database deletion cannot resurrect a removed file after restart',async()=>{
 const e=setup(new Map(),{remove:async()=>{throw Error('database unavailable');}});await e.workspace.importFiles([file('kaldir.png')]);const id=e.state.files.find(f=>f.user).id;
 e.state.files=e.state.files.filter(f=>f.id!==id);e.workspace.remove(id);e.workspace.remember();
 const next=setup(e.saved);await next.workspace.ready;assert.ok(!next.state.files.some(f=>f.name==='kaldir.png'));
});

test('Classic media, text, subtitle and archive inputs remain in their own tabs after restore',async()=>{
 const e=setup();await e.workspace.importFiles([file('ses.wav','audio/wav'),file('video.mp4','video/mp4'),file('notlar.txt','text/plain'),file('tablo.csv','text/csv'),file('altyazi.srt','text/plain'),file('paket.zip','application/zip')]);
 const next=setup(e.saved);await next.workspace.ready;
 for(const [group,name]of [['audio','ses.wav'],['video','video.mp4'],['document','notlar.txt'],['sheet','tablo.csv'],['subtitle','altyazi.srt'],['archive','paket.zip']]){
  next.workspace.switchGroup(group);const saved=next.state.files.find(item=>item.name===name);assert.ok(saved?.blob);assert.equal(saved.user,true);assert.equal(saved.sample,false);
 }
});
