import fs from 'node:fs/promises';import {existsSync} from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
export const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..');
async function umd(file){const module={exports:{}};new Function('module','exports',await fs.readFile(file,'utf8'))(module,module.exports);return module.exports;}
const pdf=root+'/android/vendor/pdf-lib-1.17.1.min.js';
export const PDFLib=await umd(pdf);
export const pako=await umd(root+'/android/vendor/pako-inflate-1.0.11.min.js');
