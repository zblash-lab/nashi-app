import {test} from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import fs from 'node:fs/promises';
const sources=await Promise.all(['../shared-ui/overlay.js','../shared-ui/editor-dialog.js','../scripts/editor_dialog_hook.js'].map(path=>fs.readFile(new URL(path,import.meta.url),'utf8')));
function setup(){
 let document;
 class Element{
  constructor(tag){this.tag=tag;this.children=[];this.attributes={};this.listeners={};this.style={overflow:'auto'};this.className='';this.classList={add:(...names)=>{this.className+=' '+names.join(' ');}};}
  append(...nodes){for(const node of nodes){node.parent=this;this.children.push(node);}}
  prepend(node){node.parent=this;this.children.unshift(node);}
  before(node){const parent=this.parent;node.parent=parent;parent.children.splice(parent.children.indexOf(this),0,node);}
  remove(){if(this.parent)this.parent.children=this.parent.children.filter(node=>node!==this);this.parent=null;}
  setAttribute(key,value){this.attributes[key]=value;}
  addEventListener(name,callback){this.listeners[name]=callback;}
  focus(){document.activeElement=this;}
  get isConnected(){return this===document.body||Boolean(this.parent?.isConnected);}
  matches(selector){return selector.split(',').includes(this.tag);}
  querySelectorAll(selector){const all=this.children.flatMap(node=>[node,...node.querySelectorAll('*')]);return selector==='*'?all:all.filter(node=>selector==='video,audio'?['video','audio'].includes(node.tag):node.tag==='button');}
  querySelector(selector){return this.querySelectorAll('*').find(node=>node.className.split(/\s+/).includes(selector.slice(1)));}
 }
 const body=new Element('body'),root=new Element('main'),stage=new Element('div'),trigger=new Element('button');root.inert=false;body.append(root);root.append(stage,trigger);
 document={body,activeElement:trigger,createElement:tag=>new Element(tag),getElementById:()=>root};
 const state={group:'epub',editor:null};let oldPreviews=0,renders=0,keys=0,closedWheels=0;
 const files=[{name:'kitap.epub',ext:'epub'}];
 const context={document,state,stage,console,icon:()=>new Element('svg'),selection:()=>files,
  closeWheel:()=>{closedWheels++;},showDialog:()=>{throw Error('Native HTML dialog must not be used');},closeEditor(){},
  openConversionPreview:()=>{oldPreviews++;return 'upstream';},renderFiles:()=>{renders++;},editorKey:()=>{keys++;},
  addResult:()=>{throw Error('Unsupported conversion must not create a result');}};
 context.window=context;vm.createContext(context);for(const source of sources)vm.runInContext(source,context);
 return {context,state,files,body,root,stage,trigger,document,Element,get renders(){return renders;},get keys(){return keys;},get oldPreviews(){return oldPreviews;},get closedWheels(){return closedWheels;}};
}
function text(node){return [node.textContent||'',...node.children.map(text)].join(' ');}
test('Real editor adapter opens an ordinary panel and closing restores page and state',()=>{
 const e=setup(),panel=e.context.showDialog('Görseli Kırp','Yeni kopya');
 assert.equal(panel.tag,'section');assert.ok(panel.className.includes('demo-dialog'));assert.ok(panel.querySelector('.editor-header'));
 assert.equal(e.state.editor.dialog,panel);assert.equal(e.root.inert,true);
 e.context.closeEditor();assert.equal(e.state.editor,null);assert.equal(e.root.inert,false);assert.equal(e.document.activeElement,e.trigger);
});
test('Escape pauses media and calls every cleanup once without recursive close',()=>{
 const e=setup(),panel=e.context.showDialog('Video','Önizleme'),media=new e.Element('video');let pauses=0,cleanups=0;
 media.pause=()=>{pauses++;};panel.append(media);e.state.editor.cleanup.push(()=>{cleanups++;});
 const overlay=e.body.children.at(-1);overlay.listeners.keydown({key:'Escape',preventDefault(){},stopPropagation(){}});
 assert.equal(pauses,1);assert.equal(cleanups,1);assert.equal(e.state.editor,null);assert.equal(e.root.inert,false);
 assert.equal(e.context.closeEditor(),false);
});
test('Replacing an editor cleans its resources and leaves only the replacement overlay',()=>{
 const e=setup(),first=e.context.showDialog('İlk','');let cleanups=0;e.state.editor.cleanup.push(()=>{cleanups++;});
 const second=e.context.showDialog('İkinci','');assert.equal(cleanups,1);assert.equal(first.isConnected,false);assert.equal(second.isConnected,true);
 assert.equal(e.body.children.filter(node=>node.className==='erbapp-modal-overlay').length,1);
 e.context.closeEditor();assert.equal(e.root.inert,false);
});
test('Unsupported EPUB target explains status and never runs simulated conversion',()=>{
 const e=setup(),panel=vm.runInContext("erbappEditorDialogs.unavailable(selection(),'docx')",e.context);
 assert.match(text(panel),/EPUB → DOCX/);assert.match(text(panel),/Bu sürümde desteklenmiyor/);assert.match(text(panel),/yeni dosya oluşturulmadı/);
 assert.equal(e.oldPreviews,0);assert.deepEqual(e.files,[{name:'kitap.epub',ext:'epub'}]);
 panel.querySelectorAll('button').find(node=>node.textContent==='Anladım').onclick();
 assert.equal(e.state.editor,null);assert.equal(e.root.inert,false);
});
test('Existing non-EPUB conversion preview still uses its original implementation',()=>{
 const e=setup();e.files[0].ext='docx';assert.equal(e.context.openConversionPreview('pdf'),'upstream');assert.equal(e.oldPreviews,1);
});
test('EPUB tab notice is visible only for the EPUB group',()=>{
 const e=setup(),note=e.stage.parent.children.find(node=>node.className==='erbapp-capability-note');
 e.context.renderFiles();assert.equal(note.hidden,false);assert.match(note.textContent,/EPUB → PDF/);
 e.state.group='image';e.context.renderFiles();assert.equal(note.hidden,true);assert.equal(e.renders,2);
});
test('Tool keyboard events reach the existing editor handler inside the overlay',()=>{
 const e=setup();e.context.showDialog('Araç','');e.body.children.at(-1).listeners.keydown({key:'s',ctrlKey:true,target:e.trigger,stopPropagation(){}});
 assert.equal(e.keys,1);
});
