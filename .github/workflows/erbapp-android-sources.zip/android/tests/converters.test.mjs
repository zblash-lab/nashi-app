import {test} from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs/promises';import {existsSync} from 'node:fs';import {createRequire} from 'node:module';import path from 'node:path';import {fileURLToPath} from 'node:url';
import {PDFLib,root} from './runtime-libs.mjs';
const api=new Function('PDFLib','const window={};'+await fs.readFile(root+'/android/shared-ui/converters.js','utf8')+'\nreturn window.ErbappConverters;')(PDFLib);
async function fixture(name,count){const doc=await PDFLib.PDFDocument.create();for(let i=0;i<count;i++)doc.addPage([200+i,300+i]).drawText('Page '+(i+1));const bytes=await doc.save();return {name,ext:'pdf',kind:'file',blob:new Blob([bytes],{type:'application/pdf'})};}
test('Actual PDF merge preserves all source pages in order',async()=>{
 const files=[await fixture('a.pdf',2),await fixture('b.pdf',3)],before=await files[0].blob.arrayBuffer(),out=await api.run(files,'pdf:merge'),pdf=await PDFLib.PDFDocument.load(await out[0].blob.arrayBuffer());
 assert.equal(pdf.getPageCount(),5);assert.deepEqual(pdf.getPages().map(p=>p.getWidth()),[200,201,200,201,202]);assert.deepEqual(await files[0].blob.arrayBuffer(),before);
});
test('PDF extraction keeps exactly the requested range',async()=>{
 const out=await api.run([await fixture('input.pdf',4)],'pdf:extract',{range:'2-3'}),pdf=await PDFLib.PDFDocument.load(await out[0].blob.arrayBuffer());assert.equal(pdf.getPageCount(),2);assert.deepEqual(pdf.getPages().map(p=>p.getWidth()),[201,202]);
});
test('PDF rotation modifies the output, retaining the source orientation',async()=>{
 const input=await fixture('input.pdf',2),out=await api.run([input],'pdf:rotate',{rotation:90}),pdf=await PDFLib.PDFDocument.load(await out[0].blob.arrayBuffer()),original=await PDFLib.PDFDocument.load(await input.blob.arrayBuffer());assert.deepEqual(pdf.getPages().map(p=>p.getRotation().angle),[90,90]);assert.equal(original.getPage(0).getRotation().angle,0);
});
test('Invalid page range fails without manufacturing an output',async()=>{await assert.rejects(api.run([await fixture('input.pdf',2)],'pdf:extract',{range:'4-7'}),/PDF dışında/);});
test('Sample placeholders and unsupported operations cannot produce fake files',async()=>{
 await assert.rejects(api.run([{name:'demo.epub',ext:'epub'}],'epub:pdf'),/kendi dosyanı/);
 await assert.rejects(api.run([await fixture('input.pdf',1)],'document:docx'),/henüz gerçek/);
});
