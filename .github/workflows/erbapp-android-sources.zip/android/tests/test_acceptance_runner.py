"""A failed converter must not suppress diagnostics for the other operations."""
import importlib.util
import pathlib
import unittest

path = pathlib.Path(__file__).resolve().parents[1] / 'scripts/acceptance_runner.py'
spec = importlib.util.spec_from_file_location('acceptance_runner_test', path)
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)


class AcceptanceRunner(unittest.TestCase):
    def test_all_ten_operations_run_even_if_first_and_middle_fail(self):
        seen = []
        checkpoints = []
        case = {}

        def exercise(name, result):
            seen.append(name)
            result['step'] = 'real operation ' + name
            if name in {'image-png', 'epub-pdf'}:
                raise RuntimeError('deliberate failure ' + name)

        runner.run_scenarios(exercise, case, lambda: checkpoints.append(len(seen)))
        self.assertEqual(seen, list(runner.SCENARIOS))
        self.assertEqual(case['status'], 'failed')
        failed = [item for item in case['scenarios'] if item['status'] == 'failed']
        self.assertEqual([item['name'] for item in failed], ['image-png', 'epub-pdf'])
        self.assertTrue(all('deliberate failure' in item['error'] for item in failed))
        self.assertEqual(checkpoints[-1], 10)

    def test_all_operations_are_mandatory_before_success(self):
        case = {}
        runner.run_scenarios(lambda name, item: None, case)
        self.assertEqual(case['status'], 'passed')
        self.assertEqual(len(case['scenarios']), 10)
        self.assertTrue(all(item['status'] == 'passed' for item in case['scenarios']))


if __name__ == '__main__':
    unittest.main()
