import importlib.util,json,pathlib,tempfile,unittest,xml.etree.ElementTree as ET
ROOT=pathlib.Path(__file__).resolve().parents[2]
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
prepare=module('prepare_web',ROOT/'android/scripts/prepare_web.py')
audit=module('audit_licenses',ROOT/'android/scripts/audit_licenses.py')
class Packaging(unittest.TestCase):
 def fixture(self,root):
  for name in prepare.REQUIRED:
   p=root/'docs'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('original fixture')
  (root/'docs/tr/index.html').write_text('<!doctype html><html><head></head><body><section id="playground"></section></body></html>')
  (root/'docs/assets/playground.js').write_text('// original processing fixture\nsetGroup(\'image\');\n')
  for name in ['LICENSE','Resources/licenses/pdf-lib.txt','android/LICENSE','android/licenses/Apache-2.0.txt']:
   p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('license fixture')
 def test_original_processing_code_stays_unchanged(self):
  with tempfile.TemporaryDirectory() as temp:
   root=pathlib.Path(temp);self.fixture(root);out=root/'output';prepare.prepare(root,out,False)
   for name in ['assets/playground.css','assets/demo/catalog.json']:
    self.assertEqual((out/'web'/name).read_bytes(),(root/'docs'/name).read_bytes())
   original=(root/'docs/assets/playground.js').read_text()
   adapted=(out/'web/assets/playground.js').read_text()
   self.assertEqual(adapted.replace(prepare.FILE_LIST_HOOK,'',1),original)
   self.assertIn('../erbapp/file-list.js',(out/'web/tr/index.html').read_text())
   self.assertIn('../../mobile/mobile.js',(out/'web/tr/index.html').read_text())
   self.assertTrue((out/'mobile/licenses.html').exists())
 def test_missing_real_asset_blocks_packaging(self):
  with tempfile.TemporaryDirectory() as temp:
   root=pathlib.Path(temp);self.fixture(root);(root/'docs/assets/demo/weekend.mp4').unlink()
   with self.assertRaises(RuntimeError):prepare.prepare(root,root/'out',False)
 def test_missing_license_audit_blocks_apk_assets(self):
  with tempfile.TemporaryDirectory() as temp:
   root=pathlib.Path(temp);self.fixture(root)
   with self.assertRaises(RuntimeError):prepare.prepare(root,root/'out')
 def test_apache_pom_is_identified(self):
  data=b'<project xmlns="http://maven.apache.org/POM/4.0.0"><licenses><license><name>Apache License 2.0</name><url>https://www.apache.org/licenses/LICENSE-2.0.txt</url></license></licenses></project>'
  self.assertEqual(audit.declared_licenses(data)[0]['url'],'https://www.apache.org/licenses/LICENSE-2.0.txt')
 def test_failed_license_audit_blocks_apk_assets(self):
  with tempfile.TemporaryDirectory() as temp:
   root=pathlib.Path(temp);self.fixture(root)
   report=root/'android/build/reports/license-audit.json';report.parent.mkdir(parents=True)
   report.write_text(json.dumps({'status':'failed','components':[],'errors':[{'component':'example','error':'unknown license'}]}))
   with self.assertRaises(RuntimeError):prepare.prepare(root,root/'out')
 def test_manifest_has_no_network_or_storage_permission(self):
  manifest=ET.parse(ROOT/'android/app/src/main/AndroidManifest.xml').getroot()
  self.assertEqual(manifest.findall('uses-permission'),[])
 def test_changed_playground_contract_blocks_packaging(self):
  with tempfile.TemporaryDirectory() as temp:
   root=pathlib.Path(temp);self.fixture(root)
   (root/'docs/assets/playground.js').write_text('// upstream entry point changed')
   with self.assertRaises(RuntimeError):prepare.prepare(root,root/'out',False)
 def test_duplicate_entry_point_is_rejected(self):
  with self.assertRaises(RuntimeError):prepare.patch_playground(prepare.MOBILE_INIT_MARKER*2)
if __name__=='__main__':unittest.main()
