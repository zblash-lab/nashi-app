"""Regression for GitHub's workflow-size limit and the two-file handoff."""
import importlib.util,pathlib,shutil,subprocess,tempfile,textwrap,unittest,zipfile
ROOT=pathlib.Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('split_bootstrap',ROOT/'android/scripts/make_bootstrap.py');bootstrap=importlib.util.module_from_spec(spec);spec.loader.exec_module(bootstrap)
class SplitBootstrap(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.folder=pathlib.Path(self.tmp.name)
  self.workflow=self.folder/'delivery/nashi-android.yml';self.archive=bootstrap.build(self.workflow)
  text=self.workflow.read_text();self.code=textwrap.dedent(text.split("          python3 - <<'PY'\n",1)[1].split('          PY\n',1)[0])
  self.checkout=self.folder/'checkout';(self.checkout/'.github/workflows').mkdir(parents=True)
 def run_code(self):return subprocess.run(['python3','-'],input=self.code,text=True,cwd=self.checkout,capture_output=True)
 def test_real_full_sources_fit_separate_archive_and_workflow_stays_small(self):
  self.assertLess(self.workflow.stat().st_size,50_000)
  self.assertLess(self.workflow.stat().st_size,bootstrap.MAX_WORKFLOW_BYTES)
  with zipfile.ZipFile(self.archive) as archive:
   font='android/vendor/fonts/DejaVuSans.ttf';self.assertEqual(archive.read(font),(ROOT/font).read_bytes())
 def test_two_files_extract_actual_application_sources(self):
  shutil.copy2(self.archive,self.checkout/'.github/workflows'/bootstrap.SOURCE_NAME)
  result=self.run_code();self.assertEqual(result.returncode,0,result.stderr)
  for name in ['android/app/build.gradle.kts','android/shared-ui/epub-engine.js','android/vendor/fonts/DejaVuSans.ttf']:
   self.assertEqual((self.checkout/name).read_bytes(),(ROOT/name).read_bytes())
  import json,hashlib
  report=json.loads((self.checkout/'android/build/reports/source-package.json').read_text())
  self.assertEqual(report['source_sha256'],hashlib.sha256(self.archive.read_bytes()).hexdigest())
  self.assertIn(report['version'],self.workflow.read_text())
 def test_modified_archive_is_rejected_before_extraction(self):
  (self.checkout/'.github/workflows'/bootstrap.SOURCE_NAME).write_bytes(self.archive.read_bytes()+b'tampered')
  result=self.run_code();self.assertNotEqual(result.returncode,0);self.assertIn('özeti eşleşmiyor',result.stderr);self.assertFalse((self.checkout/'android').exists())
 def test_missing_archive_has_actionable_error(self):
  result=self.run_code();self.assertNotEqual(result.returncode,0);self.assertIn(bootstrap.SOURCE_NAME,result.stderr);self.assertIn('.github/workflows',result.stderr)
if __name__=='__main__':unittest.main()
