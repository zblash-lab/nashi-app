import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
const source=await fs.readFile(new URL('../shared-ui/text-tools.js',import.meta.url),'utf8');
const api=new Function('const window={};'+source+';return window.ErbappTextConverters;')();
const file=(name,text)=>({name,ext:name.split('.').pop(),user:true,blob:new Blob([text],{type:'text/plain'})});
test('Text conversion reads actual Turkish user bytes and preserves the original',async()=>{
 const input=file('benim.txt','Benim ÇĞİÖŞÜ metnim.');const before=await input.blob.arrayBuffer();
 const [result]=await api.run([input],'md');assert.equal(await result.blob.text(),'Benim ÇĞİÖŞÜ metnim.');assert.deepEqual(await input.blob.arrayBuffer(),before);
});
test('HTML output escapes active markup instead of executing the source text',async()=>{
 const [result]=await api.run([file('notlar.md','<script>alert(1)</script> & veri')],'html');
 assert.match(await result.blob.text(),/&lt;script&gt;alert\(1\)&lt;\/script&gt; &amp; veri/);
});
test('CSV and TSV round trip preserves quoted delimiters, quotes and embedded newlines',async()=>{
 const input=file('tablo.csv','ad,not\r\n"Ayşe, Ece","iki\nsatır ve ""alıntı"""\r\n');
 const [tsv]=await api.run([input],'tsv');const [csv]=await api.run([file('ara.tsv',await tsv.blob.text())],'csv');
 assert.equal(await csv.blob.text(),'ad,not\r\n"Ayşe, Ece","iki\nsatır ve ""alıntı"""');
});
test('Subtitle conversion retains numeric dialogue and actual cues in UTF-8',async()=>{
 const srt=file('altyazi.srt','1\n00:00:01,000 --> 00:00:03,500\n2026\nMerhaba dünya\n');
 const [vtt]=await api.run([srt],'vtt');assert.match(await vtt.blob.text(),/WEBVTT\n\n00:00:01\.000 --> 00:00:03\.500\n2026\nMerhaba dünya/);
 const [txt]=await api.run([file('altyazi.vtt',await vtt.blob.text())],'txt');assert.equal(await txt.blob.text(),'2026\nMerhaba dünya');
});
test('Unterminated table quotes and invalid UTF-8 fail without producing substitute text',async()=>{
 await assert.rejects(api.run([file('kotu.csv','"bitmeyen alan')],'tsv'),/kapanmamış/);
 await assert.rejects(api.run([file('kotu.txt',new Uint8Array([0xc3,0x28]))],'md'),/UTF-8/);
});
test('Office files and demo placeholders cannot manufacture converted documents',async()=>{
 assert.equal(api.supports([file('belge.docx','not a word file')],'txt'),false);
 await assert.rejects(api.run([{name:'ornek.txt',ext:'txt'}],'md'),/kendi desteklenen/);
});
