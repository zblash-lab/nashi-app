"""Node test adapter only: parse genuine XML with Python's XML parser."""
import json,sys,pathlib,xml.etree.ElementTree as ET

def text(value):return {'nodeType':3,'textContent':value,'childNodes':[]}
def element(node):
 children=[]
 if node.text:children.append(text(node.text))
 for child in node:
  children.append(element(child))
  if child.tail:children.append(text(child.tail))
 attrs={key.split('}')[-1]:value for key,value in node.attrib.items()}
 for key,value in node.attrib.items():
  if key.startswith('{http://www.w3.org/1999/xlink}'):attrs['xlink:'+key.split('}')[-1]]=value
 return {'nodeType':1,'localName':node.tag.split('}')[-1],'attributes':attrs,'childNodes':children}
source=pathlib.Path(sys.argv[1]).read_text() if len(sys.argv)>1 else sys.stdin.read()
print(json.dumps({'nodeType':9,'childNodes':[element(ET.fromstring(source))]},ensure_ascii=False))
