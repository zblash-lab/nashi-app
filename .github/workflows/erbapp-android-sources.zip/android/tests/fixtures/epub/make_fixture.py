"""Create tiny, redistributable EPUB test books using only the standard library."""
import base64
import pathlib
import zipfile
import struct
import zlib

ROOT=pathlib.Path(__file__).parent
PNG=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+a2ioAAAAASUVORK5CYII=')
CONTAINER='''<?xml version="1.0"?><container xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="EPUB/package.opf" media-type="application/oebps-package+xml"/></rootfiles></container>'''
OPF='''<?xml version="1.0" encoding="utf-8"?><package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="id"><metadata xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:identifier id="id">erbapp-test</dc:identifier><dc:title>Çığ Öyküsü</dc:title><dc:creator>İpek Şen</dc:creator><dc:language>tr</dc:language></metadata><manifest><item id="second" href="second.xhtml" media-type="application/xhtml+xml"/><item id="first" href="chapters/first.xhtml" media-type="application/xhtml+xml"/><item id="pic" href="images/tiny.png" media-type="image/png"/></manifest><spine><itemref idref="first"/><itemref idref="second"/></spine></package>'''
FIRST='''<?xml version="1.0" encoding="utf-8"?><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Bölüm</title><script>throw new Error("EPUB scripts must never run");</script></head><body><h1>BİRİNCİ BÖLÜM</h1><p>İstanbul, Çığ, Şule ve ıslak çimenler. Türkçe: ÇĞİÖŞÜ çğıöşü.</p><p>Özgün içerik korunur; kitap okunabilir ve aranabilir.</p><img src="../images/tiny.png" alt="Test görseli"/>'''+''.join('<p>'+('Bu satır çok sayfalı kitap akışını ve sözcük bölünmesini denetler. '*20)+'</p>' for _ in range(18))+'''</body></html>'''
SECOND='''<?xml version="1.0"?><html xmlns="http://www.w3.org/1999/xhtml"><body><h1>İKİNCİ BÖLÜM</h1><p>Sonuç: Öykünün sonu. αβγ Привет.</p></body></html>'''
def write(path,encrypted=False):
 with zipfile.ZipFile(path,'w') as archive:
  archive.writestr('mimetype','application/epub+zip',compress_type=zipfile.ZIP_STORED)
  for name,data in [('META-INF/container.xml',CONTAINER),('EPUB/package.opf',OPF),('EPUB/chapters/first.xhtml',FIRST),('EPUB/second.xhtml',SECOND),('EPUB/images/tiny.png',PNG)]:archive.writestr(name,data,compress_type=zipfile.ZIP_DEFLATED)
  if encrypted:archive.writestr('META-INF/encryption.xml','<encryption/>')
if __name__=='__main__':
 write(ROOT/'turkce-kitap.epub');write(ROOT/'sifreli-kitap.epub',True)
 def chunk(kind,data):return struct.pack('>I',len(data))+kind+data+struct.pack('>I',zlib.crc32(kind+data)&0xffffffff)
 image=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',32,24,8,2,0,0,0))+chunk(b'IDAT',zlib.compress((b'\x00'+bytes([20,120,210])*32)*24))+chunk(b'IEND',b'')
 (ROOT/'image.png').write_bytes(image)

