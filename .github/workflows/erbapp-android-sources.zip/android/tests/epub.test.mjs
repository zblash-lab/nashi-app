import {test} from 'node:test';import assert from 'node:assert/strict';import vm from 'node:vm';import fs from 'node:fs/promises';import {existsSync,mkdtempSync,writeFileSync,rmSync} from 'node:fs';import os from 'node:os';import {createRequire} from 'node:module';import {spawnSync} from 'node:child_process';import path from 'node:path';import {fileURLToPath} from 'node:url';
import {PDFLib,pako,root} from './runtime-libs.mjs';
const ttfSource=await fs.readFile(root+'/android/shared-ui/truetype.js','utf8'),epubSource=await fs.readFile(root+'/android/shared-ui/epub-engine.js','utf8');
const context=new Function('pako','PDFLib','const window={};'+ttfSource+'\nconst ErbappTrueType=window.ErbappTrueType;\n'+epubSource+'\nreturn window;')(pako,PDFLib);
const engine=context.ErbappEpub,fixture=await fs.readFile(root+'/android/tests/fixtures/epub/turkce-kitap.epub'),font=await fs.readFile(root+'/android/vendor/fonts/DejaVuSans.ttf');
function parseXml(text){
 const temp=mkdtempSync(path.join(os.tmpdir(),'erbapp-xml-')),input=path.join(temp,'input.xml');writeFileSync(input,text);
 const result=spawnSync('python3',[root+'/android/tests/fixtures/epub/xml_tree.py',input],{encoding:'utf8',maxBuffer:5*1024*1024,timeout:10000});rmSync(temp,{recursive:true,force:true});if(result.status)throw Error(result.stderr||String(result.error));
 function wrap(node){node.childNodes=node.childNodes.map(wrap);if(node.nodeType!==3)Object.defineProperty(node,'textContent',{get(){return this.childNodes.map(child=>child.textContent).join('');}});
  node.getAttribute=name=>node.attributes?.[name]??null;node.getElementsByTagName=()=>node.childNodes.flatMap(child=>[...(child.nodeType===1?[child]:[]),...child.getElementsByTagName('*')]);return node;}
 return wrap(JSON.parse(result.stdout));
}
test('Real EPUB follows spine order, reads Turkish text and local PNG, never executes scripts',async()=>{
 const book=await engine.open(fixture,{parseXml});assert.equal(book.title,'Çığ Öyküsü');assert.equal(book.author,'İpek Şen');
 assert.ok(book.chapters[0].path.endsWith('first.xhtml'));assert.ok(book.chapters[1].path.endsWith('second.xhtml'));
 assert.ok(book.chapters[0].blocks.some(block=>block.text?.includes('ÇĞİÖŞÜ çğıöşü')));assert.ok(book.chapters[0].blocks.some(block=>block.type==='image'));assert.ok(!book.chapters.some(chapter=>chapter.blocks.some(block=>block.text?.includes('scripts must never run'))));
});
test('Real searchable multi-page PDF is produced without changing source bytes',async()=>{
 const original=Buffer.from(fixture),book=await engine.open(fixture,{parseXml}),bytes=await engine.pdf(book,font);assert.ok(Buffer.from(bytes).subarray(0,5).toString()==='%PDF-');assert.ok(fixture.equals(original));
 const pdf=await PDFLib.PDFDocument.load(bytes);assert.ok(pdf.getPageCount()>2);assert.equal(pdf.getTitle(),'Çığ Öyküsü');assert.equal(pdf.getAuthor(),'İpek Şen');
 await fs.mkdir(root+'/android/build/reports/epub',{recursive:true});await fs.writeFile(root+'/android/build/reports/epub/turkce-kitap.pdf',bytes);
});
test('Encrypted EPUB refuses conversion with a clear error',async()=>{
 const bytes=await fs.readFile(root+'/android/tests/fixtures/epub/sifreli-kitap.epub');await assert.rejects(engine.open(bytes,{parseXml}),/DRM/);
});
test('Archive truncation is rejected before reading any chapter',()=>{assert.throws(()=>engine.zip(fixture.subarray(0,fixture.length-12)),/ZIP/);});
test('Relative resources stay inside EPUB and external URLs are refused',()=>{
 assert.equal(engine.pathOf('../images/a.png','EPUB/chapters/one.xhtml'),'EPUB/images/a.png');assert.throws(()=>engine.pathOf('../../../outside','EPUB/a.xhtml'),/arşiv dışına/);assert.throws(()=>engine.pathOf('https://example.com/a.jpg'),/dış/);
});
test('Cancel stops reading and PDF generation without a fake result',async()=>{
 await assert.rejects(engine.open(fixture,{parseXml,signal:{aborted:true}}),/iptal/);
 const book=await engine.open(fixture,{parseXml});await assert.rejects(engine.pdf(book,font,{signal:{aborted:true}}),/iptal/);
});
test('Unsupported shaped writing is reported rather than silently corrupted',async()=>{
 const book={title:'Kitap',author:'',language:'tr',chapters:[{blocks:[{type:'text',text:'مرحبا',size:12}]}]};await assert.rejects(engine.pdf(book,font),/Sağdan sola/);
});
test('EPUB CRC damage is rejected instead of producing a partial book',()=>{
 const broken=Buffer.from(fixture),start=30+broken.readUInt16LE(26)+broken.readUInt16LE(28);broken[start]^=1;
 assert.throws(()=>engine.zip(broken).read('mimetype'),/bütünlük/);
});
test('Declared and actual inflated sizes are independently bounded',()=>{
 function altered(size){const broken=Buffer.from(fixture);let cursor=0;while((cursor=broken.indexOf(Buffer.from([0x50,0x4b,0x01,0x02]),cursor))>=0){const length=broken.readUInt16LE(cursor+28),name=broken.subarray(cursor+46,cursor+46+length).toString();if(name==='EPUB/chapters/first.xhtml'){broken.writeUInt32LE(size,cursor+24);return broken;}cursor+=4;}throw Error('Fixture central directory missing');}
 assert.throws(()=>engine.zip(altered(16*1024*1024)),/sınır/);
 assert.throws(()=>engine.zip(altered(1)).read('EPUB/chapters/first.xhtml'),/sınır/);
});
