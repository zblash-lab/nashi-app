"""APK-only acceptance must require Android assets and reject missing tests."""
import importlib.util
import pathlib
import unittest

path=pathlib.Path(__file__).resolve().parents[1]/'scripts/verify_converter_outputs.py'
spec=importlib.util.spec_from_file_location('output_scope',path)
outputs=importlib.util.module_from_spec(spec);spec.loader.exec_module(outputs)

def passed_case(name='android-html'):
 return {'case':name,'status':'passed','scenarios':[{'name':key,'status':'passed'} for key in outputs.EXPECTED_SCENARIOS]}

class AcceptanceScope(unittest.TestCase):
 def test_android_mode_accepts_android_case_without_any_website(self):
  outputs.validate_cases({'status':'passed','cases':[passed_case()]},True)
 def test_android_mode_rejects_missing_or_failed_or_website_only_cases(self):
  for result in [{'status':'passed','cases':[]},{'status':'failed','cases':[{'case':'android-html'}]},{'status':'passed','cases':[{'case':'mobile-web'}]}]:
   with self.subTest(result=result),self.assertRaises(RuntimeError):outputs.validate_cases(result,True)
 def test_optional_combined_mode_still_requires_all_cases(self):
  result={'status':'passed','cases':[passed_case(name) for name in ['desktop-web','mobile-web','android-html']]}
  outputs.validate_cases(result)
  with self.assertRaises(RuntimeError):outputs.validate_cases(result,True)
 def test_global_pass_cannot_hide_a_missing_failed_or_duplicate_operation(self):
  for variant in ['missing','failed','duplicate']:
   case=passed_case()
   if variant=='missing':case['scenarios'].pop()
   elif variant=='failed':case['scenarios'][0]['status']='failed'
   else:case['scenarios'][0]=case['scenarios'][1].copy()
   with self.subTest(variant=variant),self.assertRaises(RuntimeError):outputs.validate_cases({'status':'passed','cases':[case]},True)

if __name__=='__main__':unittest.main()
