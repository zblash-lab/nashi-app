"""APK-only acceptance must require Android assets and reject missing tests."""
import importlib.util
import pathlib
import unittest

path=pathlib.Path(__file__).resolve().parents[1]/'scripts/verify_converter_outputs.py'
spec=importlib.util.spec_from_file_location('output_scope',path)
outputs=importlib.util.module_from_spec(spec);spec.loader.exec_module(outputs)

class AcceptanceScope(unittest.TestCase):
 def test_android_mode_accepts_android_case_without_any_website(self):
  outputs.validate_cases({'status':'passed','cases':[{'case':'android-html'}]},True)
 def test_android_mode_rejects_missing_or_failed_or_website_only_cases(self):
  for result in [{'status':'passed','cases':[]},{'status':'failed','cases':[{'case':'android-html'}]},{'status':'passed','cases':[{'case':'mobile-web'}]}]:
   with self.subTest(result=result),self.assertRaises(RuntimeError):outputs.validate_cases(result,True)
 def test_optional_combined_mode_still_requires_all_cases(self):
  result={'status':'passed','cases':[{'case':name} for name in ['desktop-web','mobile-web','android-html']]}
  outputs.validate_cases(result)
  with self.assertRaises(RuntimeError):outputs.validate_cases(result,True)

if __name__=='__main__':unittest.main()
