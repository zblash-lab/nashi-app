"""Regression coverage for inherited Maven licenses and fail-closed packaging."""
import contextlib
import hashlib
import importlib.util
import io
import json
import pathlib
import tempfile
import unittest
from unittest.mock import patch

ROOT = pathlib.Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('audit_under_test', ROOT/'android/scripts/audit_licenses.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)


def pom(parent=None, license_url=None):
    body = ''
    if parent:
        body += '<parent>' + ''.join(
            f'<{key}>{value}</{key}>' for key, value in zip(('groupId', 'artifactId', 'version'), parent)
        ) + '</parent>'
    if license_url:
        body += f'<licenses><license><name>Test license</name><url>{license_url}</url></license></licenses>'
    return f'<project xmlns="http://maven.apache.org/POM/4.0.0">{body}</project>'.encode()


class LicenseAudit(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.file = pathlib.Path(self.temp.name)/'runtime.jar'
        self.file.write_bytes(b'test artifact')
        self.apache = 'https://www.apache.org/licenses/LICENSE-2.0.txt'
        self.child = ('com.google.guava', 'listenablefuture', '1.0')
        self.parent = ('com.google.guava', 'guava-parent', '26.0-android')

    def component(self, coordinate):
        return dict(zip(('group', 'name', 'version'), coordinate), file=str(self.file))

    def run_audit(self, documents, coordinates):
        def fetch(*coordinate):
            return documents[coordinate], 'https://repo.maven.apache.org/' + '/'.join(coordinate)
        with patch.object(audit, 'fetch_pom', side_effect=fetch) as fetched, contextlib.redirect_stdout(io.StringIO()):
            result = audit.audit([self.component(c) for c in coordinates])
        return result, fetched

    def test_listenablefuture_inherits_parent_license_and_keeps_evidence(self):
        documents = {self.child: pom(self.parent), self.parent: pom(license_url=self.apache)}
        result, fetched = self.run_audit(documents, [self.child])
        item = result['components'][0]
        self.assertEqual(result['status'], 'passed')
        self.assertEqual(item['license_source'], ':'.join(self.parent))
        self.assertEqual(len(item['pom_chain']), 2)
        self.assertEqual(item['pom_chain'][1]['pom_sha256'], hashlib.sha256(documents[self.parent]).hexdigest())
        self.assertEqual(item['artifact_sha256'], hashlib.sha256(self.file.read_bytes()).hexdigest())
        self.assertEqual(fetched.call_count, 2)

    def test_explicit_unknown_license_is_never_replaced_by_parent(self):
        documents = {self.child: pom(self.parent, 'https://example.org/unknown'), self.parent: pom(license_url=self.apache)}
        with self.assertRaises(audit.AuditFailure) as failed:
            self.run_audit(documents, [self.child])
        self.assertEqual(failed.exception.report['status'], 'failed')
        self.assertEqual(failed.exception.report['components'], [])

    def test_multilevel_parent_is_cached_across_components(self):
        grandparent = ('example', 'root', '1')
        other = ('example', 'other', '2')
        documents = {self.child: pom(self.parent), other: pom(self.parent),
                     self.parent: pom(grandparent), grandparent: pom(license_url=self.apache)}
        result, fetched = self.run_audit(documents, [self.child, other])
        self.assertEqual(len(result['components']), 2)
        self.assertEqual(fetched.call_count, 4)

    def test_parent_cycle_fails(self):
        with self.assertRaises(audit.AuditFailure) as failed:
            self.run_audit({self.child: pom(self.parent), self.parent: pom(self.child)}, [self.child])
        self.assertIn('Döngü', str(failed.exception))

    def test_missing_licenses_and_parent_fail(self):
        with self.assertRaises(audit.AuditFailure):
            self.run_audit({self.child: pom()}, [self.child])

    def test_empty_runtime_is_not_reported_as_passed(self):
        with self.assertRaises(audit.AuditFailure):
            audit.audit([])

    def test_all_bad_components_are_reported_together(self):
        other = ('example', 'other', '2')
        with self.assertRaises(audit.AuditFailure) as failed:
            self.run_audit({self.child: pom(), other: pom(license_url='https://example.org/unknown')}, [self.child, other])
        self.assertEqual(len(failed.exception.report['errors']), 2)

    def test_cli_writes_failed_report_and_returns_nonzero(self):
        components = pathlib.Path(self.temp.name)/'components.json'
        output = pathlib.Path(self.temp.name)/'reports/audit.json'
        components.write_text(json.dumps([self.component(self.child)]))
        with patch.object(audit, 'fetch_pom', return_value=(pom(), 'https://repo.maven.apache.org/test.pom')):
            with patch('sys.argv', ['audit', '--components', str(components), '--output', str(output)]):
                with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                    self.assertEqual(audit.main(), 1)
        self.assertEqual(json.loads(output.read_text())['status'], 'failed')


if __name__ == '__main__':
    unittest.main()
