import importlib.util,pathlib,tempfile,shutil,unittest,json
ROOT=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('web_audit',ROOT/'scripts/audit_web_vendor.py');audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
class WebVendorAudit(unittest.TestCase):
 def fixture(self,folder):
  shutil.copytree(ROOT/'vendor',folder/'vendor');shutil.copytree(ROOT/'licenses',folder/'licenses')
 def test_bundled_runtime_and_font_licenses_match_actual_files(self):self.assertEqual(audit.audit()['status'],'passed')
 def test_tampered_runtime_is_rejected(self):
  with tempfile.TemporaryDirectory() as temp:
   root=pathlib.Path(temp);self.fixture(root);(root/'vendor/pako-inflate-1.0.11.min.js').write_text('changed')
   with self.assertRaises(RuntimeError):audit.audit(root/'vendor',root/'licenses')
 def test_missing_font_license_is_rejected(self):
  with tempfile.TemporaryDirectory() as temp:
   root=pathlib.Path(temp);self.fixture(root);(root/'licenses/DejaVu-Embedded-License.txt').unlink()
   with self.assertRaises(RuntimeError):audit.audit(root/'vendor',root/'licenses')
 def test_unknown_license_is_rejected(self):
  with tempfile.TemporaryDirectory() as temp:
   root=pathlib.Path(temp);self.fixture(root);p=root/'vendor/manifest.json';data=json.loads(p.read_text());data['components'][0]['license']='unknown';p.write_text(json.dumps(data))
   with self.assertRaises(RuntimeError):audit.audit(root/'vendor',root/'licenses')
if __name__=='__main__':unittest.main()
