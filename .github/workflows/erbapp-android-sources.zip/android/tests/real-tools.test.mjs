import {test} from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs/promises';
const source=await fs.readFile(new URL('../shared-ui/real-tools.js',import.meta.url),'utf8'),png=await fs.readFile(new URL('fixtures/epub/image.png',import.meta.url));
function setup(failure=false){
 class Node{constructor(tag){this.tag=tag;this.children=[];this.value='';this.textContent='';this.attributes={};}append(...nodes){this.children.push(...nodes);if(this.tag==='select'&&!this.value&&nodes[0])this.value=nodes[0].value;}replaceChildren(){this.children=[];this.value='';}setAttribute(key,value){this.attributes[key]=value;}scrollIntoView(){}}
 let panel,calls=0,results=0;const state={group:'image',files:[{name:'kendi.png',kind:'image',ext:'png',user:true,blob:new Blob([png],{type:'image/png'})}]};
 const api=new Function('document','ErbappConverters','const window={};'+source+'\nreturn window.ErbappRealTools;')({createElement:tag=>new Node(tag)},{run:async(files,operation)=>{calls++;assert.equal(files[0].name,'kendi.png');assert.equal(operation,'image:png');if(failure)throw Error('decode failed');return [{name:'kendi.png',blob:new Blob([png],{type:'image/png'})}];}});
 const tools=api.install({stage:{before:node=>{panel=node;}},group:()=>state.group,selection:()=>state.files,selectAll(){},result:(name,blob)=>{results++;assert.equal(blob.type,'image/png');return {name,url:'blob:real-output'};}});
 const all=node=>[node,...node.children.flatMap(all)],find=id=>all(panel).find(node=>node.id===id);
 return {tools,state,panel,find,all,get calls(){return calls;},get results(){return results;}};
}
test('Visible operation button routes selected input to converter and exposes the real result URL',async()=>{
 const e=setup();assert.equal(e.find('erbapp-run').disabled,false);await e.find('erbapp-run').onclick();assert.equal(e.calls,1);assert.equal(e.results,1);const link=e.all(e.panel).find(node=>node.tag==='a');assert.equal(link.href,'blob:real-output');assert.equal(link.download,'kendi.png');assert.match(e.find('erbapp-conversion-status').textContent,/çıktı hazır/);
});
test('Conversion error is visible and cannot insert a fake download or library result',async()=>{
 const e=setup(true);await e.find('erbapp-run').onclick();assert.equal(e.results,0);assert.equal(e.all(e.panel).filter(node=>node.tag==='a').length,0);assert.match(e.find('erbapp-conversion-status').textContent,/decode failed/);assert.equal(e.find('erbapp-run').disabled,false);
});
test('Unsupported categories and sample placeholders cannot enable the actual export button',()=>{
 const e=setup();e.state.group='video';e.tools.render();assert.equal(e.find('erbapp-run').disabled,true);e.state.group='image';delete e.state.files[0].blob;e.tools.render();assert.equal(e.find('erbapp-run').disabled,true);
});
