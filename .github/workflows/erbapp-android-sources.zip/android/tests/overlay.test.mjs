import {test} from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import fs from 'node:fs/promises';
const script=await fs.readFile(new URL('../shared-ui/overlay.js',import.meta.url),'utf8');
function environment(){
 let document;
 class Node {
  constructor(tag){this.tag=tag;this.children=[];this.attributes={};this.listeners={};this.style={overflow:'auto'};}
  append(...nodes){for(const node of nodes){node.parent=this;this.children.push(node);}}
  remove(){if(this.parent)this.parent.children=this.parent.children.filter(node=>node!==this);this.parent=null;}
  setAttribute(key,value){this.attributes[key]=value;}
  addEventListener(name,handler){this.listeners[name]=handler;}
  focus(){document.activeElement=this;}
  get isConnected(){return this===document.body||Boolean(this.parent?.isConnected);}
  querySelectorAll(){return this.children.flatMap(node=>[...(node.tag==='button'?[node]:[]),...node.querySelectorAll()]);}
 }
 const body=new Node('body'),root=new Node('main'),trigger=new Node('button');root.inert=false;body.append(root,trigger);
 document={body,activeElement:trigger,getElementById:()=>root,createElement:tag=>new Node(tag)};
 const context={document};context.window=context;vm.createContext(context);vm.runInContext(script,context);
 return {api:context.ErbappOverlay,body,root,trigger,document};
}
test('Overlay is separate from root; close restores focus, input and scrolling',()=>{
 const e=environment(),panel=e.api.open('Dosyalar','Açıklama');
 assert.equal(panel.attributes.role,'dialog');assert.equal(e.root.inert,true);assert.equal(e.body.style.overflow,'hidden');
 assert.equal(e.api.close(),true);assert.equal(e.root.inert,false);assert.equal(e.body.style.overflow,'auto');assert.equal(e.document.activeElement,e.trigger);
 assert.equal(e.api.close(),false);
});
test('Switching to a confirmation does not leave stacked overlays or an inert page',()=>{
 const e=environment(),first=e.api.open('Yönet','Açıklama');e.api.open('Onay','Açıklama');
 assert.equal(first.isConnected,false);assert.equal(e.body.children.filter(node=>node.className==='erbapp-modal-overlay').length,1);
 e.api.close();assert.equal(e.root.inert,false);assert.equal(e.document.activeElement,e.trigger);
});
test('Escape closes the overlay and restores the page',()=>{
 const e=environment();e.api.open('Yönet','Açıklama');const overlay=e.body.children.at(-1);let prevented=false;
 overlay.listeners.keydown({key:'Escape',preventDefault(){prevented=true;},stopPropagation(){}});
 assert.equal(prevented,true);assert.equal(e.root.inert,false);assert.equal(overlay.isConnected,false);
});
test('Backdrop dismisses only when the backdrop itself is clicked',()=>{
 const e=environment(),panel=e.api.open('Yönet','Açıklama'),overlay=e.body.children.at(-1);
 overlay.listeners.click({target:panel});assert.equal(e.root.inert,true);
 overlay.listeners.click({target:overlay});assert.equal(e.root.inert,false);
});
