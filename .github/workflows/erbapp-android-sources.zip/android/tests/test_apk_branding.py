"""Manifest-based regressions for alias/target differences in AAPT badging."""
import importlib.util
import io
import json
import pathlib
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import zipfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('apk_branding', ROOT/'scripts/verify_apk_branding.py')
branding = importlib.util.module_from_spec(spec); spec.loader.exec_module(branding)
MANIFEST = (ROOT/'app/src/main/AndroidManifest.xml').read_text().replace('<manifest xmlns:', '<manifest package="lab.zblash.nashi" xmlns:')
# Some AAPT versions summarize the alias as its target; that is not the manifest.
BADGING = """application-label:'Erbapp'
launchable-activity: name='lab.zblash.nashi.MainActivity' label='Erbapp' icon=''
"""


class ApkBranding(unittest.TestCase):
    def reject(self, manifest):
        with self.assertRaises(RuntimeError): branding.check(BADGING, manifest)

    def test_alias_is_verified_even_when_badging_reports_target(self):
        self.assertEqual(branding.check(BADGING, MANIFEST)['launcher'], branding.LAUNCHER)

    def test_badging_without_launchable_summary_does_not_hide_valid_alias(self):
        self.assertEqual(branding.check("application-label:'Erbapp'", MANIFEST)['status'], 'passed')

    def test_absolute_compiled_activity_names_are_accepted(self):
        compiled = MANIFEST.replace('".MainActivity"', '"lab.zblash.nashi.MainActivity"').replace('".ErbappLauncher"', '"lab.zblash.nashi.ErbappLauncher"')
        self.assertEqual(branding.check(BADGING, compiled)['status'], 'passed')

    def test_compiled_resource_ids_resolve_to_expected_mipmap(self):
        for value in ['@0x7f080001', '@ref/0x7f080001', '@7F080001']:
            compiled = MANIFEST.replace('@mipmap/ic_erbapp', value)
            self.assertEqual(branding.check(BADGING, compiled, '  resource 0x7f080001 lab.zblash.nashi:mipmap/ic_erbapp\n')['status'], 'passed')

    def test_compiled_id_cannot_resolve_to_old_icon(self):
        with self.assertRaises(RuntimeError):
            branding.check(BADGING, MANIFEST.replace('@mipmap/ic_erbapp', '@0x7f080001'), '  resource 0x7f080001 mipmap/ic_launcher\n')

    def test_previous_label_is_rejected(self):
        with self.assertRaises(RuntimeError): branding.check(BADGING.replace("application-label:'Erbapp'", "application-label:'Nashi'"), MANIFEST)

    def test_previous_alias_is_rejected(self): self.reject(MANIFEST.replace('.ErbappLauncher', '.OldLauncher'))
    def test_wrong_target_is_rejected(self): self.reject(MANIFEST.replace('android:targetActivity=".MainActivity"', 'android:targetActivity=".Missing"'))
    def test_previous_icon_is_rejected(self): self.reject(MANIFEST.replace('@mipmap/ic_erbapp', '@mipmap/ic_launcher'))
    def test_disabled_alias_is_rejected(self): self.reject(MANIFEST.replace('android:enabled="true"', 'android:enabled="false"'))
    def test_missing_launcher_category_is_rejected(self): self.reject(MANIFEST.replace('android.intent.category.LAUNCHER', 'android.intent.category.DEFAULT'))
    def test_changed_package_is_rejected(self): self.reject(MANIFEST.replace('package="lab.zblash.nashi"', 'package="different.app"'))

    def test_multiple_launcher_entries_are_rejected(self):
        extra = '<activity android:name=".Other"><intent-filter><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/></intent-filter></activity>'
        self.reject(MANIFEST.replace('</application>', extra+'</application>'))

    def test_actual_logo_bytes_in_apk_archive_match_user_image(self):
        data = io.BytesIO()
        with zipfile.ZipFile(data, 'w') as archive:
            archive.writestr('res/drawable-nodpi-v4/erbapp_logo.jpg', (ROOT/'app/src/main/res/drawable-nodpi/erbapp_logo.jpg').read_bytes())
        data.seek(0)
        self.assertEqual(branding.inspect_logo(data)['status'], 'source-identical')

    def test_different_logo_bytes_are_reported_without_blocking(self):
        data = io.BytesIO()
        with zipfile.ZipFile(data, 'w') as archive: archive.writestr('res/drawable-nodpi-v4/erbapp_logo.jpg', b'old pear image')
        data.seek(0)
        report = branding.inspect_logo(data)
        self.assertEqual(report['status'], 'not-byte-identical')
        self.assertFalse(report['blocking'])

    def test_cosmetic_difference_never_fails_verified_apk_command(self):
        for path, contents in [('res/drawable/erbapp_logo.jpg', b'repacked image'),
                               ('res/a.jpg', b'renamed resource')]:
            with self.subTest(path=path), tempfile.TemporaryDirectory() as temporary:
                folder = pathlib.Path(temporary); apk = folder/'test.apk'; output = folder/'branding.json'
                with zipfile.ZipFile(apk, 'w') as archive: archive.writestr(path, contents)
                def run(command, **kwargs):
                    value = MANIFEST if command[1:3] == ['manifest', 'print'] else BADGING if command[1:3] == ['dump', 'badging'] else ''
                    return SimpleNamespace(returncode=0, stdout=value, stderr='')
                args = ['verify_apk_branding.py', '--aapt2', 'aapt2', '--apkanalyzer', 'apkanalyzer', '--apk', str(apk), '--output', str(output)]
                with patch('sys.argv', args), patch.object(branding.subprocess, 'run', side_effect=run):
                    self.assertEqual(branding.main(), 0)
                report = json.loads(output.read_text())
                self.assertEqual(report['status'], 'passed')
                self.assertFalse(report['logo']['blocking'])
                self.assertEqual((folder/'apk-manifest.xml').read_text(), MANIFEST)

    def test_analyzer_is_located_next_to_sdkmanager(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder = pathlib.Path(temporary); sdk = folder/'sdkmanager'; analyzer = folder/'apkanalyzer'
            sdk.touch(); analyzer.touch()
            with patch.object(branding.shutil, 'which', side_effect=lambda name: str(sdk) if name == 'sdkmanager' else None):
                self.assertEqual(branding.find_apkanalyzer(), str(analyzer))


if __name__ == '__main__': unittest.main()
