import ast
import importlib.util
import json
import os
import pathlib
import subprocess
import tempfile
import unittest
from unittest.mock import patch
import textwrap
import test_packaging as packaging_fixture
prepare=packaging_fixture.prepare

ROOT=pathlib.Path(__file__).resolve().parents[2]
def module(name,file):
    spec=importlib.util.spec_from_file_location(name,ROOT/'android/scripts'/file)
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
verify=module('verify_shared','verify_shared_outputs.py')
bootstrap=module('bootstrap_shared','make_bootstrap.py')

class SharedSite(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=pathlib.Path(self.tmp.name)/'repo';self.root.mkdir();packaging_fixture.Packaging().fixture(self.root)

    def test_web_has_management_and_logo_without_android_bridge(self):
        site=self.root/'site';prepare.prepare_site(self.root,site)
        page=(site/'tr/index.html').read_text()
        self.assertIn('data-erbapp-runtime="web"',page)
        self.assertIn('Erbapp · Yerel dosya araçları',page)
        self.assertIn('../erbapp/overlay.js',page)
        self.assertIn('../erbapp/editor-dialog.js',page)
        self.assertNotIn('../../mobile/mobile.js',page)
        self.assertEqual((site/'erbapp/erbapp-logo.jpg').read_bytes(),(ROOT/'android/app/src/main/res/drawable-nodpi/erbapp_logo.jpg').read_bytes())
        self.assertIn('tr/#playground',(site/'index.html').read_text())

    def test_native_includes_android_bridge_after_shared_ui(self):
        out=self.root/'android-assets';prepare.prepare(self.root,out,False)
        page=(out/'web/tr/index.html').read_text()
        self.assertIn('data-erbapp-runtime="android"',page)
        self.assertLess(page.index('../erbapp/overlay.js'),page.index('../erbapp/file-list.js'))
        self.assertLess(page.index('../erbapp/editor-dialog.js'),page.index('../erbapp/file-list.js'))
        self.assertLess(page.index('../erbapp/file-list.js'),page.index('../../mobile/mobile.js'))

    def test_android_and_web_share_identical_ui_hashes(self):
        android=self.root/'apk-assets';web=self.root/'site'
        prepare.prepare(self.root,android,False);prepare.prepare_site(self.root,web)
        verify.verify(android/'web',web)

    def test_changed_shared_script_is_rejected(self):
        android=self.root/'apk-assets';web=self.root/'site'
        prepare.prepare(self.root,android,False);prepare.prepare_site(self.root,web)
        with (web/'erbapp/file-list.js').open('a') as file:file.write('\n// unexpected edit')
        with self.assertRaises(RuntimeError):verify.verify(android/'web',web)

    def test_web_never_copies_native_assets_or_private_keys(self):
        (self.root/'android/private.p12').write_bytes(b'test private material')
        site=self.root/'site';prepare.prepare_site(self.root,site)
        self.assertFalse(list(site.rglob('*.p12')))
        self.assertFalse(list(site.rglob('mobile.js')))
        self.assertFalse(list(site.rglob('sign_apk.py')))

    def test_metadata_uses_ci_run_for_monotonic_version_code(self):
        with patch.dict(os.environ,{'GITHUB_RUN_NUMBER':'123','GITHUB_SHA':'commit-fixture'}):
            info=prepare.build_metadata()
        self.assertEqual(info['version_code'],1123)
        self.assertEqual(info['commit'],'commit-fixture')

    def test_bootstrap_replaces_stale_checkout_with_verified_delivery(self):
        destination=pathlib.Path(self.tmp.name)/'workflow.yml';bootstrap.build(destination)
        code=textwrap.dedent(destination.read_text().split("          python3 - <<'PY'\n",1)[1].split('          PY\n',1)[0])
        ast.parse(code)
        checkout=pathlib.Path(self.tmp.name)/'checkout';file=checkout/'android/app/build.gradle.kts'
        file.parent.mkdir(parents=True);file.write_text('stale previous Android source')
        stale=checkout/'android/old-script.js';stale.write_text('stale')
        archive=destination.with_name(bootstrap.SOURCE_NAME);target=checkout/'.github/workflows'/archive.name
        target.parent.mkdir(parents=True);target.write_bytes(archive.read_bytes())
        subprocess.run(['python3','-'],input=code,text=True,cwd=checkout,check=True,capture_output=True)
        self.assertEqual(file.read_bytes(),(ROOT/'android/app/build.gradle.kts').read_bytes())
        self.assertFalse(stale.exists())
        provenance=json.loads((checkout/'android/build/reports/source-package.json').read_text())
        self.assertIn('source_sha256',provenance)

if __name__=='__main__':unittest.main()
