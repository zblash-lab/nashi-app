"""Pin the update identity, fail closed, and keep private keys out of source ZIPs."""
import base64
import contextlib
import hashlib
import importlib.util
import io
import json
import pathlib
import tempfile
import types
import unittest
from unittest.mock import patch

ROOT = pathlib.Path(__file__).resolve().parents[2]

def module(name, file):
    spec = importlib.util.spec_from_file_location(name, ROOT/'android/scripts'/file)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value); return value

sign = module('sign_under_test', 'sign_apk.py')
bootstrap = module('bootstrap_under_test', 'make_bootstrap.py')

class Signing(unittest.TestCase):
    def config(self):
        return {'keystore_base64': base64.b64encode(b'fake key for parser test'*20).decode(),
                'alias': 'erbapp', 'store_password': 'fake-store-password', 'key_password': 'fake-key-password'}

    def test_missing_secret_fails_with_setup_instruction(self):
        with self.assertRaisesRegex(RuntimeError, 'ERBAPP_SIGNING eksik'): sign.load_config('')

    def test_valid_secret_decodes_keystore(self):
        config, data = sign.load_config(json.dumps(self.config()))
        self.assertEqual(config['alias'], 'erbapp')
        self.assertEqual(data, b'fake key for parser test'*20)

    def test_invalid_json_does_not_echo_secret(self):
        with self.assertRaises(RuntimeError) as failed: sign.load_config('{private-value')
        self.assertNotIn('private-value', str(failed.exception))

    def test_invalid_base64_is_rejected(self):
        config = self.config();config['keystore_base64'] = '!!!'
        with self.assertRaises(RuntimeError):sign.load_config(json.dumps(config))

    def test_alias_cannot_inject_command_options(self):
        config = self.config();config['alias'] = '-storepass dangerous'
        with self.assertRaises(RuntimeError):sign.load_config(json.dumps(config))

    def test_correct_certificate_is_accepted(self):
        sign.certificate_matches(b'certificate',hashlib.sha256(b'certificate').hexdigest())

    def test_changed_certificate_is_rejected(self):
        with self.assertRaises(RuntimeError):sign.certificate_matches(b'other certificate','0'*64)

    def test_multiple_apk_signers_are_rejected(self):
        output='Signer #1 certificate SHA-256 digest: '+'a'*64+'\nSigner #2 certificate SHA-256 digest: '+'b'*64+'\n'
        with self.assertRaises(RuntimeError):sign.signer_digest(output)

    def test_verified_digest_is_normalized(self):
        self.assertEqual(sign.signer_digest('Signer #1 certificate SHA-256 digest: '+'AB'*32+'\n'),'ab'*32)

    def test_public_pinned_certificate_matches_digest(self):
        certificate=(ROOT/'android/signing/certificate.der').read_bytes()
        sign.certificate_matches(certificate,(ROOT/'android/signing/certificate.sha256').read_text().strip())

    def test_bootstrap_refuses_private_keys(self):
        for name in ('accidentally-copied.p12', 'SECRET_ERBAPP_SIGNING.txt'):
            with self.subTest(name=name), tempfile.TemporaryDirectory() as tmp:
                root=pathlib.Path(tmp); (root/'android').mkdir()
                (root/'android'/name).write_bytes(b'fake private key')
                with patch.object(bootstrap,'ROOT',root):
                    with self.assertRaisesRegex(RuntimeError,'Özel imza anahtarı'):bootstrap.build(root/'workflow.yml')
                self.assertFalse((root/'workflow.yml').exists())

    def run_sign_flow(self, matching):
        with tempfile.TemporaryDirectory() as tmp:
            root=pathlib.Path(tmp); (root/'android/signing').mkdir(parents=True)
            der=b'public certificate fixture';digest=hashlib.sha256(der).hexdigest()
            (root/'android/signing/certificate.der').write_bytes(der)
            (root/'android/signing/certificate.sha256').write_text(digest)
            apk=root/'input.apk';apk.write_bytes(b'input fixture')
            output=root/'public/Erbapp.apk'
            def run(command, **kwargs):
                if command[1]=='sign':
                    pathlib.Path(command[command.index('--out')+1]).write_bytes(b'signed fixture')
                    return types.SimpleNamespace(stdout='')
                signer=digest if matching else '0'*64
                return types.SimpleNamespace(stdout=f'Signer #1 certificate SHA-256 digest: {signer}\n')
            with patch.object(sign,'ROOT',root), patch.object(sign,'check_key',return_value=(root/'fake.p12',{})):
                with patch.object(sign.subprocess,'run',side_effect=run):
                    with patch('sys.argv',['sign','--input',str(apk),'--output',str(output),'--apksigner','fake-apksigner']):
                        with patch.dict('os.environ',{'ERBAPP_SIGNING':json.dumps(self.config()),'GITHUB_ACTIONS':'false'}):
                            stdout,stderr=io.StringIO(),io.StringIO()
                            with contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):code=sign.main()
            # A test command double checks flow; it does not validate an actual APK signature.
            self.assertNotIn('fake-store-password',stdout.getvalue()+stderr.getvalue())
            self.assertNotIn('keystore_base64',(root/'android/build/reports/signing-status.json').read_text())
            if matching:
                self.assertEqual(code,0);self.assertEqual(output.read_bytes(),b'signed fixture')
                self.assertEqual(json.loads(output.with_name('signing-info.json').read_text())['certificate_sha256'],digest)
            else:
                self.assertEqual(code,1);self.assertFalse(output.exists())

    def test_final_apk_is_written_only_after_pinned_signer_matches(self):self.run_sign_flow(True)
    def test_wrong_signer_never_produces_public_apk(self):self.run_sign_flow(False)

if __name__ == '__main__':unittest.main()
