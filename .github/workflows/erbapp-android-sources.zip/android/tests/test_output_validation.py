"""Independent decoders reject truncated files and incorrect PDF contents."""
import contextlib
import importlib.util
import io
import json
import pathlib
import tempfile
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('output_validation', ROOT / 'scripts/verify_converter_outputs.py')
outputs = importlib.util.module_from_spec(spec)
spec.loader.exec_module(outputs)


class OutputValidation(unittest.TestCase):
    def test_real_fixture_png_has_expected_decoded_pixels(self):
        value = outputs.image_output(ROOT / 'tests/fixtures/epub/image.png', 'PNG')
        self.assertEqual(value['dimensions'], [32, 24])

    def test_format_headers_alone_cannot_pass_image_verification(self):
        with tempfile.TemporaryDirectory() as folder:
            for name, header, kind in [('a.png', b'\x89PNG\r\n\x1a\n', 'PNG'),
                                       ('a.jpg', b'\xff\xd8\xff', 'JPEG'),
                                       ('a.webp', b'RIFF\x10\x00\x00\x00WEBP', 'WEBP')]:
                path = pathlib.Path(folder) / name
                path.write_bytes(header)
                with self.subTest(name=name), self.assertRaises(Exception):
                    outputs.image_output(path, kind)

    def test_wrong_page_order_and_missing_rotation_are_rejected(self):
        source = ROOT / 'tests/fixtures/epub/source-a.pdf'
        for action in ['extract', 'merge', 'rotate']:
            with self.subTest(action=action), self.assertRaises(RuntimeError):
                outputs.pdf_output(source, action)

    def test_missing_outputs_are_all_reported_without_false_success(self):
        with tempfile.TemporaryDirectory() as folder:
            path = pathlib.Path(folder)
            case = {'case': 'android-html', 'status': 'passed', 'outputs': {},
                    'scenarios': [{'name': name, 'status': 'passed'} for name in outputs.EXPECTED_SCENARIOS]}
            (path / 'browser-results.json').write_text(json.dumps({'status': 'passed', 'cases': [case]}))
            with contextlib.redirect_stdout(io.StringIO()), self.assertRaises(RuntimeError):
                outputs.verify(path, android_only=True)
            result = json.loads((path / 'converter-output-verification.json').read_text())
            self.assertEqual(result['status'], 'failed')
            self.assertEqual(len(result['cases'][0]['outputs']), 8)
            self.assertTrue(all(item['status'] == 'failed' for item in result['cases'][0]['outputs']))


if __name__ == '__main__':
    unittest.main()
