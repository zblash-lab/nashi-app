import {test} from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import fs from 'node:fs/promises';
const source=await fs.readFile(new URL('../app/src/main/assets/mobile/mobile.js',import.meta.url),'utf8');
function environment(blob,{failChunk=false}={}) {
 const messages=[],received=[],status={textContent:''};let click;
 const context={location:{origin:'https://appassets.androidplatform.net'},document:{getElementById:()=>status,addEventListener:(name,fn)=>{if(name==='click')click=fn;}},
  setTimeout,clearTimeout,Uint8Array,String,Map,JSON,Blob,File,Event,Error,Promise,btoa,
  fetch:async()=>({blob:async()=>blob})};
 context.window=context;
 context.NashiNative={postMessage(raw){const message=JSON.parse(raw);messages.push(message);if(message.type==='chunk')received.push(Buffer.from(message.data,'base64'));queueMicrotask(()=>context.NashiNative.onmessage({data:JSON.stringify({token:message.token,ok:!(failChunk&&message.type==='chunk'),error:'native test rejection'})}));}};
 vm.createContext(context);vm.runInContext(source,context);
 return {messages,received,status,api:context.NashiMobile,click(href='blob:https://appassets.androidplatform.net/example'){
  let prevented=false;click({target:{closest:()=>({href,download:'örnek.png'})},preventDefault(){prevented=true;},stopImmediatePropagation(){}});return prevented;
 }};
}
async function until(fn){for(let i=0;i<300;i++){if(fn())return;await new Promise(r=>setTimeout(r,2));}throw Error('Bridge test timed out');}
test('Blob transfer is chunked, acknowledged and byte-identical',async()=>{const bytes=Uint8Array.from({length:120000},(_,i)=>i%256),e=environment(new Blob([bytes],{type:'image/png'}));assert.ok(e.click());await until(()=>e.messages.some(m=>m.type==='finish'));assert.deepEqual(e.messages.map(m=>m.type),['begin','chunk','chunk','chunk','finish']);assert.deepEqual([...Buffer.concat(e.received)],[...bytes]);assert.equal(e.messages[0].name,'örnek.png');});
test('Oversized output never starts a native file transfer',async()=>{const e=environment({size:64*1024*1024+1});e.click();await until(()=>e.messages.some(m=>m.type==='abort'));assert.ok(!e.messages.some(m=>m.type==='begin'));assert.match(e.status.textContent,/64 MB/);});
test('Native rejection aborts instead of finishing a partial file',async()=>{const e=environment(new Blob(['hello']),{failChunk:true});e.click();await until(()=>e.messages.some(m=>m.type==='abort'));assert.ok(!e.messages.some(m=>m.type==='finish'));assert.match(e.status.textContent,/rejection/);});
test('External and other-origin download links are not passed to the native bridge',async()=>{const e=environment(new Blob(['hello']));assert.equal(e.click('https://example.com/file.png'),false);assert.equal(e.click('blob:https://other.example/abc'),false);assert.equal(e.messages.length,0);});
test('Native save completion, cancellation and failure stay visible in the UI',()=>{const e=environment(new Blob(['x']));e.api.saveResult('saved');assert.match(e.status.textContent,/kaydedildi/);e.api.saveResult('cancelled');assert.match(e.status.textContent,/iptal/);e.api.saveResult('failed');assert.match(e.status.textContent,/başarısız/);});
