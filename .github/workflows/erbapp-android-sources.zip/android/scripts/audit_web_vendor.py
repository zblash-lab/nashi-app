"""Offline hash/license audit for the newly bundled web runtime artifacts."""
import argparse,hashlib,json,pathlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
APPROVED={'MIT','MIT AND Zlib','Bitstream-Vera AND Arev'}
def audit(folder=ROOT/'vendor',notices=ROOT/'licenses'):
 folder=pathlib.Path(folder);notices=pathlib.Path(notices);manifest=json.loads((folder/'manifest.json').read_text());components=manifest['components']
 if not components:raise RuntimeError('Web çalışma zamanı lisans listesi boş.')
 for item in components:
  if item['license'] not in APPROVED:raise RuntimeError('İncelenmeyen web runtime lisansı: '+item['name'])
  paths={folder/item['file']:item['sha256'],**{notices/name:digest for name,digest in item['notices'].items()}}
  if not item['notices']:raise RuntimeError('Lisans bildirimi eksik: '+item['name'])
  for path,digest in paths.items():
   if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=digest:raise RuntimeError('Web runtime veya lisans bütünlüğü uyuşmuyor: '+path.name)
 return {'status':'passed','components':components,'font_embedding':'Unmodified full DejaVuSans includes its original copyright/license name table.'}
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--output',type=pathlib.Path,required=True);args=parser.parse_args();result=audit();args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(result,indent=2)+'\n');print(str(len(result['components']))+' web runtime artifact: licenses and hashes verified.')
