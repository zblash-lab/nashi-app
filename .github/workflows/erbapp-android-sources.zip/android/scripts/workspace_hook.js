
const erbappWorkspace=window.ErbappWorkspace.install({
 state:()=>state,
 samples:()=>[],
 model:(name,kind)=>fileModel(name,kind),url:blob=>objectURL(blob),uuid:()=>crypto.randomUUID?.()||[...crypto.getRandomValues(new Uint8Array(16))].map(byte=>byte.toString(16).padStart(2,'0')).join(''),
 notice:text=>{const status=document.getElementById('erbapp-conversion-status');if(status&&!status.closest?.('[hidden]'))status.textContent=text;else toast('Dosyalar',text);},render:()=>renderFiles(),
 display:(group,files,selected)=>{
  closeWheel();closeEditor();state.drag?.ghost?.remove();state.drag=null;
  state.group=group;state.files=files;state.selected=selected;
  formatSelect.replaceChildren();for(const ext of familyExtensions[group])formatSelect.append(el('option',{value:ext},ext.toUpperCase()));
  formatSelect.value=files.find(file=>file.sample)?.ext||familyExtensions[group][0];
  for(const button of $$('[role=tab]',tabs))button.setAttribute('aria-selected',button.dataset.group===group);
 }
});
setGroup=erbappWorkspace.switchGroup;
importFiles=erbappWorkspace.importFiles;
input.accept='image/png,image/jpeg,image/webp,image/gif,image/bmp,application/pdf,application/epub+zip,.epub';
$('#demo-upload').textContent='+ Dosya ekle';
$('#demo-reset').onclick=()=>{state.selected=[];setGroup(state.group);};
const erbappOriginalRenderWorkspace=renderFiles;
renderFiles=function(){erbappOriginalRenderWorkspace();erbappWorkspace.remember();};
