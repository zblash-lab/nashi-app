// Preserve the original Nashi wheel, toolbar, editors and category navigation.
const erbappRealTools=window.ErbappRealTools.install({stage,compact:true,pick:()=>input.click(),group:()=>state.group,selection:()=>selection(),result:(name,blob)=>addResult(name,blob),selectAll:()=>{state.selected=state.files.filter(file=>file.user).map(file=>file.id);renderFiles();}});
const erbappClassicRender=renderFiles;
renderFiles=function(){
 for(const [index,file]of state.files.entries())if(!Number.isFinite(file.x)||!Number.isFinite(file.y)||state.files.slice(0,index).some(other=>other.x===file.x&&other.y===file.y)){
  file.x=.19+(index%3)*.235;file.y=index%2?.36:.17;
 }
 erbappClassicRender();stage.classList.toggle('erbapp-many-files',state.files.length>3);erbappRealTools.render();
};
const erbappClassicSelect=selectFile;
selectFile=function(file,multiple){if(!multiple)state.selected=[file.id];erbappClassicSelect(file,multiple);erbappRealTools.render();};
const erbappClassicToast=toast;
toast=function(title,detail,result){if(result?.blob&&erbappRealTools.busy)return;return erbappClassicToast(title,detail,result);};
const erbappClassicAddResult=addResult;
addResult=function(name,blob,details=''){
 if(!blob){toast('Önizleme','Bu işlem henüz gerçek dosya üretmiyor. Kaynak dosyan değiştirilmedi.');return null;}
 if(blob.size>64*1024*1024)throw Error('Tek çıktı en fazla 64 MB olabilir.');
 return erbappClassicAddResult(name,blob,details);
};
convert=async function(ext){
 const files=selection();
 const operation=files.length&&files.every(file=>file.kind==='image')&&['png','jpg','webp','pdf'].includes(ext)?'image:'+ext:
  files.length===1&&files[0].ext==='epub'&&ext==='pdf'?'epub:pdf':null;
 if(operation)return erbappRealTools.execute(operation);
 if(window.ErbappTextConverters.supports(files,ext)){
  try{for(const output of await window.ErbappTextConverters.run(files,ext))addResult(output.name,output.blob);}catch(error){toast('Dönüştürülemedi',error.message);}return;
 }
 return openConversionPreview(ext);
};
const erbappExtraTools=el('button',{id:'erbapp-extra-tools',type:'button'},'Dönüşüm ayarları');
erbappExtraTools.onclick=()=>{closeWheel();erbappRealTools.show();};
$('.desktop-toolbar',root).append(erbappExtraTools);
input.accept='image/png,image/jpeg,image/webp,image/gif,image/bmp,video/*,audio/*,.pdf,.epub,.docx,.pages,.md,.rtf,.rtfd,.textclipping,.txt,.xlsx,.xls,.ods,.csv,.tsv,.ppt,.pptx,.srt,.vtt,.zip,.tar,.gz,.rar';
const erbappClassicFileAction=fileAction;
fileAction=function(id){if(id==='copyPath')return openActionPreview(id,'Android dosya sağlayıcılarında gerçek dosya yolu paylaşılmaz.');return erbappClassicFileAction(id);};
