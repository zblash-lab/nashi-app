"""Build Erbapp's shared web UI for both Pages and offline Android assets."""
import argparse
import hashlib
import html
import json
import os
import pathlib
import re
import shutil
import importlib.util

SOURCE = pathlib.Path(__file__).resolve().parents[1]
_audit_spec=importlib.util.spec_from_file_location('erbapp_vendor_audit',SOURCE/'scripts/audit_web_vendor.py')
_audit_module=importlib.util.module_from_spec(_audit_spec);_audit_spec.loader.exec_module(_audit_module)
audit_web_vendor=_audit_module.audit
SHARED_UI = SOURCE/'shared-ui'
REQUIRED = [
    'tr/index.html', 'assets/playground.js', 'assets/playground.css', 'assets/site.css',
    'assets/wheel-geometry.mjs', 'assets/demo/catalog.json', 'assets/vendor/pdf-lib.min.js',
    'assets/demo/orchard.jpg', 'assets/demo/hills.jpg', 'assets/demo/weekend.mp4',
    'assets/demo/soft-morning.wav', 'assets/demo/wheel-selection.wav', 'assets/nashi.png',
]
MOBILE_INIT_MARKER = "\nsetGroup('image');\n"
FILE_LIST_HOOK = (pathlib.Path(__file__).with_name('workspace_hook.js').read_text()
                  + pathlib.Path(__file__).with_name('editor_dialog_hook.js').read_text()
                  + pathlib.Path(__file__).with_name('epub_hook.js').read_text()
                  + pathlib.Path(__file__).with_name('file_list_hook.js').read_text()
                  + pathlib.Path(__file__).with_name('real_tools_hook.js').read_text())


def patch_playground(source):
    if source.count(MOBILE_INIT_MARKER) != 1:
        raise RuntimeError('Playground başlangıç noktası değişmiş; ortak arayüz adaptörü gözden geçirilmeli.')
    return source.replace(MOBILE_INIT_MARKER, FILE_LIST_HOOK + MOBILE_INIT_MARKER, 1)


def build_metadata():
    properties = dict(line.split('=', 1) for line in (SOURCE/'version.properties').read_text().splitlines()
                      if line.strip() and not line.startswith('#'))
    run = os.environ.get('GITHUB_RUN_NUMBER', '')
    code = int(properties['ciVersionCodeBase']) + int(run) if run.isdigit() else int(properties['localVersionCode'])
    return {'name': 'Erbapp', 'version': properties['versionName'], 'version_code': code,
            'commit': os.environ.get('GITHUB_SHA', 'local')}


def licenses(repo, web, require_audit):
    notices = web/'notices'; notices.mkdir(exist_ok=True)
    for source, name in [
        ('LICENSE', 'Nashi-MIT.txt'), ('Resources/licenses/pdf-lib.txt', 'pdf-lib.txt'),
        ('android/LICENSE', 'Android-wrapper-MIT.txt'), ('android/licenses/Apache-2.0.txt', 'Apache-2.0.txt'),
    ]:
        shutil.copy2(repo/source, notices/name)
    audit = repo/'android/build/reports/license-audit.json'
    if require_audit:
        report = json.loads(audit.read_text())
        if report.get('status') != 'passed':
            raise RuntimeError('Bağımlılık lisans denetimi geçmedi.')
        shutil.copy2(audit, notices/'android-runtime.json')
    vendor_audit=audit_web_vendor()
    (notices/'erbapp-vendor-audit.json').write_text(json.dumps(vendor_audit,indent=2)+'\n')
    for item in vendor_audit['components']:
        for name in item['notices']:
            shutil.copy2(SOURCE/'licenses'/name,notices/name)
    parts = []
    for file in sorted(notices.iterdir()):
        parts.append(f'<details><summary>{html.escape(file.name)}</summary><pre>{html.escape(file.read_text())}</pre></details>')
    page = ('<!doctype html><html lang="tr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
            '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'">'
            '<title>Erbapp · Lisanslar</title><style>body{background:#101e17;color:#e9eee7;font:14px/1.8 system-ui;padding:18px}'
            'pre{white-space:pre-wrap;overflow-wrap:anywhere;font-size:11px}details{margin:20px 0}summary{color:#e7c46d}</style>'
            '<h1>Açık kaynak lisansları</h1>' + ''.join(parts) + '</html>')
    (web/'erbapp/licenses.html').write_text(page)
    return page


def render_site(repo, web, runtime, require_audit):
    repo = pathlib.Path(repo); web = pathlib.Path(web)
    for name in REQUIRED:
        if not (repo/'docs'/name).is_file():
            raise RuntimeError(f'Eksik web varlığı: docs/{name}')
    for name in ['LICENSE', 'Resources/licenses/pdf-lib.txt', 'android/LICENSE', 'android/licenses/Apache-2.0.txt']:
        if not (repo/name).is_file():
            raise RuntimeError(f'Eksik lisans: {name}')
    if require_audit and not (repo/'android/build/reports/license-audit.json').is_file():
        raise RuntimeError('Önce exportRuntimeComponents ve audit_licenses.py çalıştırılmalı.')
    if web.exists(): shutil.rmtree(web)
    shutil.copytree(repo/'docs', web)
    shared = web/'erbapp'; shared.mkdir(exist_ok=True)
    for source in SHARED_UI.iterdir():
        if source.is_file(): shutil.copy2(source, shared/source.name)
    shutil.copy2(SOURCE/'app/src/main/res/drawable-nodpi/erbapp_logo.jpg', shared/'erbapp-logo.jpg')
    shutil.copytree(SOURCE/'vendor', shared/'vendor')
    metadata = build_metadata()
    revision = f'{metadata["version_code"]}-{metadata["commit"][:12]}'
    (shared/'build-info.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2)+'\n')
    playground = web/'assets/playground.js'
    playground.write_text(patch_playground(playground.read_text()))
    page = web/'tr/index.html'; text = page.read_text()
    if '<head>' not in text or '</head>' not in text or '<body>' not in text:
        raise RuntimeError('Türkçe sayfanın head/body başlangıç noktası değişmiş.')
    text = text.replace('<html', f'<html data-erbapp-runtime="{runtime}"', 1)
    if '<title>' in text:
        text = re.sub(r'<title>.*?</title>', '<title>Erbapp · Yerel dosya araçları</title>', text, count=1, flags=re.S)
    else:
        text = text.replace('<head>', '<head><title>Erbapp · Yerel dosya araçları</title>', 1)
    text = re.sub(r'<link\b[^>]*\brel=["\'](?:shortcut )?icon["\'][^>]*>', '', text, flags=re.I)
    # Invalidate modified scripts/styles on Pages and preserve the repo-relative base path.
    text = re.sub(r'((?:src|href)=["\'][^"\']*/assets/[^"\'?]+\.(?:js|css|mjs))(?:\?[^"\']*)?(["\'])',
                  lambda m: m[1]+'?v='+revision+m[2], text)
    scripts = ''.join(f'<script src="../erbapp/{name}?v={revision}" defer></script>'
                      for name in ('vendor/pako-inflate-1.0.11.min.js', 'truetype.js', 'epub-engine.js', 'epub-ui.js', 'converters.js', 'real-tools.js', 'overlay.js', 'workspace.js', 'editor-dialog.js', 'file-list.js'))
    text = text.replace('<head>', '<head>'+scripts, 1)
    additions = (f'<link rel="stylesheet" href="../erbapp/erbapp.css?v={revision}">'
                 f'<link rel="icon" type="image/jpeg" href="../erbapp/erbapp-logo.jpg?v={revision}">'
                 f'<link rel="apple-touch-icon" href="../erbapp/erbapp-logo.jpg?v={revision}">')
    if runtime == 'android':
        additions += '<script src="../../mobile/mobile.js" defer></script>'
    text = text.replace('</head>', additions+'</head>', 1)
    header = (f'<div class="erbapp-web-header" role="banner"><img src="../erbapp/erbapp-logo.jpg?v={revision}" alt="">'
              f'<strong>Erbapp</strong><small>{html.escape(metadata["version"])}</small>'
              '<a href="../erbapp/licenses.html">Lisanslar</a></div>')
    text = text.replace('<body>', '<body>'+header, 1)
    page.write_text(text)
    (web/'index.html').write_text('<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta http-equiv="refresh" content="0;url=tr/#playground"><title>Erbapp</title></head><body><a href="tr/#playground">Erbapp uygulamasını aç</a></body></html>')
    license_page = licenses(repo, web, require_audit)
    common = ['assets/playground.js', 'assets/playground.css', 'assets/site.css', 'assets/wheel-geometry.mjs', 'assets/demo/catalog.json']
    common += ['erbapp/'+p.relative_to(shared).as_posix() for p in shared.rglob('*') if p.is_file() and p.name not in {'licenses.html', 'shared-assets-sha256.json'}]
    manifest = {name: hashlib.sha256((web/name).read_bytes()).hexdigest() for name in sorted(common)}
    (shared/'shared-assets-sha256.json').write_text(json.dumps(manifest, indent=2)+'\n')
    return license_page


def prepare(repo, output, require_audit=True):
    output = pathlib.Path(output)
    if output.exists(): shutil.rmtree(output)
    license_page = render_site(repo, output/'web', 'android', require_audit)
    mobile = output/'mobile'; mobile.mkdir()
    (mobile/'licenses.html').write_text(license_page)
    hashes = {p.relative_to(output/'web').as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
              for p in (output/'web').rglob('*') if p.is_file()}
    (output/'web-assets-sha256.json').write_text(json.dumps(hashes, indent=2)+'\n')
    print(f'{len(hashes)} gerçek web varlığı ve lisans paketlendi; internetten dosya alınmadı.')


def prepare_site(repo, output):
    render_site(repo, output, 'web', False)
    print('Ortak Erbapp web sürümü hazırlandı; Android köprüsü ve özel imza verisi eklenmedi.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', required=True); parser.add_argument('--output', required=True)
    parser.add_argument('--runtime', choices=['android', 'web'], default='android')
    args = parser.parse_args()
    if args.runtime == 'web': prepare_site(args.repo, args.output)
    else: prepare(args.repo, args.output)
