"""Poll via DevTools evaluation without Playwright's in-page eval loop.

wait_for_function re-evaluates its predicate inside the page, which strict CSP
can block. Each evaluate call below uses the debugger protocol directly; the
application's Content Security Policy remains enabled and unchanged.
"""
import time


def wait_for_page_value(page, expression, *, timeout=60_000, description='page condition'):
    deadline = time.monotonic() + timeout / 1000
    while True:
        value = page.evaluate(expression)
        if value:
            return value
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError(f'Timed out after {timeout} ms waiting for {description}')
        # Yield through Playwright so bridge acknowledgements and events run.
        page.wait_for_timeout(min(50, remaining * 1000))
