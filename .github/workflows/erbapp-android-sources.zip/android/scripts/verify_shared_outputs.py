"""Require published web and embedded Android UI to share identical sources."""
import argparse
import hashlib
import json
import pathlib


def verify(android, web):
    android=pathlib.Path(android);web=pathlib.Path(web)
    name='erbapp/shared-assets-sha256.json'
    a=json.loads((android/name).read_text());b=json.loads((web/name).read_text())
    if a != b or not a:
        raise RuntimeError('Web ve Android ortak arayüz sürümleri eşleşmiyor.')
    for file, digest in a.items():
        for root in (android,web):
            if hashlib.sha256((root/file).read_bytes()).hexdigest()!=digest:
                raise RuntimeError(f'Ortak arayüz dosyası değişmiş: {file}')
    print(f'{len(a)} ortak dosya web ve Android için byte/SHA-256 eşitliğiyle doğrulandı.')


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--android',required=True);parser.add_argument('--web',required=True)
    args=parser.parse_args();verify(args.android,args.web)
