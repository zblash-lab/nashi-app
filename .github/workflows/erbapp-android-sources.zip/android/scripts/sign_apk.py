"""Sign a tested APK with the persistent private key from GitHub Secrets.

Private material exists only in a protected temporary directory, never reports.
The certificate is pinned to the public certificate shipped with this project.
"""
import argparse
import base64
import hashlib
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[2]


def record_status(status, message, certificate=''):
    report = ROOT/'android/build/reports/signing-status.json'
    report.parent.mkdir(parents=True, exist_ok=True)
    report.write_text(json.dumps({'status': status, 'message': message,
                                 'certificate_sha256': certificate}, ensure_ascii=False, indent=2)+'\n')


def load_config(raw):
    if not raw:
        raise RuntimeError('GitHub Actions secret ERBAPP_SIGNING eksik. Önce repository secret ekleyin.')
    try:
        config = json.loads(raw)
        fields = ('keystore_base64', 'store_password', 'key_password', 'alias')
        if not isinstance(config, dict) or not all(isinstance(config.get(k), str) and config[k] for k in fields):
            raise ValueError()
        if any(c in config['store_password'] + config['key_password'] for c in '\r\n\x00'):
            raise ValueError()
        if not re.fullmatch(r'[A-Za-z0-9_][A-Za-z0-9_.-]{0,63}', config['alias']):
            raise ValueError()
        data = base64.b64decode(config['keystore_base64'], validate=True)
        if not 100 <= len(data) <= 32000:
            raise ValueError()
        return config, data
    except (ValueError, TypeError, KeyError):
        raise RuntimeError('ERBAPP_SIGNING biçimi geçersiz. Özel secret dosyasının tamamını yapıştırın.') from None


def signer_digest(output):
    digests = re.findall(r'^Signer #\d+ certificate SHA-256 digest:\s*([0-9a-fA-F]{64})\s*$', output, re.M)
    if len(digests) != 1:
        raise RuntimeError('APK için tek bir doğrulanmış imza sertifikası bekleniyordu.')
    return digests[0].lower()


def certificate_matches(der, expected):
    if not re.fullmatch(r'[0-9a-f]{64}', expected) or hashlib.sha256(der).hexdigest() != expected:
        raise RuntimeError('İmza anahtarı beklenen Erbapp sertifikasıyla eşleşmiyor; farklı anahtar kullanılamaz.')


def check_key(config, data, temporary, expected):
    keystore = temporary/'erbapp.p12'
    keystore.write_bytes(data)
    keystore.chmod(0o600)
    env = dict(os.environ, ERBAPP_STORE_PASSWORD=config['store_password'], ERBAPP_KEY_PASSWORD=config['key_password'])
    env.pop('ERBAPP_SIGNING', None)
    result = subprocess.run([
        'keytool', '-exportcert', '-alias', config['alias'], '-keystore', str(keystore),
        '-storetype', 'PKCS12', '-storepass:env', 'ERBAPP_STORE_PASSWORD',
    ], env=env, capture_output=True, check=True)
    certificate_matches(result.stdout, expected)
    return keystore, env


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--check', action='store_true')
    parser.add_argument('--input', type=pathlib.Path)
    parser.add_argument('--output', type=pathlib.Path)
    parser.add_argument('--apksigner')
    args = parser.parse_args()
    try:
        config, data = load_config(os.environ.get('ERBAPP_SIGNING', ''))
        if os.environ.get('GITHUB_ACTIONS') == 'true':
            for value in (config['store_password'], config['key_password'], config['keystore_base64']):
                print('::add-mask::' + value, flush=True)
        expected = (ROOT/'android/signing/certificate.sha256').read_text().strip()
        # This certificate is public; only its fingerprint is trusted for updates.
        certificate_matches((ROOT/'android/signing/certificate.der').read_bytes(), expected)
        with tempfile.TemporaryDirectory(prefix='erbapp-signing-', dir=os.environ.get('RUNNER_TEMP')) as folder:
            temporary = pathlib.Path(folder)
            temporary.chmod(0o700)
            keystore, env = check_key(config, data, temporary, expected)
            if args.check:
                record_status('configured', 'Kalıcı imza ayarı doğrulandı.', expected)
                print('Kalıcı Erbapp imza ayarı ve sertifika doğrulandı.')
                return 0
            if not args.input or not args.output or not args.apksigner:
                raise RuntimeError('APK girdisi, çıktısı ve apksigner yolu gerekli.')
            if not args.input.is_file():
                raise RuntimeError('Testlerden geçen APK girdisi bulunamadı.')
            signed = temporary/'Erbapp.apk'
            subprocess.run([
                args.apksigner, 'sign', '--ks', str(keystore), '--ks-type', 'PKCS12',
                '--ks-key-alias', config['alias'], '--ks-pass', 'env:ERBAPP_STORE_PASSWORD',
                '--key-pass', 'env:ERBAPP_KEY_PASSWORD', '--out', str(signed), str(args.input),
            ], env=env, capture_output=True, check=True)
            verified = subprocess.run([
                args.apksigner, 'verify', '--verbose', '--print-certs', str(signed),
            ], env=env, capture_output=True, text=True, check=True)
            if signer_digest(verified.stdout) != expected:
                raise RuntimeError('Üretilen APK beklenen kalıcı imzayla eşleşmiyor.')
            args.output.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(signed, args.output)
            digest = hashlib.sha256(args.output.read_bytes()).hexdigest()
            args.output.with_name('SHA256SUMS.txt').write_text(f'{digest}  {args.output.name}\n')
            args.output.with_name('signing-info.json').write_text(json.dumps({
                'app': 'Erbapp', 'certificate_sha256': expected, 'apk_sha256': digest,
                'verification': 'apksigner verify --verbose --print-certs; pinned signer matched',
            }, indent=2)+'\n')
            record_status('signed', 'APK kalıcı imzayla doğrulandı.', expected)
            print('Erbapp APK kalıcı anahtarla imzalandı; imza ve SHA-256 doğrulandı.')
            print('Açık sertifika SHA-256: ' + expected)
        return 0
    except RuntimeError as error:
        record_status('failed', str(error))
        print('ERROR: ' + str(error), file=sys.stderr)
    except (OSError, ValueError, subprocess.CalledProcessError):
        # Never print subprocess environments, config JSON, passwords, or key bytes.
        message = 'İmza işlemi başarısız. Secret, anahtar parolası ve Android apksigner kurulumunu kontrol edin.'
        record_status('failed', message)
        print('ERROR: ' + message, file=sys.stderr)
    return 1


if __name__ == '__main__':
    sys.exit(main())
