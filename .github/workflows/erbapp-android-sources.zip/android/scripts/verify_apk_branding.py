"""Verify the compiled manifest; badging may report an alias's target activity."""
import argparse
import hashlib
import json
import os
import pathlib
import re
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ANDROID = '{http://schemas.android.com/apk/res/android}'
PACKAGE = 'lab.zblash.nashi'
LAUNCHER = PACKAGE + '.ErbappLauncher'
TARGET = PACKAGE + '.MainActivity'
LOGO_SHA256 = 'fa08b31e8ea979b068f64e5986845f2b29fbadf52e288954fae624189188bb1e'


def qualified(name, package):
    if name.startswith('.'): return package + name
    return package + '.' + name if '.' not in name else name


def resource_matches(value, resource, resources):
    if value in ('@' + resource, '@' + PACKAGE + ':' + resource): return True
    reference = re.fullmatch(r'@(?:ref/)?(?:0x)?([0-9a-fA-F]{8})', value or '')
    if not reference: return False
    resource_id = int(reference[1], 16)
    for match in re.finditer(r'\bresource\s+(0x[0-9a-fA-F]+)\s+(\S+)', resources):
        name = match[2].split(':')[-1]
        if int(match[1], 16) == resource_id and name == resource: return True
    return False


def check(badging, manifest, resources=''):
    if "application-label:'Erbapp'" not in badging:
        raise RuntimeError('APK görünen uygulama adı Erbapp değil.')
    root = ET.fromstring(manifest)
    if root.get('package') != PACKAGE:
        raise RuntimeError('APK paket kimliği değişmiş; mevcut kuruluma güncellenemez.')
    app = root.find('application')
    if app is None: raise RuntimeError('APK application bildirimi bulunamadı.')
    if not resource_matches(app.get(ANDROID+'icon'), 'mipmap/ic_erbapp', resources):
        raise RuntimeError('Uygulama Erbapp simge kaynağını kullanmıyor.')
    launchers = []
    for node in list(app):
        if node.tag not in ('activity', 'activity-alias'): continue
        for intent in node.findall('intent-filter'):
            actions = {value.get(ANDROID+'name') for value in intent.findall('action')}
            categories = {value.get(ANDROID+'name') for value in intent.findall('category')}
            if 'android.intent.action.MAIN' in actions and 'android.intent.category.LAUNCHER' in categories:
                launchers.append(node)
    if len(launchers) != 1:
        raise RuntimeError('APK içinde tam bir Erbapp başlatıcısı bulunmalı.')
    alias = launchers[0]
    if alias.tag != 'activity-alias' or qualified(alias.get(ANDROID+'name', ''), PACKAGE) != LAUNCHER:
        raise RuntimeError('Erbapp başlatıcı alias bildirimi derlenmiş manifestte bulunamadı.')
    if qualified(alias.get(ANDROID+'targetActivity', ''), PACKAGE) != TARGET:
        raise RuntimeError('Erbapp başlatıcısının hedef etkinliği yanlış.')
    if alias.get(ANDROID+'enabled', 'true') != 'true' or alias.get(ANDROID+'exported') != 'true':
        raise RuntimeError('Erbapp başlatıcısı etkin ve dışa açık olmalı.')
    icon = alias.get(ANDROID+'icon', app.get(ANDROID+'icon'))
    if not resource_matches(icon, 'mipmap/ic_erbapp', resources):
        raise RuntimeError('Başlatıcı Erbapp simge kaynağını kullanmıyor.')
    if not any(node.tag == 'activity' and qualified(node.get(ANDROID+'name', ''), PACKAGE) == TARGET
               for node in app):
        raise RuntimeError('Başlatıcının hedef etkinliği APK içinde yok.')
    return {'status': 'passed', 'label': 'Erbapp', 'package': PACKAGE,
            'launcher': LAUNCHER, 'target': TARGET, 'icon': 'mipmap/ic_erbapp',
            'evidence': 'decoded compiled AndroidManifest.xml; not launchable-activity summary'}


def inspect_logo(apk):
    """Optional evidence only: APK resource paths/bytes are not a visual identity test."""
    result = {'blocking': False, 'source_sha256': LOGO_SHA256}
    try:
        with zipfile.ZipFile(apk) as archive:
            hashes = {name: hashlib.sha256(archive.read(name)).hexdigest()
                      for name in archive.namelist()
                      if name.startswith('res/') and name.endswith('/erbapp_logo.jpg')}
        result['files'] = hashes
        result['status'] = ('source-identical' if all(value == LOGO_SHA256 for value in hashes.values())
                            else 'not-byte-identical') if hashes else 'not-located-by-original-name'
    except Exception as error:
        result.update(status='unavailable', message=str(error))
    return result


def find_apkanalyzer():
    sdkmanager = shutil.which('sdkmanager')
    options = [shutil.which('apkanalyzer')]
    if sdkmanager: options.append(str(pathlib.Path(sdkmanager).resolve().with_name('apkanalyzer')))
    sdk = os.environ.get('ANDROID_HOME') or os.environ.get('ANDROID_SDK_ROOT')
    if sdk: options.extend(str(path) for path in sorted(pathlib.Path(sdk).glob('cmdline-tools/*/bin/apkanalyzer')))
    for option in options:
        if option and pathlib.Path(option).is_file(): return option
    raise RuntimeError('Android command-line tools içindeki apkanalyzer bulunamadı.')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--aapt2', required=True); parser.add_argument('--apkanalyzer')
    parser.add_argument('--apk', required=True); parser.add_argument('--output', type=pathlib.Path, required=True)
    args = parser.parse_args(); args.output.parent.mkdir(parents=True, exist_ok=True)
    report = {'status': 'failed'}
    try:
        analyzer = args.apkanalyzer or find_apkanalyzer()
        def dump(command, suffix):
            result = subprocess.run(command, capture_output=True, text=True, check=False)
            args.output.with_name('apk-' + suffix).write_text(result.stdout + result.stderr)
            if result.returncode: raise RuntimeError('APK çözümleme aracı başarısız: ' + pathlib.Path(command[0]).name)
            return result.stdout
        badging = dump([args.aapt2, 'dump', 'badging', args.apk], 'badging.txt')
        manifest = dump([analyzer, 'manifest', 'print', args.apk], 'manifest.xml')
        resources = dump([args.aapt2, 'dump', 'resources', args.apk], 'resources.txt')
        report = check(badging, manifest, resources)
        report['logo'] = inspect_logo(args.apk)
        print('Derlenmiş APK manifestinde Erbapp başlatıcısı ve simge bağlantısı doğrulandı.')
        print('Logo byte karşılaştırması (bilgi amaçlı, yayını engellemez): ' + report['logo']['status'])
    except Exception as error:
        report = {'status': 'failed', 'message': str(error)}
        print('APK kimlik denetimi başarısız: ' + str(error))
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__': raise SystemExit(main())
