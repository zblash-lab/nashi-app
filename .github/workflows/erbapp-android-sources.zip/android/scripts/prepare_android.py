"""Package only local Android UI and pinned engines; never read the web repo."""
import argparse
import hashlib
import html
import importlib.util
import json
import os
import pathlib
import shutil

ROOT = pathlib.Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('android_vendor_audit', ROOT / 'scripts/audit_web_vendor.py')
vendor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(vendor)
MODULES = ('truetype.js', 'epub-engine.js', 'converters.js', 'workspace.js',
           'overlay.js', 'file-list.js', 'real-tools.js')


def prepare(android, output, require_audit=True):
    android, output = pathlib.Path(android), pathlib.Path(output)
    audit = vendor.audit(android / 'vendor', android / 'licenses')
    runtime = android / 'build/reports/license-audit.json'
    if require_audit:
        if not runtime.is_file() or json.loads(runtime.read_text()).get('status') != 'passed':
            raise RuntimeError('Android çalışma zamanı lisans denetimi tamamlanmadan APK paketlenemez.')
    if output == android or output in android.parents:
        raise RuntimeError('Paketleme hedefi kaynak dizini olamaz.')
    if output.exists():
        shutil.rmtree(output)
    web = output / 'web'
    ui = web / 'erbapp'
    ui.mkdir(parents=True)
    (web / 'tr').mkdir()
    (output / 'mobile').mkdir()
    notices = web / 'notices'
    notices.mkdir()
    for path in (android / 'licenses').glob('*.txt'):
        shutil.copy2(path, notices / path.name)
    shutil.copy2(android / 'LICENSE', notices / 'Android-MIT.txt')
    shutil.copytree(android / 'vendor', ui / 'vendor')
    for name in MODULES + ('erbapp.css',):
        shutil.copy2(android / 'shared-ui' / name, ui / name)
    for name in ['app.js', 'android.css']:
        shutil.copy2(android / 'app-ui' / name, ui / name)
    shutil.copy2(android / 'app/src/main/res/drawable-nodpi/erbapp_logo.jpg', ui / 'erbapp-logo.jpg')
    properties = dict(line.split('=', 1) for line in (android / 'version.properties').read_text().splitlines() if '=' in line)
    run = os.environ.get('GITHUB_RUN_NUMBER', '')
    code = int(properties['ciVersionCodeBase']) + int(run) if run.isdigit() else int(properties['localVersionCode'])
    metadata = {'version': properties['versionName'], 'version_code': code, 'commit': os.environ.get('GITHUB_SHA', 'local'), 'runtime': 'android-only'}
    key = html.escape(str(code) + '-' + metadata['commit'][:12], quote=True)
    scripts = ['vendor/pdf-lib-1.17.1.min.js', 'vendor/pako-inflate-1.0.11.min.js', *MODULES, 'app.js']
    tags = '\n'.join(f'<script src="../erbapp/{name}?v={key}" defer></script>' for name in scripts)
    tags += '\n<script src="../../mobile/mobile.js" defer></script>'
    page = (android / 'app-ui/index.html').read_text().replace('{{SCRIPTS}}', tags).replace('{{BUILD}}', key).replace('{{VERSION}}', html.escape(metadata['version']))
    (web / 'tr/index.html').write_text(page)
    (ui / 'build.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + '\n')
    (ui / 'vendor-license-audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n')
    if runtime.is_file():
        shutil.copy2(runtime, notices / 'android-runtime-licenses.json')
    links = ''.join(f'<li><a href="../web/notices/{html.escape(path.name, quote=True)}">{html.escape(path.name)}</a></li>' for path in sorted(notices.iterdir()))
    licenses = '<!doctype html><html lang="tr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'"><title>Erbapp lisansları</title><style>body{background:#101e17;color:#e9eee7;font:16px/1.7 system-ui;padding:20px}a{color:#e7c46d}</style><h1>Açık kaynak lisansları</h1><ul>' + links + '</ul></html>'
    (output / 'mobile/licenses.html').write_text(licenses)
    hashes = {path.relative_to(output).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest() for path in output.rglob('*') if path.is_file()}
    (ui / 'asset-manifest.json').write_text(json.dumps(hashes, indent=2) + '\n')
    print(f'Android {metadata["version"]}: {len(hashes)} yerel varlık paketlendi; web/docs kaynağı okunmadı.')
    return metadata


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--android-root', type=pathlib.Path, default=ROOT)
    parser.add_argument('--output', type=pathlib.Path, required=True)
    args = parser.parse_args()
    prepare(args.android_root, args.output)
