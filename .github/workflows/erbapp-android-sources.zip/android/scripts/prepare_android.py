"""Package only local Android UI and pinned engines; never read the web repo."""
import argparse
import hashlib
import html
import importlib.util
import json
import os
import pathlib
import re
import shutil

ROOT = pathlib.Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('android_vendor_audit', ROOT / 'scripts/audit_web_vendor.py')
vendor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(vendor)
MODULES = ('truetype.js', 'epub-engine.js', 'converters.js', 'workspace.js',
           'overlay.js', 'editor-dialog.js', 'epub-ui.js', 'file-list.js', 'real-tools.js', 'text-tools.js')
MEDIA_OLD = "const mediaBlob=await(await fetch(isVideo?asset('demo/weekend.mp4'):asset('demo/soft-morning.wav'))).blob();"
MEDIA_NEW = "const mediaBlob=files[0].blob;if(!mediaBlob)throw Error('Kendi video veya ses dosyanı ekle.');"


def patch_classic(android, source):
    marker = "\nsetGroup('image');\n"
    if source.count(marker) != 1:
        raise RuntimeError('Klasik arayüz başlangıcı değişmiş; adaptör kontrol edilmeli.')
    if source.count(MEDIA_OLD) != 1:
        raise RuntimeError('Medya giriş noktası değişmiş; kullanıcı dosyası bağlantısı kontrol edilmeli.')
    source=source.replace(MEDIA_OLD,MEDIA_NEW,1)
    source=source.replace('Örnek videodan gerçek PNG oluşturur.','Seçilen videodan gerçek PNG oluşturur.')
    hooks = ''.join((android / 'scripts' / name).read_text() for name in
                    ['workspace_hook.js', 'editor_dialog_hook.js', 'file_list_hook.js', 'classic_hook.js'])
    return source.replace(marker, hooks + marker, 1)


def prepare(android, output, require_audit=True):
    android, output = pathlib.Path(android), pathlib.Path(output)
    audit = vendor.audit(android / 'vendor', android / 'licenses')
    classic = android / 'classic-ui'
    snapshot = json.loads((classic / 'manifest.json').read_text())
    for name, digest in snapshot['files'].items():
        if hashlib.sha256((classic / name).read_bytes()).hexdigest() != digest:
            raise RuntimeError('Klasik arayüz kaynak özeti değişmiş: ' + name)
    runtime = android / 'build/reports/license-audit.json'
    if require_audit:
        if not runtime.is_file() or json.loads(runtime.read_text()).get('status') != 'passed':
            raise RuntimeError('Android çalışma zamanı lisans denetimi tamamlanmadan APK paketlenemez.')
    if output == android or output in android.parents:
        raise RuntimeError('Paketleme hedefi kaynak dizini olamaz.')
    if output.exists():
        shutil.rmtree(output)
    web = output / 'web'
    ui = web / 'erbapp'
    ui.mkdir(parents=True)
    (web / 'tr').mkdir()
    (output / 'mobile').mkdir()
    notices = web / 'notices'
    notices.mkdir()
    for path in (android / 'licenses').glob('*.txt'):
        shutil.copy2(path, notices / path.name)
    shutil.copy2(android / 'LICENSE', notices / 'Android-MIT.txt')
    shutil.copytree(android / 'vendor', ui / 'vendor')
    for name in MODULES + ('erbapp.css',):
        shutil.copy2(android / 'shared-ui' / name, ui / name)
    shutil.copytree(classic / 'assets', web / 'assets')
    source = web / 'assets/playground.js'
    source.write_text(patch_classic(android, source.read_text()))
    shutil.copy2(android / 'app/src/main/res/drawable-nodpi/erbapp_logo.jpg', ui / 'erbapp-logo.jpg')
    properties = dict(line.split('=', 1) for line in (android / 'version.properties').read_text().splitlines() if '=' in line)
    run = os.environ.get('GITHUB_RUN_NUMBER', '')
    code = int(properties['ciVersionCodeBase']) + int(run) if run.isdigit() else int(properties['localVersionCode'])
    metadata = {'version': properties['versionName'], 'version_code': code, 'commit': os.environ.get('GITHUB_SHA', 'local'), 'runtime': 'android-only', 'interface':'classic-nashi'}
    key = html.escape(str(code) + '-' + metadata['commit'][:12], quote=True)
    scripts = ['vendor/pdf-lib-1.17.1.min.js', 'vendor/pako-inflate-1.0.11.min.js', *MODULES]
    tags = '\n'.join(f'<script src="../erbapp/{name}?v={key}" defer></script>' for name in scripts)
    tags += '\n<script src="../../mobile/mobile.js" defer></script>'
    page = (classic / 'tr/index.html').read_text()
    page = page.replace('<html', '<html data-erbapp-runtime="android"', 1)
    page = re.sub(r'<title>.*?</title>', '<title>Erbapp · Dosya araçları</title>', page, count=1)
    page = re.sub(r'<script\b[^>]*src="[^"]+"[^>]*></script>', '', page)
    page = re.sub(r'<video\b[\s\S]*?</video>', '', page)
    page = re.sub(r'<img\b[^>]*>', '', page)
    page = page.replace('../assets/nashi.png', '../erbapp/erbapp-logo.jpg')
    page = re.sub(r'((?:src|href)="[^"?]+\.(?:css|js|mjs))(?:\?[^\"]*)?(\")', lambda match:match[1]+'?v='+key+match[2], page)
    page = page.replace('</head>', f'<link rel="stylesheet" href="../erbapp/erbapp.css?v={key}">'+tags+f'<script src="../assets/playground.js?v={key}" defer></script></head>', 1)
    # Mobile integration is defined before the async classic initializer but
    # accesses its UI only on user input; all processing remains local.
    page = page.replace('<body>', '<body><div class="erbapp-web-header"><strong>Erbapp</strong><small>'+html.escape(metadata['version'])+'</small></div>', 1)
    (web / 'tr/index.html').write_text(page)
    (ui / 'build.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + '\n')
    (ui / 'vendor-license-audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n')
    if runtime.is_file():
        shutil.copy2(runtime, notices / 'android-runtime-licenses.json')
    links = ''.join(f'<li><a href="../web/notices/{html.escape(path.name, quote=True)}">{html.escape(path.name)}</a></li>' for path in sorted(notices.iterdir()))
    licenses = '<!doctype html><html lang="tr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'"><title>Erbapp lisansları</title><style>body{background:#101e17;color:#e9eee7;font:16px/1.7 system-ui;padding:20px}a{color:#e7c46d}</style><h1>Açık kaynak lisansları</h1><ul>' + links + '</ul></html>'
    (output / 'mobile/licenses.html').write_text(licenses)
    hashes = {path.relative_to(output).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest() for path in output.rglob('*') if path.is_file()}
    (ui / 'asset-manifest.json').write_text(json.dumps(hashes, indent=2) + '\n')
    print(f'Android {metadata["version"]}: {len(hashes)} yerel varlık paketlendi; web/docs kaynağı okunmadı.')
    return metadata


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--android-root', type=pathlib.Path, default=ROOT)
    parser.add_argument('--output', type=pathlib.Path, required=True)
    args = parser.parse_args()
    prepare(args.android_root, args.output)
