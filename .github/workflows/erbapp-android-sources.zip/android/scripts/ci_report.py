"""Collect build evidence even on failure; never claim success without an APK."""
import json
import os
import pathlib
import re

ROOT = pathlib.Path(__file__).resolve().parents[2]
REPORTS = ROOT/'android/build/reports'
CI = REPORTS/'ci'


def report():
    CI.mkdir(parents=True, exist_ok=True)
    apk = ROOT/'android/app/build/outputs/erbapp/Erbapp.apk'
    signature = apk.with_name('SHA256SUMS.txt')
    audit_file = REPORTS/'license-audit.json'
    lines = ['# Erbapp Android APK derleme raporu', '']
    properties = dict(line.split('=', 1) for line in (ROOT/'android/version.properties').read_text().splitlines() if '=' in line)
    lines += [f'Sürüm: {properties["versionName"]}',
              f'Commit: {os.environ.get("GITHUB_SHA", "local")}',
              f'Çalışma: {os.environ.get("GITHUB_RUN_ID", "local")} / deneme {os.environ.get("GITHUB_RUN_ATTEMPT", "1")}', '']
    source_file = REPORTS/'source-package.json'
    if source_file.is_file():
        source = json.loads(source_file.read_text())
        lines += [f'Kaynak ZIP SHA-256: {source["source_sha256"]}', '']
    # Publication additionally depends on the job's mandatory test/lint steps.
    artifact = os.environ.get('APK_ARTIFACT_URL', '')
    if apk.is_file() and signature.is_file() and artifact:
        lines += [f'APK artifact: {artifact}', '', signature.read_text().strip(), '']
    else:
        lines += ['Doğrulanmış APK artifact oluşturulmadı. Aşağıdaki kayıtları inceleyin.', '']
    signing_file = REPORTS/'signing-status.json'
    if signing_file.is_file():
        signing = json.loads(signing_file.read_text())
        lines += [f'İmzalama: {signing["status"]} — {signing["message"]}', '']
    if audit_file.is_file():
        audit = json.loads(audit_file.read_text())
        lines += [f'Lisans denetimi: {audit.get("status", "unknown")}',
                  f'Doğrulanan bileşenler: {len(audit.get("components", []))}', '']
        for error in audit.get('errors', []):
            lines.append(f'- {error["component"]}: {error["error"]}')
        lines.append('')
    vendor_file = REPORTS/'web-vendor-licenses.json'
    if vendor_file.is_file():
        vendor = json.loads(vendor_file.read_text())
        lines += [f'Web runtime / font lisansları: {vendor["status"]} ({len(vendor["components"])} bileşen)', '']
    browser_file = REPORTS/'browser/browser-results.json'
    if browser_file.is_file():
        browser = json.loads(browser_file.read_text())
        lines += [f'Tarayıcı kabul testleri: {browser["status"]}', '']
        for case in browser.get('cases', []):
            lines.append(f'- {case["case"]}: {case["status"]}')
            for scenario in case.get('scenarios', []):
                lines.append(f'  - {scenario["name"]}: {scenario["status"]}')
        lines += ['', 'Android HTML testi Chrome ve köprü taklidi kullanır; fiziksel Android/SAF testi değildir.', '']
    outputs_file = REPORTS/'browser/converter-output-verification.json'
    if outputs_file.is_file():
        outputs = json.loads(outputs_file.read_text())
        lines += [f'Bağımsız PNG/PDF içerik kontrolü: {outputs["status"]}', '']
    branding_file = REPORTS/'apk-branding.json'
    if branding_file.is_file():
        branding = json.loads(branding_file.read_text())
        lines += [f'APK adı ve başlatıcı kontrolü: {branding["status"]}', '']
        if 'logo' in branding:
            lines += [f'Logo byte raporu (bilgi amaçlı): {branding["logo"]["status"]}', '']
    for log in sorted(CI.glob('*.log')):
        text = re.sub(r'\x1b\[[0-9;]*m', '', log.read_text(errors='replace'))
        # Include the beginning of failure sections as well as the final tail;
        # Gradle stack traces can otherwise hide the actual compiler error.
        rows = text.splitlines()
        selected = set(range(max(0, len(rows)-45), len(rows)))
        for index, row in enumerate(rows):
            if any(key in row for key in ('What went wrong', 'FAILURE:', 'e: file:', 'error:', 'ERROR ', '* Where:', 'Execution failed for task')):
                selected.update(range(max(0, index-2), min(len(rows), index+16)))
        excerpt = '\n'.join(rows[index] for index in sorted(selected))[-22000:]
        lines += [f'## {log.name}', '', '~~~~text', excerpt.replace('~~~~', '----'), '~~~~', '']
    text = '\n'.join(lines)
    (CI/'derleme-ozeti.txt').write_text(text)
    summary = os.environ.get('GITHUB_STEP_SUMMARY')
    if summary:
        with open(summary, 'a') as destination:
            destination.write(text[:600000]+'\n')
    print(text)


if __name__ == '__main__':
    report()
