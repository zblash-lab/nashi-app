"""Packaged Android HTML acceptance, with one isolated context per operation.

The real save link and JS chunk bridge run with native acknowledgements supplied
by a test double. Android SAF and physical WebView remain separate device checks.
"""
import argparse
import base64
import functools
import hashlib
import http.server
import json
import pathlib
import shutil
import tempfile
import threading
import traceback

from playwright.sync_api import sync_playwright, expect
from browser_wait import wait_for_page_value
from acceptance_runner import run_scenarios


class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass


NATIVE_PROXY = '''
window.__nativeExport=null;let current=null;
window.NashiNative={postMessage(raw){
 const message=JSON.parse(raw);let ok=true;
 if(message.type==='begin')current={name:message.name,mime:message.mime,size:message.size,chunks:[]};
 else if(message.type==='chunk'){
  ok=!!current&&message.sequence===current.chunks.length;
  if(ok)current.chunks.push(message.data);
 }
 const completed=message.type==='finish'?current:null;
 if(message.type==='abort')current=null;
 setTimeout(()=>{
  window.NashiNative.onmessage?.({data:JSON.stringify({token:message.token,ok,error:'Invalid transfer sequence'})});
  if(completed)setTimeout(()=>window.__nativeExport=completed,0);
 },0);
}};
'''


def exercise(browser, origin, url, output, label, mobile, native, fixtures,
             expected_version, scenario, result, outputs):
    context = browser.new_context(
        viewport={'width': 412 if mobile else 1280, 'height': 850 if mobile else 900},
        is_mobile=mobile, has_touch=mobile, accept_downloads=True)
    context.route('**/*', lambda route: route.continue_() if route.request.url.startswith(
        (origin + '/', 'blob:' + origin + '/', 'data:')) else route.abort())
    if native:
        context.add_init_script(NATIVE_PROXY)
    page = context.new_page()
    errors = []
    page.on('pageerror', lambda error: errors.append(str(error)))

    def activate(locator):
        locator.tap() if mobile else locator.click()

    def upload(paths):
        with page.expect_file_chooser() as chooser:
            activate(page.locator('#erbapp-pick') if page.locator('#erbapp-pick').is_visible() else page.locator('#demo-upload'))
        chooser.value.set_files([str(path) for path in paths])

    def converted(operation, name):
        result['step'] = 'convert ' + operation
        page.locator('#erbapp-output-format').select_option(operation)
        activate(page.locator('#erbapp-run'))
        link = page.locator('.erbapp-real-results a[download]')
        expect(link).to_have_count(1, timeout=60000)
        expect(link).to_be_visible()
        destination = output / (label + '-' + name)
        if native:
            page.evaluate('window.__nativeExport=null')
            activate(link)
            transferred = wait_for_page_value(page, 'window.__nativeExport',
                description=operation + ' native byte transfer')
            data = b''.join(base64.b64decode(chunk, validate=True) for chunk in transferred['chunks'])
            assert len(data) == transferred['size'], 'Native bridge transfer size mismatch'
            destination.write_bytes(data)
        else:
            with page.expect_download() as download:
                activate(link)
            download.value.save_as(str(destination))
        outputs[name] = destination.name
        return destination

    def manager():
        if page.locator('.erbapp-file-drawer').count() == 0:
            activate(page.locator('#nashi-manage-files'))
        drawer = page.get_by_role('region', name='Dosyaları yönet', exact=True)
        expect(drawer).to_be_visible()
        assert page.evaluate('document.getElementById("playground").inert') is False
        if native:
            expect(drawer.get_by_role('button', name='Örnekleri geri getir', exact=True)).to_have_count(0)
        return drawer

    try:
        result['step'] = 'load ' + expected_version
        page.goto(url, wait_until='networkidle')
        expect(page.locator('#demo-upload')).to_be_visible()
        expect(page.locator('.demo-file')).to_have_count(0)
        assert page.locator('.erbapp-web-header small').text_content() == expected_version
        # Inspect the declaration; DevTools eval does not measure CSP enforcement.
        policy = page.locator('meta[http-equiv="Content-Security-Policy"]').get_attribute('content') or ''
        assert "script-src 'self';" in policy and "'unsafe-eval'" not in policy
        result['version'] = expected_version
        if native:
            expect(page.get_by_role('tab')).to_have_count(10)
            expect(page.get_by_role('button', name='Örnekleri geri getir', exact=True)).to_have_count(0)
            expect(page.locator('.erbapp-real-tools')).to_be_hidden()
        if scenario not in {'classic-tools','library'}:
            if native:
                activate(page.locator('#erbapp-extra-tools'))
            expect(page.locator('#erbapp-run')).to_be_visible()

        if scenario.startswith('image-'):
            upload([fixtures / 'image.png'])
            expect(page.locator('.demo-file')).to_have_count(1)
            extension = {'image-jpeg': 'jpg'}.get(scenario, scenario.split('-')[1])
            converted('image:' + extension, 'image.' + extension)
            if extension == 'png':
                pixel = page.evaluate('''async()=>{
                 const image=await createImageBitmap(await(await fetch(document.querySelector('.erbapp-real-results a').href)).blob());
                 const canvas=document.createElement('canvas');canvas.width=image.width;canvas.height=image.height;
                 const c=canvas.getContext('2d');c.drawImage(image,0,0);
                 return {width:image.width,height:image.height,pixel:[...c.getImageData(0,0,1,1).data]};
                }''')
                assert pixel == {'width': 32, 'height': 24, 'pixel': [20, 120, 210, 255]}, pixel
        elif scenario == 'epub-pdf':
            upload([fixtures / 'turkce-kitap.epub'])
            expect(page.get_by_role('tab', name='EPUB', exact=True)).to_have_attribute('aria-selected', 'true')
            converted('epub:pdf', 'book.pdf')
        elif scenario.startswith('pdf-'):
            paths = [fixtures / 'source-a.pdf']
            if scenario == 'pdf-merge':
                paths.append(fixtures / 'source-b.pdf')
            upload(paths)
            expect(page.locator('.demo-file')).to_have_count(len(paths))
            expect(page.get_by_role('tab', name='PDF', exact=True)).to_have_attribute('aria-selected', 'true')
            action = scenario.split('-')[1]
            if action == 'extract':
                page.locator('#erbapp-output-format').select_option('pdf:extract')
                page.locator('#erbapp-page-range').fill('1,3')
            converted('pdf:' + action, action + '.pdf')
        elif scenario == 'file-management':
            result['step'] = 'file persistence and removal'
            upload([fixtures / 'image.png'])
            expect(page.locator('.demo-file')).to_have_count(1)
            activate(page.get_by_role('tab', name='PDF', exact=True))
            expect(page.locator('.demo-file')).to_have_count(0)
            activate(page.get_by_role('tab', name='Görseller', exact=True))
            expect(page.locator('.demo-file')).to_have_count(1)
            page.reload(wait_until='networkidle')
            expect(page.locator('.demo-file')).to_have_count(1)
            drawer = manager()
            activate(drawer.get_by_role('button', name='image.png dosyasını listeden kaldır', exact=True))
            expect(page.locator('.demo-file')).to_have_count(0)
            expect(drawer.get_by_role('status')).to_contain_text('listeden kaldırıldı')
            wait_for_page_value(page, '''()=>new Promise((resolve,reject)=>{
             const open=indexedDB.open('erbapp-files',1);open.onerror=()=>reject(open.error);
             open.onsuccess=()=>{const db=open.result;const get=db.transaction('files').objectStore('files').getAll();
              get.onsuccess=()=>{const absent=!get.result.some(file=>file.name==='image.png');db.close();resolve(absent);};
              get.onerror=()=>{db.close();reject(get.error);};};
            })''', description='committed IndexedDB deletion')
            activate(drawer.get_by_role('button', name='Kapat', exact=True))
            page.reload(wait_until='networkidle')
            expect(page.locator('.demo-file')).to_have_count(0)
            upload([fixtures / 'turkce-kitap.epub', fixtures / 'source-a.pdf', fixtures / 'source-b.pdf'])
            expect(page.get_by_role('tab', name='EPUB', exact=True)).to_have_attribute('aria-selected', 'true')
            expect(page.locator('.demo-file')).to_have_count(1)
            drawer = manager()
            activate(drawer.get_by_role('button', name='turkce-kitap.epub dosyasını listeden kaldır', exact=True))
            expect(page.locator('.demo-file')).to_have_count(0)
            activate(drawer.get_by_role('button', name='Kapat', exact=True))
            activate(page.get_by_role('tab', name='PDF', exact=True))
            expect(page.locator('.demo-file')).to_have_count(2)
            drawer = manager()
            activate(drawer.get_by_role('button', name='Bu listeyi temizle', exact=True))
            confirmation = drawer.get_by_role('group', name='Liste temizlensin mi?', exact=True)
            expect(confirmation).to_be_visible()
            activate(confirmation.get_by_role('button', name='Vazgeç', exact=True))
            expect(page.locator('.demo-file')).to_have_count(2)
            activate(drawer.get_by_role('button', name='Bu listeyi temizle', exact=True))
            activate(drawer.get_by_role('group', name='Liste temizlensin mi?', exact=True).get_by_role(
                'button', name='Listeden kaldır', exact=True))
            expect(page.locator('.demo-file')).to_have_count(0)
            page.screenshot(path=str(output / (label + '-manager-cleared.png')), full_page=True)
        elif scenario == 'classic-tools':
            result['step']='classic tool wheel and editor'
            upload([fixtures/'image.png'])
            activate(page.locator('.demo-file'))
            activate(page.locator('[data-mode="tools"]'))
            wheel=page.get_by_role('menu',name='Nashi çarkı',exact=True)
            expect(wheel).to_be_visible()
            activate(wheel.get_by_role('menuitem').first)
            editor=page.get_by_role('dialog')
            expect(editor).to_be_visible()
            expect(editor.locator('.export-button')).to_be_enabled()
            expect(editor.locator('canvas')).to_be_visible()
            activate(editor.get_by_role('button',name='Kapat',exact=True))
            expect(page.get_by_role('dialog')).to_have_count(0)
            assert page.evaluate('document.getElementById("playground").inert') is False
            expect(page.locator('.demo-file')).to_have_count(1)
        elif scenario == 'library':
            result['step'] = 'library open and close'
            activate(page.locator('#demo-library'))
            library = page.get_by_role('dialog', name='Kitaplık', exact=True)
            expect(library).to_be_visible()
            assert page.locator('dialog[open]').count() == 0
            if native:
                assert page.evaluate('window.NashiMobile.back()') is True
            else:
                activate(library.get_by_role('button', name='Kapat', exact=True))
            expect(page.get_by_role('dialog')).to_have_count(0)
            assert page.evaluate('document.getElementById("playground").inert') is False
        else:
            raise RuntimeError('Unknown mandatory scenario: ' + scenario)
        assert not errors, 'Uncaught JavaScript errors: ' + repr(errors)
    except Exception:
        result['page_errors'] = errors
        try:
            page.screenshot(path=str(output / (label + '-' + scenario + '-failure.png')), full_page=True)
            (output / (label + '-' + scenario + '-failure.html')).write_text(page.content())
        except Exception:
            result['capture_error'] = traceback.format_exc()
        raise
    finally:
        context.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--site', type=pathlib.Path)
    parser.add_argument('--android-only', action='store_true')
    parser.add_argument('--android', type=pathlib.Path, required=True)
    parser.add_argument('--repo', type=pathlib.Path, required=True)
    parser.add_argument('--output', type=pathlib.Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    properties = dict(line.split('=', 1) for line in (args.repo / 'android/version.properties').read_text().splitlines() if '=' in line)
    result = {'status': 'failed', 'version': properties['versionName'], 'cases': []}

    def checkpoint():
        (args.output / 'browser-results.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')

    try:
        executable = shutil.which('google-chrome') or shutil.which('google-chrome-stable') or shutil.which('chromium')
        if not executable:
            raise RuntimeError('CI Chrome kurulumu bulunamadı.')
        fixtures = args.repo / 'android/tests/fixtures/epub'
        originals = {path: hashlib.sha256(path.read_bytes()).hexdigest() for path in fixtures.iterdir() if path.is_file()}
        with tempfile.TemporaryDirectory(prefix='erbapp-browser-') as temporary:
            mounted = pathlib.Path(temporary)
            if not args.android_only:
                if args.site is None:
                    raise RuntimeError('Web kabul testi için --site gerekli.')
                shutil.copytree(args.site, mounted / 'nashi-app')
            shutil.copytree(args.repo / 'android/app/src/main/assets', mounted / 'assets')
            shutil.copytree(args.android, mounted / 'assets', dirs_exist_ok=True)
            server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), functools.partial(QuietHandler, directory=str(mounted)))
            threading.Thread(target=server.serve_forever, daemon=True).start()
            try:
                origin = f'http://127.0.0.1:{server.server_port}'
                with sync_playwright() as playwright:
                    browser = playwright.chromium.launch(executable_path=executable, headless=True)
                    try:
                        expect.set_options(timeout=20000)
                        cases = [('android-html', True, True, origin + '/assets/web/tr/index.html#playground')]
                        if not args.android_only:
                            cases = [('desktop-web', False, False, origin + '/nashi-app/tr/#playground'),
                                     ('mobile-web', True, False, origin + '/nashi-app/tr/#playground')] + cases
                        for label, mobile, native, url in cases:
                            case = {'case': label, 'status': 'failed', 'outputs': {}, 'native_scope': 'HTML and real JS chunk bridge with proxy acknowledgements; physical SAF is not tested'}
                            result['cases'].append(case)

                            def check(name, item):
                                exercise(browser, origin, url, args.output, label, mobile, native, fixtures,
                                         properties['versionName'], name, item, case['outputs'])

                            run_scenarios(check, case, checkpoint)
                            for item in case['scenarios']:
                                print(item['status'].upper() + ' ' + label + '/' + item['name'], flush=True)
                                if item.get('error'):
                                    print(item['error'], flush=True)
                    finally:
                        browser.close()
            finally:
                server.shutdown()
                server.server_close()
        for path, digest in originals.items():
            assert hashlib.sha256(path.read_bytes()).hexdigest() == digest, 'Source file changed: ' + path.name
        if result['cases'] and all(case['status'] == 'passed' for case in result['cases']):
            result['status'] = 'passed'
    except Exception:
        result['error'] = traceback.format_exc()
        print(result['error'], flush=True)
    checkpoint()
    return 0 if result['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
