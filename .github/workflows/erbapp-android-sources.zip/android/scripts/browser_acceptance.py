"""Real browser conversions and file persistence; Android HTML uses a bridge double."""
import argparse,base64,functools,hashlib,http.server,json,pathlib,shutil,tempfile,threading,traceback
from playwright.sync_api import sync_playwright,expect

class QuietHandler(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass

def exercise(browser,origin,url,output,label,mobile,native,fixtures):
 context=browser.new_context(viewport={'width':412 if mobile else 1280,'height':850 if mobile else 900},is_mobile=mobile,has_touch=mobile,accept_downloads=True)
 context.route('**/*',lambda route:route.continue_() if route.request.url.startswith((origin+'/', 'blob:'+origin+'/', 'data:')) else route.abort())
 if native:context.add_init_script('''
 window.__nativeExport=null;let current=null;
 window.NashiNative={postMessage(raw){const message=JSON.parse(raw);let ok=true;
  if(message.type==='begin')current={name:message.name,mime:message.mime,size:message.size,chunks:[]};
  else if(message.type==='chunk'){ok=!!current&&message.sequence===current.chunks.length;if(ok)current.chunks.push(message.data);}
  const completed=message.type==='finish'?current:null;
  if(message.type==='abort')current=null;
  setTimeout(()=>{window.NashiNative.onmessage?.({data:JSON.stringify({token:message.token,ok,error:'Invalid transfer sequence'})});if(completed)setTimeout(()=>window.__nativeExport=completed,0);},0);
 }};
 ''')
 page=context.new_page();errors=[];page.on('pageerror',lambda error:errors.append(str(error)));result={'case':label,'status':'failed','outputs':{}}
 def activate(locator):locator.tap() if mobile else locator.click()
 def upload(paths):
  with page.expect_file_chooser() as chooser:activate(page.locator('#erbapp-pick'))
  chooser.value.set_files([str(path) for path in paths])
 def converted(operation,name):
  page.locator('#erbapp-output-format').select_option(operation);activate(page.locator('#erbapp-run'))
  link=page.locator('.erbapp-real-results a[download]');expect(link).to_have_count(1,timeout=60000);expect(link).to_be_visible()
  destination=output/(label+'-'+name)
  if native:
   # Click the actual save link and validate bytes across the real JS chunk bridge.
   # The proxy acknowledges messages; Android SAF remains a separate device check.
   page.evaluate('window.__nativeExport=null');activate(link)
   page.wait_for_function('window.__nativeExport!==null',timeout=60000)
   transferred=page.evaluate('window.__nativeExport');data=b''.join(base64.b64decode(chunk) for chunk in transferred['chunks'])
   assert len(data)==transferred['size'],'Native bridge transfer size mismatch';destination.write_bytes(data)
  else:
   with page.expect_download() as download:activate(link)
   download.value.save_as(str(destination))
  result['outputs'][name]=destination.name;return destination
 def manager():
  if page.locator('.erbapp-file-drawer').count()==0:activate(page.locator('#nashi-manage-files'))
  drawer=page.get_by_role('region',name='Dosyaları yönet',exact=True);expect(drawer).to_be_visible()
  assert page.evaluate('document.getElementById("playground").inert') is False,'Inline manager must not blur or disable the page'
  return drawer
 try:
  page.goto(url,wait_until='networkidle');expect(page.locator('#erbapp-run')).to_be_visible();expect(page.locator('.demo-file')).to_have_count(0)
  original={path:hashlib.sha256(path.read_bytes()).hexdigest() for path in fixtures.iterdir() if path.is_file()}
  upload([fixtures/'image.png']);expect(page.locator('.demo-file')).to_have_count(1);expect(page.locator('.erbapp-tool-selection')).to_contain_text('image.png')
  converted('image:png','image.png')
  pixel=page.evaluate('''async()=>{const image=await createImageBitmap(await(await fetch(document.querySelector('.erbapp-real-results a').href)).blob());const canvas=document.createElement('canvas');canvas.width=image.width;canvas.height=image.height;const c=canvas.getContext('2d');c.drawImage(image,0,0);return {width:image.width,height:image.height,pixel:[...c.getImageData(0,0,1,1).data]};}''')
  assert pixel=={'width':32,'height':24,'pixel':[20,120,210,255]},pixel
  converted('image:jpg','image.jpg');converted('image:pdf','image.pdf')
  activate(page.get_by_role('tab',name='PDF',exact=True));expect(page.locator('.demo-file')).to_have_count(0)
  activate(page.get_by_role('tab',name='Görseller',exact=True));expect(page.locator('.demo-file')).to_have_count(1)
  page.reload(wait_until='networkidle');expect(page.locator('.demo-file')).to_have_count(1)
  drawer=manager();activate(drawer.get_by_role('button',name='image.png dosyasını listeden kaldır',exact=True));expect(page.locator('.demo-file')).to_have_count(0)
  expect(drawer.get_by_role('status')).to_contain_text('listeden kaldırıldı')
  # Wait for committed deletion, rather than testing only DOM disappearance.
  page.wait_for_function('''()=>new Promise((resolve,reject)=>{const open=indexedDB.open('erbapp-files',1);open.onsuccess=()=>{const db=open.result;const get=db.transaction('files').objectStore('files').getAll();get.onsuccess=()=>{const absent=!get.result.some(file=>file.name==='image.png');db.close();resolve(absent);};get.onerror=()=>reject(get.error);};})''')
  activate(drawer.get_by_role('button',name='Kapat',exact=True));page.reload(wait_until='networkidle');expect(page.locator('.demo-file')).to_have_count(0)
  upload([fixtures/'turkce-kitap.epub']);expect(page.get_by_role('tab',name='EPUB',exact=True)).to_have_attribute('aria-selected','true');expect(page.locator('.demo-file')).to_have_count(1)
  book=converted('epub:pdf','book.pdf');assert book.read_bytes().startswith(b'%PDF-')
  second=output/(label+'-second.pdf');shutil.copyfile(book,second);upload([book,second]);expect(page.get_by_role('tab',name='PDF',exact=True)).to_have_attribute('aria-selected','true');expect(page.locator('.demo-file')).to_have_count(2)
  first_name=book.name
  activate(page.get_by_role('button',name=first_name,exact=True));page.locator('#erbapp-output-format').select_option('pdf:extract');page.locator('#erbapp-page-range').fill('1-2');converted('pdf:extract','extract.pdf')
  activate(page.get_by_role('button',name='Yüklediklerimin tümünü seç',exact=True));converted('pdf:merge','merge.pdf')
  activate(page.get_by_role('button',name=first_name,exact=True));converted('pdf:rotate','rotate.pdf')
  activate(page.get_by_role('tab',name='EPUB',exact=True));expect(page.locator('.demo-file')).to_have_count(1)
  drawer=manager();activate(drawer.get_by_role('button',name='turkce-kitap.epub dosyasını listeden kaldır',exact=True));expect(page.locator('.demo-file')).to_have_count(0);activate(drawer.get_by_role('button',name='Kapat',exact=True))
  activate(page.get_by_role('tab',name='PDF',exact=True));expect(page.locator('.demo-file')).to_have_count(2)
  drawer=manager();activate(drawer.get_by_role('button',name='Bu listeyi temizle',exact=True));confirmation=drawer.get_by_role('group',name='Liste temizlensin mi?',exact=True);expect(confirmation).to_be_visible();activate(confirmation.get_by_role('button',name='Vazgeç',exact=True));expect(page.locator('.demo-file')).to_have_count(2)
  activate(drawer.get_by_role('button',name='Bu listeyi temizle',exact=True));activate(drawer.get_by_role('group',name='Liste temizlensin mi?',exact=True).get_by_role('button',name='Listeden kaldır',exact=True));expect(page.locator('.demo-file')).to_have_count(0)
  page.screenshot(path=str(output/(label+'-manager-cleared.png')),full_page=True);activate(drawer.get_by_role('button',name='Kapat',exact=True))
  activate(page.locator('#demo-library'));library=page.get_by_role('dialog',name='Kitaplık',exact=True);expect(library).to_be_visible();assert page.locator('dialog[open]').count()==0
  if native:assert page.evaluate('window.NashiMobile.back()') is True
  else:activate(library.get_by_role('button',name='Kapat',exact=True))
  expect(page.get_by_role('dialog')).to_have_count(0);assert page.evaluate('document.getElementById("playground").inert') is False
  for path,digest in original.items():assert hashlib.sha256(path.read_bytes()).hexdigest()==digest,'Source file changed: '+path.name
  assert not errors,'Uncaught JavaScript errors: '+repr(errors)
  result.update(status='passed',checks=['real PNG pixels','real JPEG','image PDF','EPUB PDF','PDF extract/merge/rotate','tab retention','IndexedDB reload','committed removal','clear cancel/confirm','source bytes unchanged'],native_scope='HTML, actual save link and real JS chunk bridge with proxy acknowledgements; native SAF is not simulated' if native else 'browser download')
  return result
 except Exception:
  page.screenshot(path=str(output/(label+'-failure.png')),full_page=True);(output/(label+'-failure.html')).write_text(page.content());raise
 finally:context.close()

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--site',type=pathlib.Path);parser.add_argument('--android-only',action='store_true');parser.add_argument('--android',type=pathlib.Path,required=True);parser.add_argument('--repo',type=pathlib.Path,required=True);parser.add_argument('--output',type=pathlib.Path,required=True);args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
 result={'status':'failed','cases':[]}
 try:
  executable=shutil.which('google-chrome') or shutil.which('google-chrome-stable') or shutil.which('chromium')
  if not executable:raise RuntimeError('CI Chrome kurulumu bulunamadı.')
  with tempfile.TemporaryDirectory(prefix='erbapp-browser-') as temporary:
   mounted=pathlib.Path(temporary)
   if not args.android_only:
    if args.site is None:raise RuntimeError('Web kabul testi için --site gerekli.')
    shutil.copytree(args.site,mounted/'nashi-app')
   shutil.copytree(args.repo/'android/app/src/main/assets',mounted/'assets');shutil.copytree(args.android,mounted/'assets',dirs_exist_ok=True)
   server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(QuietHandler,directory=str(mounted)));threading.Thread(target=server.serve_forever,daemon=True).start()
   try:
    origin=f'http://127.0.0.1:{server.server_port}'
    with sync_playwright() as playwright:
     browser=playwright.chromium.launch(executable_path=executable,headless=True)
     try:
      expect.set_options(timeout=20000)
      cases=[('desktop-web',False,False,origin+'/nashi-app/tr/#playground'),('mobile-web',True,False,origin+'/nashi-app/tr/#playground'),('android-html',True,True,origin+'/assets/web/tr/index.html#playground')]
      if args.android_only:cases=[case for case in cases if case[2]]
      for label,mobile,native,url in cases:
       result['cases'].append(exercise(browser,origin,url,args.output,label,mobile,native,args.repo/'android/tests/fixtures/epub'));print('PASS '+label,flush=True)
     finally:browser.close()
   finally:server.shutdown();server.server_close()
  result['status']='passed'
 except Exception:result['error']=traceback.format_exc();print(result['error'],flush=True)
 (args.output/'browser-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');return 0 if result['status']=='passed' else 1
if __name__=='__main__':raise SystemExit(main())
