
const erbappRealTools=window.ErbappRealTools.install({stage,pick:()=>input.click(),group:()=>state.group,selection:()=>selection(),result:(name,blob)=>addResult(name,blob),selectAll:()=>{state.selected=state.files.filter(file=>file.user).map(file=>file.id);renderFiles();}});
const erbappOriginalRenderTools=renderFiles;
renderFiles=function(){erbappOriginalRenderTools();erbappRealTools.render();};
const erbappOriginalSelectFile=selectFile;
selectFile=function(file,multiple){if(!multiple)state.selected=[file.id];erbappOriginalSelectFile(file,multiple);erbappRealTools.render();};
const erbappOriginalOpenWheel=openWheel;
openWheel=function(mode,...args){if(mode==='convert'){closeWheel();erbappRealTools.show();return;}return erbappOriginalOpenWheel(mode,...args);};

const erbappOriginalAddResult=addResult;
const erbappOriginalToast=toast;
toast=function(title,description,result){if(result?.blob)return;return erbappOriginalToast(title,description,result);};
addResult=function(name,blob,details=''){
 if(!blob){toast('Önizleme','Bu araç gerçek çıktı üretmiyor. Dosya dönüştür bölümündeki desteklenen işlemleri kullan.');return null;}
 return erbappOriginalAddResult(name,blob,details);
};
