
const erbappEpubUI=window.ErbappEpubUI.install({
 dialog:(title,subtitle)=>showDialog(title,subtitle),editor:()=>state.editor,
 close:()=>closeEditor(),pick:()=>input.click(),
 result:(name,blob)=>addResult(name,blob),unavailable:(files,ext)=>erbappEditorDialogs.unavailable(files,ext)
});
const erbappOriginalConvert=convert;
convert=async function(ext){
 const files=selection();
 if(files.some(file=>file.ext==='epub'))return erbappEpubUI.convert(files,ext);
 return erbappOriginalConvert(ext);
};
