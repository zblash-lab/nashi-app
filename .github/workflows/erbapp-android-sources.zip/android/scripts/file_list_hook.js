
// Android list management: source URIs and saved outputs are never changed.
const nashiFileList = window.NashiFileList.install({
 root, stage,
 group:()=>state.group,
 files:()=>state.files,
 replace:files=>{
  closeWheel(); state.drag?.ghost?.remove(); state.drag=null;
  const kept=new Set(files.map(file=>file.id));
  const removed=new Set(state.files.filter(file=>!kept.has(file.id)).map(file=>file.id));
  state.files=files; state.selected=state.selected.filter(id=>kept.has(id));
  state.shelf=state.shelf.filter(file=>!removed.has(file.id));
  state.float.selected=state.float.selected.filter(id=>state.shelf.some(file=>file.id===id));
 },
 release:file=>{
  erbappWorkspace.remove(file.id);
  if(file.url && state.urls.has(file.url) && !state.library.some(output=>output.url===file.url)){
   URL.revokeObjectURL(file.url); state.urls.delete(file.url);
  }
 },
 refresh:()=>renderFiles(),
 samples:()=>specs[state.group].map(([name,kind],i)=>fileModel(name,kind,i)),
 dialog:(title,subtitle)=>{ closeWheel(); closeEditor(); return window.ErbappOverlay.open(title,subtitle); },
 closeDialog:()=>window.ErbappOverlay.close(), pick:()=>input.click()
});
const nashiRenderFiles = renderFiles;
renderFiles = function(){ nashiFileList.filter(); nashiRenderFiles(); nashiFileList.render(); };
