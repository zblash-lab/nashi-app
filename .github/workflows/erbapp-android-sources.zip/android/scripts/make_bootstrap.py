"""Generate a small workflow plus a separately checksummed Android source ZIP."""
import hashlib,io,pathlib,zipfile
ROOT=pathlib.Path(__file__).resolve().parents[2]
SOURCE_NAME='erbapp-android-sources.zip'
MAX_WORKFLOW_BYTES=500_000

def build(destination):
 destination=pathlib.Path(destination);destination.parent.mkdir(parents=True,exist_ok=True)
 buffer=io.BytesIO()
 with zipfile.ZipFile(buffer,'w',zipfile.ZIP_DEFLATED) as archive:
  for path in sorted((ROOT/'android').rglob('*')):
   if not path.is_file() or any(part in {'build','.gradle','__pycache__'} for part in path.parts):continue
   if path.suffix.lower() in {'.p12','.jks','.keystore','.key'} or 'ERBAPP_SIGNING' in path.name.upper() or (path.suffix.lower()=='.pem' and b'PRIVATE KEY' in path.read_bytes()):
    raise RuntimeError('Özel imza anahtarı kaynak paketine eklenemez: '+str(path.relative_to(ROOT)))
   info=zipfile.ZipInfo(path.relative_to(ROOT).as_posix(),(2026,10,29,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
   archive.writestr(info,path.read_bytes())
 data=buffer.getvalue();digest=hashlib.sha256(data).hexdigest()
 python=[
  'import hashlib,io,pathlib,zipfile',
  'if pathlib.Path("android/app/build.gradle.kts").is_file():',
  '    print("Using checked-in Android sources.")',
  'else:',
  f'    package=pathlib.Path(".github/workflows/{SOURCE_NAME}")',
  '    if not package.is_file():',
  f'        raise RuntimeError("{SOURCE_NAME} dosyasını ZIP olarak .github/workflows klasörüne yükle.")',
  '    data=package.read_bytes()',
  f'    if hashlib.sha256(data).hexdigest()!={digest!r}:',
  '        raise RuntimeError("Kaynak ZIP özeti eşleşmiyor. Aynı teslimattaki YAML ve ZIP dosyalarını birlikte yükle.")',
  '    with zipfile.ZipFile(io.BytesIO(data)) as archive:',
  '        for info in archive.infolist():',
  '            path=pathlib.PurePosixPath(info.filename)',
  '            assert not path.is_absolute() and ".." not in path.parts and path.parts[0]=="android"',
  '            assert ((info.external_attr >> 16) & 0o170000) != 0o120000',
  '        archive.extractall(".")']
 step='      - name: Doğrulanan Android kaynak paketini aç\n        run: |\n          python3 - <<\'PY\'\n'
 step+='\n'.join('          '+line for line in python)+'\n          PY\n'
 workflow=(ROOT/'.github/workflows/nashi-android.yml').read_text()
 workflow=workflow.replace('      - uses: actions/checkout@v4\n','      - uses: actions/checkout@v4\n'+step,1)
 workflow='# Upload this YAML and erbapp-android-sources.zip together to .github/workflows/.\n'+workflow
 if len(workflow.encode())>MAX_WORKFLOW_BYTES:raise RuntimeError('Workflow 500 KB sınırını aşıyor.')
 destination.with_name(SOURCE_NAME).write_bytes(data);destination.write_text(workflow)
 print(f'Workflow: {len(workflow.encode())} bytes; separate sources: {len(data)} bytes; SHA-256 {digest}')
 return destination.with_name(SOURCE_NAME)

if __name__=='__main__':
 import sys
 build(sys.argv[1])
