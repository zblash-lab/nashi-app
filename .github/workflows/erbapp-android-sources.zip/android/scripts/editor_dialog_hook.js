
// Route all existing tool/library/preview windows through the shared DOM overlay.
const erbappEditorDialogs=window.ErbappEditorDialogs.install({
 closeWheel,
 getEditor:()=>state.editor,
 setEditor:editor=>{state.editor=editor;},
 icon,
 key:event=>editorKey(event,event.target.matches('input,textarea,select,[contenteditable=true]'))
});
showDialog=erbappEditorDialogs.open;
closeEditor=erbappEditorDialogs.close;
const erbappCapabilityNote=document.createElement('p');
erbappCapabilityNote.className='erbapp-capability-note';
erbappCapabilityNote.textContent='EPUB → PDF için kendi EPUB dosyanı ekle. DRM’siz metin kitapları desteklenir; örnek dosya dönüştürülmez.';
erbappCapabilityNote.hidden=true;stage.before(erbappCapabilityNote);
const erbappRenderWithCapability=renderFiles;
renderFiles=function(){
 erbappRenderWithCapability();
 erbappCapabilityNote.hidden=state.group!=='epub';
};
