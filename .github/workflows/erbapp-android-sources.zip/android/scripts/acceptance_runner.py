"""Run isolated mandatory checks, retaining all failures and partial evidence."""
import traceback

SCENARIOS = ('image-png', 'image-jpeg', 'image-webp', 'image-pdf', 'epub-pdf',
             'pdf-extract', 'pdf-merge', 'pdf-rotate', 'file-management', 'library')


def run_scenarios(exercise, case, checkpoint=lambda: None):
    case['scenarios'] = []
    for name in SCENARIOS:
        result = {'name': name, 'status': 'failed'}
        case['scenarios'].append(result)
        try:
            exercise(name, result)
            result['status'] = 'passed'
        except Exception:
            result['error'] = traceback.format_exc()
        checkpoint()
    case['status'] = 'passed' if all(item['status'] == 'passed' for item in case['scenarios']) else 'failed'
    checkpoint()
