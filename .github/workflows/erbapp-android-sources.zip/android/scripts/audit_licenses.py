"""Audit runtime POM licenses, including Maven parent inheritance.

Missing or unrecognized license evidence blocks APK publication. Check every
component before reporting errors so CI exposes all license problems together.
"""
import argparse
import hashlib
import json
import pathlib
import re
import sys
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET

APACHE_URLS = {
    'https://www.apache.org/licenses/LICENSE-2.0',
    'https://www.apache.org/licenses/LICENSE-2.0.txt',
    'http://www.apache.org/licenses/LICENSE-2.0',
    'http://www.apache.org/licenses/LICENSE-2.0.txt',
}
NS = {'m': 'http://maven.apache.org/POM/4.0.0'}
REPOSITORIES = (
    'https://dl.google.com/dl/android/maven2/',
    'https://repo.maven.apache.org/maven2/',
)


def declared_licenses(data):
    root = ET.fromstring(data)
    return [
        {'name': x.findtext('m:name', default='', namespaces=NS).strip(),
         'url': x.findtext('m:url', default='', namespaces=NS).strip()}
        for x in root.findall('m:licenses/m:license', NS)
    ]


def fetch_pom(group, name, version):
    parts = (group, name, version)
    if not all(re.fullmatch(r'[A-Za-z0-9_][A-Za-z0-9_.+-]*', part) for part in parts):
        raise RuntimeError(f'Geçersiz veya çözümlenmemiş POM koordinatı: {parts}')
    path = f'{group.replace(".", "/")}/{name}/{version}/{name}-{version}.pom'
    repositories = REPOSITORIES if group.startswith('androidx.') else REPOSITORIES[::-1]
    for base in repositories:
        url = base + path
        try:
            with urllib.request.urlopen(url, timeout=25) as response:
                return response.read(), url
        except urllib.error.HTTPError as error:
            if error.code != 404:
                raise
    raise RuntimeError(f'POM bulunamadı: {group}:{name}:{version}')


def resolve_licenses(coordinate, cache, chain=()):
    """Follow a parent only when the child has no explicit license declaration."""
    if coordinate in chain or len(chain) >= 12:
        raise RuntimeError('Döngü veya aşırı uzun POM üst proje zinciri: ' + ':'.join(coordinate))
    if coordinate not in cache:
        cache[coordinate] = fetch_pom(*coordinate)
    data, url = cache[coordinate]
    evidence = {'component': ':'.join(coordinate), 'pom_url': url,
                'pom_sha256': hashlib.sha256(data).hexdigest()}
    licenses = declared_licenses(data)
    if licenses:
        return licenses, [evidence]
    parent = ET.fromstring(data).find('m:parent', NS)
    if parent is None:
        raise RuntimeError(f'Lisans bildirimi veya üst proje bulunamadı: {evidence["component"]}')
    parent_coordinate = tuple(
        parent.findtext(f'm:{field}', default='', namespaces=NS).strip()
        for field in ('groupId', 'artifactId', 'version')
    )
    licenses, ancestors = resolve_licenses(parent_coordinate, cache, chain + (coordinate,))
    return licenses, [evidence, *ancestors]


class AuditFailure(RuntimeError):
    def __init__(self, report):
        self.report = report
        super().__init__('\n'.join(f'{x["component"]}: {x["error"]}' for x in report['errors']))


def audit(components):
    report, errors, cache = [], [], {}
    if not components:
        errors.append({'component': '(runtime)', 'error': 'Çözümlenen çalışma zamanı bileşeni yok.'})
    for item in components:
        gav = ':'.join(item.get(key, '') for key in ('group', 'name', 'version'))
        try:
            coordinate = tuple(item[key] for key in ('group', 'name', 'version'))
            licenses, evidence = resolve_licenses(coordinate, cache)
            if not all(x['url'].rstrip('/') in APACHE_URLS for x in licenses):
                raise RuntimeError(f'Lisans manuel inceleme gerektiriyor: {licenses}')
            report.append({
                'component': gav, 'license': 'Apache-2.0', 'declared': licenses,
                'pom_url': evidence[0]['pom_url'], 'pom_sha256': evidence[0]['pom_sha256'],
                'license_source': evidence[-1]['component'], 'pom_chain': evidence,
                'artifact_sha256': hashlib.sha256(pathlib.Path(item['file']).read_bytes()).hexdigest(),
            })
            print(f'OK {gav}: Apache-2.0 (kaynak: {evidence[-1]["component"]})', flush=True)
        except (OSError, ValueError, KeyError, RuntimeError, ET.ParseError) as error:
            errors.append({'component': gav, 'error': str(error)})
    result = {
        'status': 'failed' if errors else 'passed',
        'scope': 'resolved debugRuntimeClasspath; Maven parent inheritance; upstream web notices packaged separately',
        'components': report, 'errors': errors,
    }
    if errors:
        raise AuditFailure(result)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--components', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    try:
        result = audit(json.loads(pathlib.Path(args.components).read_text()))
    except AuditFailure as error:
        result = error.report
    out = pathlib.Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    for error in result['errors']:
        print(f'ERROR {error["component"]}: {error["error"]}', file=sys.stderr)
    print(f'{len(result["components"])} bileşen doğrulandı; {len(result["errors"])} hata.')
    return 0 if result['status'] == 'passed' else 1


if __name__ == '__main__':
    sys.exit(main())
