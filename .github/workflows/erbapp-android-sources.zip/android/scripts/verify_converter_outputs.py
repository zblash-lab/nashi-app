"""Read the generated files with an independent PDF reader; never accept file names alone."""
import argparse,hashlib,json,pathlib,struct

def book(path):
 from pypdf import PdfReader
 reader=PdfReader(path);text='\n'.join(page.extract_text() for page in reader.pages)
 for value in ['ÇĞİÖŞÜ çğıöşü','Öykünün sonu','BİRİNCİ BÖLÜM','İKİNCİ BÖLÜM']:
  if value not in text:raise RuntimeError('EPUB PDF metni eksik: '+value)
 if text.index('BİRİNCİ BÖLÜM')>=text.index('İKİNCİ BÖLÜM'):raise RuntimeError('EPUB bölümleri yanlış sırada.')
 if len(reader.pages)<3 or not any(list(page.images) for page in reader.pages):raise RuntimeError('EPUB PDF sayfaları veya görseli eksik.')
 expected=hashlib.sha256((pathlib.Path(__file__).resolve().parents[1]/'vendor/fonts/DejaVuSans.ttf').read_bytes()).hexdigest()
 embedded=set()
 for page in reader.pages:
  for reference in page['/Resources'].get('/Font',{}).get_object().values():
   font=reference.get_object()
   for child in font.get('/DescendantFonts',[]):
    descriptor=child.get_object().get('/FontDescriptor')
    if descriptor and descriptor.get_object().get('/FontFile2'):
     embedded.add(hashlib.sha256(descriptor.get_object()['/FontFile2'].get_data()).hexdigest())
 if expected not in embedded:raise RuntimeError('Gömülü yazı tipinin özgün lisans tablosu korunmamış.')
 return len(reader.pages)

def validate_cases(result,android_only=False):
 expected={'android-html'} if android_only else {'desktop-web','mobile-web','android-html'}
 if result['status']!='passed' or {case['case'] for case in result['cases']}!=expected or len(result['cases'])!=len(expected):raise RuntimeError('Gerekli arayüz/çıktı senaryoları tamamlanmadı.')

def verify(folder,node_pdf=None,android_only=False):
 from pypdf import PdfReader
 folder=pathlib.Path(folder);report={'status':'passed','cases':[]}
 if node_pdf:report['node_epub_pages']=book(node_pdf)
 result=json.loads((folder/'browser-results.json').read_text())
 validate_cases(result,android_only)
 for case in result['cases']:
  outputs={name:folder/file for name,file in case['outputs'].items()}
  png=outputs['image.png'].read_bytes()
  if not png.startswith(b'\x89PNG\r\n\x1a\n') or struct.unpack('>II',png[16:24])!=(32,24):raise RuntimeError('Görsel PNG çıktısı geçersiz.')
  if not outputs['image.jpg'].read_bytes().startswith(b'\xff\xd8'):raise RuntimeError('JPEG çıktısı geçersiz.')
  image=PdfReader(outputs['image.pdf'])
  if len(image.pages)!=1 or not list(image.pages[0].images):raise RuntimeError('Görselden PDF çıktısı boş.')
  count=book(outputs['book.pdf']);extract=PdfReader(outputs['extract.pdf']);merge=PdfReader(outputs['merge.pdf']);rotate=PdfReader(outputs['rotate.pdf'])
  if len(extract.pages)!=2:raise RuntimeError('PDF sayfa seçimi yanlış.')
  if len(merge.pages)!=count*2:raise RuntimeError('PDF birleştirme yanlış.')
  if len(rotate.pages)!=count or any(int(page.get('/Rotate',0))%360!=90 for page in rotate.pages):raise RuntimeError('PDF döndürme yanlış.')
  report['cases'].append({'case':case['case'],'status':'passed','epub_pages':count,'extract_pages':2,'merged_pages':count*2,'rotation':90,'png_dimensions':[32,24]})
 (folder/'converter-output-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False,indent=2))
 return report
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--folder',required=True);parser.add_argument('--node-pdf');parser.add_argument('--android-only',action='store_true');args=parser.parse_args();verify(args.folder,args.node_pdf,args.android_only)
