"""Independently decode every real output; retain all errors, never accept names alone."""
import argparse
import hashlib
import json
import pathlib

EXPECTED_SCENARIOS = {'image-png', 'image-jpeg', 'image-webp', 'image-pdf', 'epub-pdf',
                      'pdf-extract', 'pdf-merge', 'pdf-rotate', 'file-management', 'library', 'classic-tools'}


def book(path):
    from pypdf import PdfReader
    reader = PdfReader(path)
    text = '\n'.join(page.extract_text() for page in reader.pages)
    for value in ['ÇĞİÖŞÜ çğıöşü', 'Öykünün sonu', 'BİRİNCİ BÖLÜM', 'İKİNCİ BÖLÜM']:
        if value not in text:
            raise RuntimeError('EPUB PDF metni eksik: ' + value)
    if text.index('BİRİNCİ BÖLÜM') >= text.index('İKİNCİ BÖLÜM'):
        raise RuntimeError('EPUB bölümleri yanlış sırada.')
    if len(reader.pages) < 3 or not any(list(page.images) for page in reader.pages):
        raise RuntimeError('EPUB PDF sayfaları veya görseli eksik.')
    expected = hashlib.sha256((pathlib.Path(__file__).resolve().parents[1] / 'vendor/fonts/DejaVuSans.ttf').read_bytes()).hexdigest()
    embedded = set()
    for page in reader.pages:
        for reference in page['/Resources'].get('/Font', {}).get_object().values():
            font = reference.get_object()
            for child in font.get('/DescendantFonts', []):
                descriptor = child.get_object().get('/FontDescriptor')
                if descriptor and descriptor.get_object().get('/FontFile2'):
                    embedded.add(hashlib.sha256(descriptor.get_object()['/FontFile2'].get_data()).hexdigest())
    if expected not in embedded:
        raise RuntimeError('Gömülü yazı tipinin özgün lisans tablosu korunmamış.')
    return len(reader.pages)


def validate_cases(result, android_only=False):
    expected = {'android-html'} if android_only else {'desktop-web', 'mobile-web', 'android-html'}
    cases = result.get('cases', [])
    if (result.get('status') != 'passed' or {case['case'] for case in cases} != expected or
            len(cases) != len(expected)):
        raise RuntimeError('Gerekli arayüz/çıktı senaryoları tamamlanmadı.')
    for case in cases:
        scenarios = case.get('scenarios', [])
        if (case.get('status') != 'passed' or len(scenarios) != len(EXPECTED_SCENARIOS) or
                {item['name'] for item in scenarios} != EXPECTED_SCENARIOS or
                any(item.get('status') != 'passed' for item in scenarios)):
            raise RuntimeError('Eksik veya başarısız zorunlu araç testi: ' + case['case'])


def image_output(path, expected_format):
    from PIL import Image
    with Image.open(path) as image:
        image.load()
        if image.format != expected_format or image.size != (32, 24):
            raise RuntimeError('Görsel biçimi veya boyutu yanlış: ' + path.name)
        pixel = image.convert('RGB').getpixel((0, 0))
        tolerance = 0 if expected_format == 'PNG' else 6
        if any(abs(actual - expected) > tolerance for actual, expected in zip(pixel, (20, 120, 210))):
            raise RuntimeError('Görsel pikseli yanlış: ' + path.name)
    return {'dimensions': [32, 24], 'format': expected_format}


def pdf_output(path, action):
    from pypdf import PdfReader
    reader = PdfReader(path)
    expected = {'extract': ([301, 303], ['Source A page 1', 'Source A page 3']),
                'merge': ([301, 302, 303, 401, 402], ['Source A page 1', 'Source A page 2', 'Source A page 3', 'Source B page 1', 'Source B page 2']),
                'rotate': ([301, 302, 303], ['Source A page 1', 'Source A page 2', 'Source A page 3'])}
    widths, texts = expected[action]
    if [int(page.mediabox.width) for page in reader.pages] != widths:
        raise RuntimeError('PDF sayfa sayısı veya sırası yanlış: ' + action)
    if [page.extract_text().strip() for page in reader.pages] != texts:
        raise RuntimeError('PDF sayfa içeriği yanlış: ' + action)
    rotation = 90 if action == 'rotate' else 0
    if any(int(page.get('/Rotate', 0)) % 360 != rotation for page in reader.pages):
        raise RuntimeError('PDF döndürme yanlış: ' + action)
    return {'pages': len(reader.pages), 'rotation': rotation, 'widths': widths}


def image_pdf(path):
    from pypdf import PdfReader
    pdf = PdfReader(path)
    if len(pdf.pages) != 1 or not list(pdf.pages[0].images):
        raise RuntimeError('Görselden PDF çıktısı boş.')
    return {'pages': 1, 'embedded_images': len(list(pdf.pages[0].images))}


def verify(folder, node_pdf=None, android_only=False):
    folder = pathlib.Path(folder)
    report = {'status': 'failed', 'cases': [], 'errors': []}
    try:
        result = json.loads((folder / 'browser-results.json').read_text())
        try:
            validate_cases(result, android_only)
        except Exception as error:
            report['errors'].append(str(error))
        if node_pdf:
            try:
                report['node_epub_pages'] = book(node_pdf)
            except Exception as error:
                report['errors'].append('Node EPUB PDF: ' + str(error))
        checks = [('image.png', lambda path: image_output(path, 'PNG')),
                  ('image.jpg', lambda path: image_output(path, 'JPEG')),
                  ('image.webp', lambda path: image_output(path, 'WEBP')),
                  ('image.pdf', image_pdf), ('book.pdf', lambda path: {'pages': book(path)}),
                  ('extract.pdf', lambda path: pdf_output(path, 'extract')),
                  ('merge.pdf', lambda path: pdf_output(path, 'merge')),
                  ('rotate.pdf', lambda path: pdf_output(path, 'rotate'))]
        for case in result.get('cases', []):
            item = {'case': case['case'], 'status': 'failed', 'outputs': []}
            report['cases'].append(item)
            for name, check in checks:
                output = {'name': name, 'status': 'failed'}
                item['outputs'].append(output)
                try:
                    relative = pathlib.PurePosixPath(case.get('outputs', {})[name])
                    if relative.is_absolute() or '..' in relative.parts:
                        raise RuntimeError('Çıktı rapor yolu geçersiz.')
                    output.update(check(folder / relative), status='passed')
                except Exception as error:
                    output['error'] = str(error)
                    report['errors'].append(case['case'] + '/' + name + ': ' + str(error))
            if all(output['status'] == 'passed' for output in item['outputs']):
                item['status'] = 'passed'
    except Exception as error:
        report['errors'].append(str(error))
    if not report['errors'] and report['cases']:
        report['status'] = 'passed'
    (folder / 'converter-output-verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if report['status'] != 'passed':
        raise RuntimeError('Bağımsız çıktı kontrolü tamamlanmadı; converter-output-verification.json dosyasını incele.')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--folder', required=True)
    parser.add_argument('--node-pdf')
    parser.add_argument('--android-only', action='store_true')
    args = parser.parse_args()
    verify(args.folder, args.node_pdf, args.android_only)
